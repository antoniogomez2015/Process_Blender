Rendering Updates

- possibly add new bpy handler and submit a patch
    - POST_VIEW, PRE_VIEW!!!
    - [bpy.app.handlers](http://www.blender.org/api/blender_python_api_2_72_1/bpy.app.handlers.html)
    - [BLI_callbacks.h](https://developer.blender.org/diffusion/B/browse/master/source/blender/blenlib/BLI_callbacks.h)
    - [bpy_app_handlers.c:list](https://developer.blender.org/diffusion/B/browse/master/source/blender/python/intern/bpy_app_handlers.c;20a177814815e7e3a1a4a4d37e91880ef98aa68a$46)
    - [bpy_app_handlers.c:calling](https://developer.blender.org/diffusion/B/browse/master/source/blender/python/intern/bpy_app_handlers.c;20a177814815e7e3a1a4a4d37e91880ef98aa68a$229)


- Topology

- [topowiki](http://probiner.x10.mx/wiki/doku.php?id=start)