# rigify_rollbreak_patch
Patch Existing Rigify Rigs to add FootRoll Break

![FootRollBreak](doc/footrollbreak_steps.png?raw=true "FootRollBreak")

# How to use it ?
A complete documentation is available here : [FootRollBreak documentation](http://julienduroure.com/footrollbreak).
If here a minimal quick guide:

* Install FootRollBreak addon, and activate it.
* Select your rigify rig, and got to armature data properties. A new panel is there :)
* Patch your rig
* A new panel can be found on 3D View properties panels (N), near other rigify panels.
* That's it ! Enjoy :)
* FootRollBreak will remain enabled on your rig, even if you disable/remove the addon.


# Version history

## 1.0.0 (2016, Match 15th)

Initial release
