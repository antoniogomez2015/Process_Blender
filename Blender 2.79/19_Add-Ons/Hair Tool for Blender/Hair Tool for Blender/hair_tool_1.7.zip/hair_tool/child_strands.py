# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from math import sqrt, pow
from random import uniform, seed
from mathutils import noise, Vector, kdtree, Matrix
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
from .resample2d import interpol
from .surface_to_splines import calc_power
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python35\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb
 #DONE: fix active particle
 #DONE: mask support
 #DONE: Fix matrix world
 #DONE: Addo noise..
 #NOPE: Support uniform and non even len interpol? Or just leave it to resample oper?

class RibbonsFromParticleHairChild(bpy.types.Operator):
    bl_label = "Ribbons from particle hair with children"
    bl_idname = "object.ribbons_from_ph_child"
    bl_description = "Generate Ribbons from particle hair with custom made child strands generator. \n" \
                     "It gives more uniform child distribution compared to build in child particles."
    bl_options = {"REGISTER", "UNDO", "PRESET"}

    # extend = BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=True)
    # override_segments = BoolProperty(name="Resample strands", description="Force using strands segments parameter", default=False)
    t_in_y = IntProperty(name="Strand Segments", default=5, min=2, max=20)
    childCount = IntProperty(name="Child count", default=100, min=10, max=2000)
    hairType = bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    Seed = IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    PlacementJittering = FloatProperty(name="Placement Jittering/Face", description="Placement Jittering/Face \n"
                                                                                    "Helps even out particle distribution \n"
                                                                                    "0 = automatic", default=0, min=0, max=100, subtype='PERCENTAGE')

    embed = FloatProperty(name="Embed roots", description="Radius for bezier curve", default=0, min=0, max=10)
    # embedTips = FloatProperty(name="Embed tips", description="Radius for bezier curve", default=0, min=0, max=10)

    noiseFalloff = FloatProperty(name="Noise falloff", description="Noise influence over strand lenght", default=0, min=-1, max=1, subtype='PERCENTAGE')
    freq = FloatProperty(name="Noise freq", default=0.5, min=0.0, max=5.0)
    noiseAmplitude = FloatProperty(name="Noise Amplitude", default=0.5, min=0.0, max=10.0)

    lenSeed = IntProperty(name="Length Seed", default=1, min=1, max=1000)
    RandomizeLengthPlus = FloatProperty(name="Increase length randomly", description="Increase length randomly", default=0, min=0, max=1, subtype='PERCENTAGE')
    RandomizeLengthMinus = FloatProperty(name="Decrease length randomly", description="Decrease length randomly", default=0, min=0, max=1, subtype='PERCENTAGE')

    generateRibbons = BoolProperty(name="Generate Ribbons", description="Generate Ribbons on curve", default=True)
    strandResU = IntProperty(name="Segments U", default=3, min=1, max=5, description="Additional subdivision along strand length")
    strandResV = IntProperty(name="Segments V", default=2, min=1, max=5, description="Subdivisions perpendicular to strand length ")
    strandWidth = FloatProperty(name="Strand Width", default=0.5, min=0.0, max=10)
    strandPeak = FloatProperty(name="Strand peak", default=0.4, min=0.0, max=1,
                               description="Describes how much middle point of ribbon will be elevated")
    strandUplift = FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")
    alignToSurface = BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    RadiusFalloff = FloatProperty(name="Radius falloff", description="Radius falloff over strand lenght", default=0,  min=-1, max=1, subtype='PERCENTAGE')
    TipRadius = FloatProperty(name="Tip Radius", description="Tip Radius", default=0, min=0,  max=1, subtype='PERCENTAGE')

    Clumping = FloatProperty(name="Clumping", description="Clumping", default=0, min=0,  max=1, subtype='PERCENTAGE')
    ClumpingFalloff = FloatProperty(name="Clumping Falloff", description="Clumping Falloff", default=0,  min=-1, max=1, subtype='PERCENTAGE')
    Radius = FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, max=100)


    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label("Curves from Particle Hair Settings:")
        box.prop(self, 'embed')
        # box.prop(self, 'embedTips')
        box.prop(self, 'hairType')
        box.prop(self, 't_in_y')
        box.prop(self, 'childCount')
        box.prop(self, 'PlacementJittering')

        box.label("Noise:")
        col = box.column(align=True)
        col.prop(self, 'Seed')
        col.prop(self, 'noiseFalloff')
        col.prop(self, 'noiseAmplitude')
        col.prop(self, 'freq')
        col = box.column(align=True)
        col.prop(self, 'lenSeed')
        col.prop(self, 'RandomizeLengthPlus')
        col.prop(self, 'RandomizeLengthMinus')

        box.prop(self, 'generateRibbons')
        if self.generateRibbons:
            col = box.column(align=True)
            col.prop(self, 'strandResU')
            col.prop(self, 'strandResV')
            col.prop(self, 'strandWidth')
            col.prop(self, 'strandPeak')
            col.prop(self, 'strandUplift')
            col.prop(self, 'alignToSurface')
        else:
            col.prop(self, 'Radius')
            col.prop(self, 'RadiusFalloff')
            col.prop(self, 'TipRadius')
            col.prop(self, 'Clumping')
            col.prop(self, 'ClumpingFalloff')

    @staticmethod
    def isEqualLen(lst_of_lsts):
        if len(lst_of_lsts) in (0, 1): return True
        lfst = len(lst_of_lsts[0])
        return all(len(lst) == lfst for lst in lst_of_lsts[1:])


    def createUniformParticleSystem(self, particleObj,partsysMod):
        tempParticleMod = particleObj.modifiers.new("HairTemp", 'PARTICLE_SYSTEM')
        partsysUniform = tempParticleMod.particle_system.settings
        partsysUniform.name = 'HairFromCurves'
        partsysUniform.count = self.childCount
        partsysUniform.use_emit_random = False
        partsysUniform.use_even_distribution = True
        partsysUniform.emit_from = 'FACE'
        partsysUniform.physics_type = 'NO'
        partsysUniform.frame_start = 0
        partsysUniform.frame_end = 0
        partsysUniform.lifetime = 500
        partsysUniform.distribution = "JIT"
        partsysUniform.jitter_factor = 1
        partsysUniform.userjit = self.PlacementJittering*2
        tempParticleMod.particle_system.seed = self.Seed
        tempParticleMod.particle_system.vertex_group_density = partsysMod.vertex_group_density
        bpy.context.scene.update()
        particleObjMatWorldInv = particleObj.matrix_world.inverted()
        childParticles = [particleObjMatWorldInv * particle.location for particle in tempParticleMod.particle_system.particles]
        particleObj.modifiers.remove(tempParticleMod)
        return childParticles

    def execute(self, context):
        particleObj = context.active_object
        partsysMod = None
        for mod in particleObj.modifiers:
            if mod.type == 'PARTICLE_SYSTEM':  # use first visible
                if particleObj.particle_systems.active.name == mod.particle_system.name:
                    if mod.particle_system.settings.type == "HAIR":
                        partsysMod = mod.particle_system  # use last
                        mod.show_viewport = True
                        break
        if partsysMod is None:  # create new one
            self.report({'INFO'}, 'No active Particle Hair System found!')
            return {"CANCELLED"}
        psys_active_index = particleObj.particle_systems.active_index
        pointsList = []
        for strand in partsysMod.particles:  # for strand point
            pointsList.append([hair_key.co for hair_key in strand.hair_keys])
        # if not self.isEqualLen(pointsList): #why this breaks
        bpy.context.scene.update()
        #constantLen cos barycentric transform requires it
        pointsList = interpol(pointsList, self.t_in_y, uniform=True, constantLen=True) #just gives smoother result on borders
        diagonal = sqrt(pow(particleObj.dimensions[0], 2) + pow(particleObj.dimensions[1], 2) + pow(particleObj.dimensions[2], 2))  # to normalize some values
        searchDistance = 100 * diagonal
        parentRoots = [strand[0] for strand in pointsList]  # first point of roots
    #create nnew Part Sytem with uniform points
        pointsChildRoots = self.createUniformParticleSystem(particleObj, partsysMod)  # return child part roots positions

        particleObj.particle_systems.active_index = psys_active_index

        kd = kdtree.KDTree(len(parentRoots))
        for i, root in enumerate(parentRoots):
            kd.insert(root, i)
        kd.balance()
        sourceSurface_BVHT = BVHTree.FromObject(particleObj, context.scene)
        childStrandsPoints = []  #will contain strands with child points
        childStrandRootNormals = []
        VGIndex = -1
        vertex_group_length_name = partsysMod.vertex_group_length
        if vertex_group_length_name:  # calc weight based on root point
            VGIndex = particleObj.vertex_groups[vertex_group_length_name].index
        particleObjMesh = particleObj.to_mesh(context.scene, apply_modifiers=True, settings='PREVIEW')
        seed(a=self.lenSeed, version=2)
        embed = self.embed * 0.04 * diagonal
        cpow = calc_power(self.noiseFalloff)
        cpowClump = calc_power(self.ClumpingFalloff)
        noiseFalloff = [pow(i / self.t_in_y, cpow) for i in range(self.t_in_y)]
        ClumpFalloff = [pow((i+1) / self.t_in_y, cpowClump) for i in range(self.t_in_y)]

        for i,childRoot in enumerate(pointsChildRoots):  #for each child find it three parents and genereate strands by barycentric transform
            snappedPoint, normalChildRoot, rootHitIndex, distance = sourceSurface_BVHT.find_nearest(childRoot, searchDistance)
            childStrandRootNormals.append(normalChildRoot)
            threeClosestParentRoots = kd.find_n(childRoot, 3) #find three closes parent roots
            rootTri_co, ParentRootIndices, distances = zip(*threeClosestParentRoots)  #split it into 3 arrays
            sourceTri_BVHT = BVHTree.FromPolygons(rootTri_co,[(0,1,2)],all_triangles=True)  # [0,1,2] - polygon == vert indices list
            childRootSnapped, normalChildProjected, index, distance = sourceTri_BVHT.find_nearest(childRoot, searchDistance) #snap generated child to parent triangle ares \normals are sometimes flipped
            childRootSnapped2, normalChildProjected2, index2, distance2 = sourceSurface_BVHT.find_nearest(childRootSnapped, searchDistance) #this gives ok normals always

            lenWeight = 1
            if VGIndex != -1:  # if vg exist
                averageWeight = 0
                for vertIndex in particleObjMesh.polygons[rootHitIndex].vertices: #DONE: check if work on mesh with modifiers
                    for group in particleObjMesh.vertices[vertIndex].groups:
                        if group.group == VGIndex:
                            averageWeight += group.weight
                            break
                lenWeight = averageWeight / len(particleObjMesh.polygons[rootHitIndex].vertices)
            ranLen=uniform(-self.RandomizeLengthMinus, self.RandomizeLengthPlus)
            lenWeight*=(1+ranLen)
            # diff = childRoot - childRootSnapped
            # mat_loc = Matrix.Translation(childRootSnapped)
            # matTriangleSpaceInv = mat_loc #* rotMatrix
            # matTriangleSpaceInv.invert()
            rotQuat = normalChildProjected2.rotation_difference(normalChildRoot)
            translationMatrix = Matrix.Translation(childRoot)
            rotMatrixRot = rotQuat.to_matrix().to_4x4()
            mat_sca = Matrix.Scale(lenWeight, 4)
            # ipdb.set_trace()
            transformMatrix = translationMatrix * rotMatrixRot
            strandPoints = []
            #for childRootSnapped points transform them from parent root triangles to parent next segment triangle t1,t2,t3
            # and compensate child snapping to root triangle from before
            for j,(t1,t2,t3) in enumerate(zip(pointsList[ParentRootIndices[0]],pointsList[ParentRootIndices[1]],pointsList[ParentRootIndices[2]])):
                pointTransformed = barycentric_transform(childRootSnapped,rootTri_co[0],rootTri_co[1],rootTri_co[2], Vector(t1), Vector(t2), Vector(t3))
                childInterpolatedPoint = transformMatrix*mat_sca*(pointTransformed-childRootSnapped) #rotate child strand to original pos (from before snapt)
                #do noise
                noise.seed_set(self.Seed + i)  # add seed per strand/ring ?
                noiseVectorPerStrand = noise.noise_vector(childInterpolatedPoint * self.freq / diagonal, noise.types.STDPERLIN)* noiseFalloff[j] * self.noiseAmplitude * diagonal / 10
                # childInterpolatedPoint += noiseVectorPerStrand

                #do clumping
                diff = Vector(t1) - childInterpolatedPoint  # calculate distance to parent strand (first strand from trio)
                # point += noiseVectorPerStrand * noiseFalloff[j] * self.noiseAmplitude * diagonal / 10
                # childClumped = childInterpolatedPoint + ClumpFalloff[j] * self.Clumping * diff + noiseVectorPerStrand * (1-ClumpFalloff[j])
                childClumped = childInterpolatedPoint + ClumpFalloff[j] * self.Clumping * diff + noiseVectorPerStrand * (1-ClumpFalloff[j]* self.Clumping)
                # childClumped = childInterpolatedPoint + noiseVectorPerStrand

                strandPoints.append(childClumped)
            # embeding roots
            diff = strandPoints[0] - strandPoints[1]
            diff.normalize()
            strandPoints[0] += (diff - normalChildRoot) * embed  # do childStrandRootNormal to move it more into mesh surface
            childStrandsPoints.append(strandPoints)

        bpy.data.meshes.remove(particleObjMesh)
        # create the Curve Datablock
        curveData = bpy.data.curves.new(particleObj.name+'_curve', type='CURVE')

        for strandPoints in childStrandsPoints:  # for strand point
            curveLength = len(strandPoints)
            polyline = curveData.splines.new(self.hairType)
            if self.hairType == 'BEZIER':
                polyline.bezier_points.add(curveLength - 1)
            elif self.hairType == 'POLY' or self.hairType == 'NURBS':
                polyline.points.add(curveLength - 1)
            if self.hairType == 'NURBS':
                polyline.order_u = 3  # like bezier thing
                polyline.use_endpoint_u = True

            for i, point in enumerate(strandPoints):
                x, y, z = Vector(point)
                if self.hairType == 'BEZIER':
                    polyline.bezier_points[i].co = (x, y, z)
                    polyline.bezier_points[i].handle_left_type = 'AUTO'
                    polyline.bezier_points[i].handle_right_type = 'AUTO'
                else:
                    polyline.points[i].co = (x, y, z, 1)
        curveData.resolution_u = self.strandResU
        curveData.dimensions = '3D'
        # create Object
        curveOB = bpy.data.objects.new(particleObj.name+'_curve', curveData)
        curveOB.matrix_world = particleObj.matrix_world
        scn = context.scene
        scn.objects.link(curveOB)
        curveOB.targetObjPointer = particleObj.name  # store source surface for snapping oper
        scn.objects.active = curveOB
        curveOB.select = True
        curveOB.data.show_normal_face = False
        if self.generateRibbons:
            bpy.ops.object.generate_ribbons(strandResU=self.strandResU, strandResV=self.strandResV,
                                            strandWidth=self.strandWidth, strandPeak=self.strandPeak,
                                            strandUplift=self.strandUplift, alignToSurface=self.alignToSurface)
        else:
            curveData.fill_mode = 'FULL'
            curveData.bevel_depth = 0.004 * diagonal
            curveData.bevel_resolution = 2
            bpy.ops.object.curve_taper(TipRadiusFalloff=self.RadiusFalloff, TipRadius=self.TipRadius, MainRadius=self.Radius)
        return {"FINISHED"}







