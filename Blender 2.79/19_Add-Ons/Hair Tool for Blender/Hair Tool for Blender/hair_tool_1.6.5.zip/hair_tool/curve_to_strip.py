# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
import math
import numpy as np
from collections import defaultdict
from bpy.props import StringProperty, BoolProperty, IntProperty, FloatProperty
from .surface_to_splines import calc_power

# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python35\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb


import bgl
import blf


def draw_callback_px(self, context, previous_uv_points,drawMouse = False):
    print("mouse points", len(self.mouse_pos))

    font_id = 0  # XXX, need to find out how best to get this.

    # draw some text
    # region = context.region
    # x, y = region.view2d.region_to_view(self.mouse_pos[0], self.mouse_pos[1]) # vies space to UV (0,1 space)
    # blf.size(font_id, 20, 72)
    # blf.position(font_id, 15, 30, 0)
    # blf.draw(font_id, "X" + str(x))
    # blf.position(font_id, 150, 80, 0)
    # blf.draw(font_id, "Y" + str(y))
    blf.size(font_id, 16, 72)
    blf.position(font_id, 15, 30, 0)
    blf.draw(font_id, "Press Enter to finish. ctrl + Mouse wheel up/down - change uv seed. Esc - cancel")
    # 50% alpha, 2 pixel width line
    bgl.glEnable(bgl.GL_BLEND)
    bgl.glColor4f(0.2, 1.0, 0.0, 0.5)
    bgl.glLineWidth(2)

    # bgl.glBegin(bgl.GL_LINE_STRIP)
    # for x, y in self.mouse_pos:
    #     bgl.glVertex2i(x, y)
    #
    # edgesUV =[[0.1,0.1]]
    if len(previous_uv_points)>0:
        bgl.glColor4f(0.4, 8.0, 0.2, 0.3)
        region = context.region
        if drawMouse:
            pointsToDraw = previous_uv_points[:-1]
        else:
            pointsToDraw = previous_uv_points
        for uv_point in pointsToDraw:
            x1, y1 = region.view2d.view_to_region(uv_point.start_point[0], uv_point.start_point[1]) # vies space to UV (0,1 space)
            x2, y2 = region.view2d.view_to_region(uv_point.end_point[0], uv_point.end_point[1]) # vies space to UV (0,1 space)

            bgl.glBegin(bgl.GL_LINE_STRIP)
            bgl.glVertex2i(x1, y1)
            bgl.glVertex2i(x1, y2)
            bgl.glVertex2i(x2, y2)
            bgl.glVertex2i(x2, y1)
            bgl.glVertex2i(x1, y1)

            bgl.glEnd()
        bgl.glColor4f(0.2, 1.0, 0.0, 0.5)
    if drawMouse:
        bgl.glBegin(bgl.GL_LINE_STRIP)
        # bgl.glColor4f(uv_draw_props.uv_edge_color[0], uv_draw_props.uv_edge_color[1], uv_draw_props.uv_edge_color[2],
        #               uv_draw_props.edgeOpacity)
        bgl.glVertex2i(self.mouse_start[0], self.mouse_start[1])
        bgl.glVertex2i(self.mouse_start[0], self.mouse_pos[1])
        bgl.glVertex2i(self.mouse_pos[0], self.mouse_pos[1])
        bgl.glVertex2i(self.mouse_pos[0], self.mouse_start[1])
        bgl.glVertex2i(self.mouse_start[0], self.mouse_start[1])

        bgl.glEnd()

    # restore opengl defaults
    bgl.glLineWidth(1)
    bgl.glDisable(bgl.GL_BLEND)
    bgl.glColor4f(0.0, 0.0, 0.0, 1.0)


class ModalUvRangeSelect(bpy.types.Operator):
    """Draw a line with the mouse"""
    bl_idname = "uv.hair_uv_area_select"
    bl_label = "Draw uv area for Hair"
    bl_description = "Draw box in UV editor to define hair ribbons uv's"
    bl_options = {"REGISTER", "UNDO"}

    Seed = IntProperty(name="Noise Seed", default=20, min=1, max=1000)
    _handle = None
    UVBackup= []
    uv_seedBackup = 1
    # def poll(self, context):
    #     return context.active_object.type == "MESH"

    def manualUndo(self,mesheHair,hairParent):
        mesheHair.hair_settings.hair_uv_points.clear()
        for points in self.UVBackup:
            mesheHair.hair_settings.hair_uv_points.add()
            for p in points.keys():  # copy start and end point
                mesheHair["hair_settings"]["hair_uv_points"][-1][p] = points[p]
        mesheHair.hair_settings.uv_seed = self.uv_seedBackup
        uvTransform(mesheHair, hairParent)

    def modal(self, context, event):
        context.area.tag_redraw()
        mesheHair = None
        if context.active_object.type == 'MESH':
            mesheHair = context.active_object
            hairParent = bpy.data.objects[mesheHair.hair_settings.hair_mesh_parent]
        elif context.active_object.type == 'CURVE':
            hairParent = context.active_object
            mesheHair = bpy.data.objects[hairParent.hair_settings.hair_curve_child]
        if event.type == 'MOUSEMOVE':
            self.mouse_pos = [event.mouse_region_x, event.mouse_region_y]

        elif event.type == 'LEFTMOUSE' and self.LMB_Clicked == True:  # finish drawing box, and calculate uv Transformation
            self.first_point_painted = True
            region = context.region
            x, y = region.view2d.region_to_view(self.mouse_pos[0], self.mouse_pos[1])  # vies space to UV (0,1 space)
            mesheHair.hair_settings.hair_uv_points[-1].end_point = [x, y]
            self.LMB_Clicked = False
            if self._handle:
                bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
            args = (self, context, mesheHair.hair_settings.hair_uv_points, False)
            self._handle = bpy.types.SpaceImageEditor.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            mesheHair.hair_settings.uv_seed = self.Seed
            uvTransform(mesheHair, hairParent)
        elif event.type == 'LEFTMOUSE' and self.LMB_Clicked == False:
            # Add the region OpenGL drawing callback
            # draw in view space with 'POST_VIEW' and 'PRE_VIEW'
            self.first_point_painted = True
            if self._handle:
                bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
            args = (self, context,mesheHair.hair_settings.hair_uv_points,True)
            self._handle = bpy.types.SpaceImageEditor.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            self.mouse_start = [event.mouse_region_x, event.mouse_region_y]
            region = context.region
            x, y = region.view2d.region_to_view(self.mouse_pos[0], self.mouse_pos[1])  # vies space to UV (0,1 space)
            mesheHair.hair_settings.hair_uv_points.add()
            mesheHair.hair_settings.hair_uv_points[-1].start_point = [x, y]
            self.LMB_Clicked = True
        elif event.ctrl and event.type == 'Z' and event.value == 'PRESS':
            if len(mesheHair.hair_settings.hair_uv_points)>1:
                mesheHair.hair_settings.hair_uv_points.remove(len(mesheHair.hair_settings.hair_uv_points)-1)
                mesheHair.hair_settings.uv_seed = self.Seed
                uvTransform(mesheHair, hairParent)
        elif event.type == 'WHEELUPMOUSE' and event.ctrl:
            self.Seed += 1
            mesheHair.hair_settings.uv_seed = self.Seed
            uvTransform(mesheHair, hairParent)
        elif event.type == 'WHEELDOWNMOUSE' and event.ctrl:
            self.Seed -= 1
            mesheHair.hair_settings.uv_seed = self.Seed
            uvTransform(mesheHair, hairParent)
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            # allow navigation
            return {'PASS_THROUGH'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self._handle:
                bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
            self.manualUndo( mesheHair, hairParent)
            self.report({'INFO'}, 'CANCELLED')
            return {'CANCELLED'}
        elif event.type in {'NUMPAD_ENTER', 'RET'}:
            if self._handle:
                bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
            if not self.first_point_painted:
                self.manualUndo( mesheHair, hairParent)
                self.report({'INFO'}, 'Finished')
            context.scene.last_hair_settings.hair_uv_points.clear()
            for uvPoint in mesheHair.hair_settings.hair_uv_points:
                context.scene.last_hair_settings.hair_uv_points.add()
                context.scene.last_hair_settings.hair_uv_points[-1].start_point = uvPoint.start_point
                context.scene.last_hair_settings.hair_uv_points[-1].end_point = uvPoint.end_point
                # ipdb.set_trace()
            mesheHair.hair_settings.uv_seed = self.Seed
            uvTransform(mesheHair, hairParent)
            self.report({'INFO'}, 'Finished')
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'IMAGE_EDITOR':
            mesheHair = context.active_object
            if mesheHair.type !='MESH':
                self.report({'WARNING'}, "Operator works only on mesh ribbons! Cancelling")
                return {'CANCELLED'}

            self.first_point_painted = False
            # the arguments we pass the the callback
            # manual undo begin backup
            self.UVBackup.clear()
            self.uv_seedBackup = mesheHair.hair_settings.uv_seed
            for point in mesheHair["hair_settings"]["hair_uv_points"]:
                self.UVBackup.append({'start_point':[point['start_point'][0],point['start_point'][1]],
                                      'end_point':[point['end_point'][0],point['end_point'][1]]})
            mesheHair.hair_settings.hair_uv_points.clear()
            self.LMB_Clicked = False
            self.mouse_pos = []
            self.report({'INFO'}, 'Draw box shape in UV editor')
            self.Seed = mesheHair.hair_settings.uv_seed
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "You must run this operator in UV editor! Cancelling")
            return {'CANCELLED'}


__face_to_verts = defaultdict(set)
__vert_to_faces = defaultdict(set)

def __parse_island(bm, face_idx, faces_left, island):
    if face_idx in faces_left:
        faces_left.remove(face_idx)
        island.append(bm.faces[face_idx])
        for v in __face_to_verts[face_idx]:
            connected_faces = __vert_to_faces[v]
            if connected_faces:
                for cf in connected_faces:
                    __parse_island(bm, cf, faces_left, island)

def __get_island(bm):
    uv_island_lists = []
    faces_left = set(__face_to_verts.keys())
    while len(faces_left) > 0:
        current_island = []
        face_idx = list(faces_left)[0]
        __parse_island(bm, face_idx, faces_left, current_island)
        uv_island_lists.append(current_island)
    return uv_island_lists


def uvTransform(hairMesh, parentCurveHair, firstTime=False):
    # print('UV transform method')
    imgBackup = None
    for area in bpy.context.screen.areas:
        if area.type == 'IMAGE_EDITOR':
            if area.spaces.active.image:
                imgBackup = area.spaces.active.image
    uvBoxes = len(hairMesh.hair_settings.hair_uv_points)
    if uvBoxes==0: #if no uv box, then initialize with empty or last used
        firstTime = True
    if firstTime: #first time use last known settings
        hairMesh.hair_settings.hair_uv_points.clear()
        if len(bpy.context.scene.last_hair_settings.hair_uv_points)==0: #set to defaults 00 11
            bpy.context.scene.last_hair_settings.hair_uv_points.add()
            bpy.context.scene.last_hair_settings.hair_uv_points[-1].start_point = [0,0]
            bpy.context.scene.last_hair_settings.hair_uv_points[-1].end_point = [1,1]
        for uvPair in  bpy.context.scene.last_hair_settings.hair_uv_points:
            hairMesh.hair_settings.hair_uv_points.add()
            hairMesh.hair_settings.hair_uv_points[-1].start_point = uvPair.start_point
            hairMesh.hair_settings.hair_uv_points[-1].end_point = uvPair.end_point
    # ipdb.set_trace()
    uvBoxes = len(hairMesh.hair_settings.hair_uv_points)
    np.random.seed(hairMesh.hair_settings.uv_seed)
    meCurv = parentCurveHair.to_mesh(bpy.context.scene, False, 'PREVIEW')
    meCurv.uv_textures.new('HairTool_UV')  # for vert veights and colors helper layer add secpnd uv's
    me = hairMesh.data  # will write bmesh from curves to this output mesh hair

    global __face_to_verts, __vert_to_faces  #helpers for geting uv islands
    __face_to_verts = defaultdict(set)
    __vert_to_faces = defaultdict(set)

    bm = bmesh.new()
    bm.from_mesh(meCurv)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.verify()

    for f in bm.faces:
        for l in f.loops:
            id = l[uv_layer].uv.to_tuple(5), l.vert.index
            __face_to_verts[f.index].add(id)
            __vert_to_faces[id].add(f.index)


    uv_island_lists = __get_island(bm)  #get uv islands for randomizing each island transformation if required

    uv_layer = bm.loops.layers.uv.active
    # ipdb.set_trace()
    # bm.faces.layers.tex.verify()  # currently blender needs both layers.
    addon_prefs = bpy.context.user_preferences.addons['hair_tool'].preferences
    for island in uv_island_lists:
        if uvBoxes>=2:
            BoxIndex = np.random.randint(uvBoxes) # get random uv space for each island
        else:
            BoxIndex=0
        RandomFlipX =False
        if addon_prefs.flipUVRandom:
            RandomFlipX = True if np.random.randint(2)==1 else False
        x1, y1 = hairMesh.hair_settings.hair_uv_points[BoxIndex].start_point
        x2, y2 = hairMesh.hair_settings.hair_uv_points[BoxIndex].end_point
        for f in island:
            for l in f.loops:
                x, y = l[uv_layer].uv
                xOut = y * (x2 - x1) + x1  # rot -90, scale , translate
                yOut = -x * (y1 - y2) + y1
                if RandomFlipX:
                    xOut = -xOut + x1 + x2
                l[uv_layer].uv = xOut, yOut

    uv_layer2 = bm.loops.layers.uv[1] #rotate second uv (help uvs)
    for f in bm.faces:
        for l in f.loops:
            x, y = l[uv_layer2].uv
            l[uv_layer2].uv = y, x # rot -90
    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    bm.to_mesh(me)
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)

    bpy.ops.mesh.select_all(action='SELECT')
    me.update()
    if imgBackup:
        for area in bpy.context.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = imgBackup

def uvCopyPaste(hairMesh, parentCurveHair):
    print('UV copy method')
    meCurv = parentCurveHair.to_mesh(bpy.context.scene, False, 'PREVIEW')
    bmCurv = bmesh.new()
    bmCurv.from_mesh(meCurv)
    uv_layer_curve = bmCurv.loops.layers.uv.active

    meHair = hairMesh.data
    bmOldHairMesh = bmesh.new()
    bmOldHairMesh.from_mesh(meHair)
    uv_layer_old_hair = bmOldHairMesh.loops.layers.uv.active
    uvSource = []
    for face in bmOldHairMesh.faces:
        uvSource.append([l[uv_layer_old_hair].uv.copy() for l in face.loops])

    for i, f in enumerate(bmCurv.faces):
        suv = uvSource[i % len(uvSource)]  # M:N strategy
        for l, uv in zip(f.loops, suv):
            l[uv_layer_curve].uv = uv

    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    bmCurv.to_mesh(hairMesh.data)
    # meHair.update()
    bmCurv.free()
    bmOldHairMesh.free()
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)


class GenerateRibbons(bpy.types.Operator):
    bl_label = "Add ribbons"
    bl_idname = "object.generate_ribbons"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Add ribbon to curve profile"

    strandResU = IntProperty(name="Segments U", default=3, min=1, max=5, description="Additional subdivision along strand length")
    strandResV = IntProperty(name="Segments V", default=2, min=1, max=5, description="Subdivisions perpendicular to strand length ")
    strandWidth = FloatProperty(name="Strand Width", default=0.5, min=0.0, max=10)
    strandPeak = FloatProperty(name="Strand peak", default=0.4, min=0.0, max=1,
                               description="Describes how much middle point of ribbon will be elevated")
    strandUplift = FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")
    alignToSurface = BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    diagonal  = 0
    # @classmethod
    # def poll(cls, context):  #breaks undo
    #     return context.active_object.type == 'CURVE'  # bpy.context.scene.render.engine == "CYCLES"

    def invoke(self,context, event):
        if context.active_object.type != 'CURVE':
            self.report({'INFO'}, 'Select curve object first')
            return {"CANCELLED"}
        hairCurve = context.active_object
        # unitsScale = 1 #context.scene.unit_settings.scale_length
        self.diagonal = math.sqrt(pow(hairCurve.dimensions[0], 2) + pow(hairCurve.dimensions[1], 2) + pow(hairCurve.dimensions[2], 2))  # to normalize some values
        bevelObj = hairCurve.data.bevel_object
        if bevelObj:
            points = bevelObj.data.splines[0].points[:]
            self.strandResV = len(points)-1
            self.strandResU = hairCurve.data.resolution_u
        return  self.execute(context)


    def execute(self, context):

        hairCurve = context.active_object
        pointsCo = []
        if self.diagonal==0:
            diagonal = math.sqrt(pow(hairCurve.dimensions[0], 2) + pow(hairCurve.dimensions[1], 2) + pow(hairCurve.dimensions[2], 2))  # to normalize some values
        else:
            diagonal = self.diagonal
        # print("diagonal is :" + str(diagonal))
        # unitsScale = 1 #context.scene.unit_settings.scale_length

        strandWidth = self.strandWidth / 10  * diagonal
        for i in range(self.strandResV + 1):
            x = 2 * i / self.strandResV - 1  # normalise and map from -1 to 1
            pointsCo.append((x * strandWidth , ((1 - x * x) * self.strandPeak + self.strandUplift) * strandWidth  , 0))  # **self.strandWidth to mantain proportion while changing widht
        # create the Curve Datablock
        if hairCurve.data.bevel_object:
            curveBevelObj = hairCurve.data.bevel_object
            curveBevelObj.data.splines.clear()
            BevelCurveData = curveBevelObj.data
        else:
            BevelCurveData = bpy.data.curves.new('hairBevelCurve', type='CURVE')  # new CurveData
            BevelCurveData.dimensions = '2D'
            curveBevelObj = bpy.data.objects.new('bevelCurve', BevelCurveData)  # new object
            hairCurve.data.bevel_object = curveBevelObj
        bevelSpline = BevelCurveData.splines.new('POLY')  # new spline
        bevelSpline.points.add(len(pointsCo) - 1)
        for i, coord in enumerate(pointsCo):
            x, y, z = coord
            bevelSpline.points[i].co = (x, y, z, 1)
        curveBevelObj.use_fake_user = True

        hairCurve.data.resolution_u = self.strandResU
        hairCurve.data.use_auto_texspace = True
        hairCurve.data.use_uv_as_generated = True
        hairCurve.data.show_normal_face = False
        if self.alignToSurface:
            context.scene.objects.active = hairCurve
            bpy.ops.object.curves_align_tilt(onlySelection=False)

        return {"FINISHED"}


class CurvesToRibbons(bpy.types.Operator):
    bl_label = "Curve ribbons to mesh ribbons"
    bl_idname = "object.curve_edit"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = 'Convert curve to mesh object'

    hairUvMethod = bpy.props.EnumProperty(name="Hair UV Method", default="0",
                                          items=(("0", "BOX UV", ""),
                                                 ("1", "Preserve UV", "")))
    Seed = IntProperty(name="Noise Seed", default=1, min=1, max=1000)

    def invoke(self,context, event):
        curveHairs = context.active_object
        if curveHairs.type == "CURVE":
            if curveHairs.hair_settings.hair_curve_child != '':  # only if child mesh exist
                childStripMeshObj = bpy.data.objects[context.active_object.hair_settings.hair_curve_child]
                self.Seed = childStripMeshObj.hair_settings.uv_seed
        else:
            self.report({'INFO'}, 'You need to select curve ribbon object first')
            return {"CANCELLED"}
        return  self.execute(context)

    def convert_curve(self,childHairMesh, parentCurveHair):
        parentCurveHair.hair_settings.hairUvMethod=self.hairUvMethod #backup uv method in obj settings for next call
        if parentCurveHair.hair_settings.hairUvMethod == '0':
            childHairMesh.hair_settings.uv_seed = self.Seed
            uvTransform(childHairMesh, parentCurveHair)
        elif parentCurveHair.hair_settings.hairUvMethod == '1':
            uvCopyPaste(childHairMesh, parentCurveHair)

    def createMeshFromCurve(self,parentCurve):
        meshFromCurve = parentCurve.to_mesh(bpy.context.scene, False, 'PREVIEW')
        meshObjFromCurve = bpy.data.objects.new(parentCurve.name + "mesh", meshFromCurve)
        bpy.context.scene.objects.link(meshObjFromCurve)
        meshObjFromCurve.select = True
        lastMat=bpy.context.scene.last_hair_settings.material
        if lastMat:
            if lastMat in bpy.data.materials.keys():
                meshObjFromCurve.data.materials.append(bpy.data.materials[lastMat])
        bpy.context.scene.objects.active = meshObjFromCurve
        meshObjFromCurve.use_fake_user = False
        meshObjFromCurve.hair_settings.hair_mesh_parent = parentCurve.name
        parentCurve.hair_settings.hair_curve_child = meshObjFromCurve.name
        meshObjFromCurve.matrix_world = parentCurve.matrix_world
        bpy.context.scene.objects.unlink(parentCurve)
        parentCurve.use_fake_user = True
        meshObjFromCurve.hair_settings.uv_seed = self.Seed
        uvTransform(meshObjFromCurve, parentCurve, True)

    def execute(self, context):
        curveHairs = context.active_object
        mode = curveHairs.mode
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        if curveHairs.hair_settings.hair_curve_child == '':  # no child mesh, then create new one
            self.createMeshFromCurve(curveHairs)
        else:  # else switch to editing child hair mesh obj and transfer spline changes to mesh
            if curveHairs.hair_settings.hair_curve_child in bpy.data.objects.keys():
                childStripMeshObj = bpy.data.objects[curveHairs.hair_settings.hair_curve_child]
                if childStripMeshObj.name not in context.scene.objects.keys(): #link mesh obj to scene
                    context.scene.objects.link(childStripMeshObj)
                    childStripMeshObj.hide = False
                    childStripMeshObj.use_fake_user = False
                    context.scene.objects.active = childStripMeshObj
                    self.convert_curve(childStripMeshObj, curveHairs)
                    curveHairs.use_fake_user = True
                    context.scene.objects.unlink(curveHairs)
                    childStripMeshObj.select = True
                    bpy.context.scene.objects.active = childStripMeshObj
                    childStripMeshObj.matrix_world = curveHairs.matrix_world
                    childStripMeshObj.hair_settings.hair_mesh_parent = curveHairs.name  # set parent in just in case curve name was changed
                else: #was already in scene, probbably cos source was duplicated? create new one
                    self.createMeshFromCurve(curveHairs)
            else:
                self.createMeshFromCurve(curveHairs)
        bpy.ops.object.mode_set(mode=mode, toggle=False)

        return {"FINISHED"}


class RibbonsToCurve(bpy.types.Operator):
    bl_label = "Mesh ribbons to curve ribbons"
    bl_idname = "object.ribbon_edit"
    bl_description = "Revert hair mesh to curve object type"
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        stripMeshObj = context.active_object
        mode = stripMeshObj.mode
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        if stripMeshObj.type == "MESH":
            if stripMeshObj.hair_settings.hair_mesh_parent:  # switch to spline hair obj
                if stripMeshObj.hair_settings.hair_mesh_parent in bpy.data.objects.keys():
                    splineHair = bpy.data.objects[stripMeshObj.hair_settings.hair_mesh_parent]
                    if splineHair.name not in bpy.context.scene.objects.keys():
                        context.scene.objects.link(splineHair)
                    else:  #possibly already linked becaouse mesh ribbon was duplicated, then duplicate source curve too
                        splineHair = splineHair.copy()  # copies dupli_group property(empty), but group property is empty (users_group = None)
                        stripMeshObj.hair_settings.hair_mesh_parent = splineHair.name
                        splineHair.data = splineHair.data.copy()
                        splineHair.select = True
                        context.scene.objects.link(splineHair)
                    splineHair.matrix_world = stripMeshObj.matrix_world
                    splineHair.use_fake_user = False
                    stripMeshObj.use_fake_user = True
                    context.scene.objects.unlink(stripMeshObj)  # hide mesh object
                    if stripMeshObj.data.materials:
                        bpy.context.scene.last_hair_settings.material = stripMeshObj.data.materials[0].name
                    bpy.context.scene.objects.active = splineHair
                    splineHair.hair_settings.hair_curve_child = stripMeshObj.name  # set child in just in case curve name was changed
        bpy.ops.object.mode_set(mode=mode, toggle=False)

        return {"FINISHED"}

class GenerateWeight(bpy.types.Operator):
    bl_label = "Add ribbon weights"
    bl_idname = "object.ribbon_weight"
    bl_description = "Add vertex weights to ribbons mesh"
    bl_options = {"REGISTER", "UNDO"}

    gradientFalloff = FloatProperty(name="Gradient Falloff", description="Gradient Falloff", default=0,
                                    min=-1, max=1, subtype='PERCENTAGE')

    def execute(self, context):
        ribbonMesh = context.active_object
        if len(ribbonMesh.data.uv_layers)<2:
            self.report({'INFO'}, 'No second UV channel found!')
            return {"CANCELLED"}
        vg = ribbonMesh.vertex_groups.new('gradient')
        vertUV = {}
        cpow = calc_power(self.gradientFalloff)
        for face in ribbonMesh.data.polygons:
            for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                uv_coords = ribbonMesh.data.uv_layers[1].data[loop_idx].uv
                vertUV[vert_idx]= (uv_coords.x, uv_coords.y)

        for vert in ribbonMesh.data.vertices:
            x,y = vertUV[vert.index]
            weight = abs(max(min(1 - y, 1), 0))  # d over box height
            w2 = math.pow(weight, cpow)
            vg.add([vert.index],w2 , "ADD")
        self.report({'INFO'}, 'Vertex weights have been generated')
        bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        return {"FINISHED"}

class GenerateVerColorGradient(bpy.types.Operator):
    bl_label = "Add vertex colors gradient to ribbons"
    bl_idname = "object.ribbon_vert_color_grad"
    bl_description = "Add vertex color gradient to ribbons"
    bl_options = {"REGISTER", "UNDO"}

    createNewVC = BoolProperty(name="Add new VColor", description="Adds new vertex color layer instead of overriding active one", default=False)
    gradientFalloff = FloatProperty(name="Gradient Falloff", description="Gradient Falloff", default=0,
                                  min=-1, max=1, subtype='PERCENTAGE')

    def execute(self, context):
        ribbonMesh = context.active_object
        if len(ribbonMesh.data.uv_layers)<2:
            self.report({'INFO'}, 'No second UV channel found!')
            return {"CANCELLED"}
        mesh = ribbonMesh.data
        if not mesh.vertex_colors or self.createNewVC:
            mesh.vertex_colors.new("Gradient")

        # color_layer = mesh.vertex_colors["Col"]
        # or you could avoid using the color_layer name
        if self.createNewVC:
            color_layer = ribbonMesh.data.vertex_colors[-1]
        else:
            color_layer = mesh.vertex_colors.active
        cpow = calc_power(self.gradientFalloff)
        for face in ribbonMesh.data.polygons:
            for loop_idx in face.loop_indices:
                x,y = ribbonMesh.data.uv_layers[-1].data[loop_idx].uv
                col = abs(max(min(y, 1), 0))
                col2 = math.pow(col, cpow)
                color_layer.data[loop_idx].color = [col2,col2,col2]

        self.report({'INFO'}, 'Vertex colors have been generated')
        if self.createNewVC:
            ribbonMesh.data.vertex_colors.active = ribbonMesh.data.vertex_colors[-1]
        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        return {"FINISHED"}

class GenerateVerColorRandom(bpy.types.Operator):
    bl_label = "Add random vertex colors per ribbon"
    bl_idname = "object.ribbon_vert_color_random"
    bl_description = "Makes each ribbon vertex color unique"
    bl_options = {"REGISTER", "UNDO"}

    Seed = IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    mergeSimilar = BoolProperty(name="Merge Similar", description="Merge Simila", default=False)
    createNewVC = BoolProperty(name="Add new VColor", description="Adds new vertex color layer instead of overriding active one", default=False)


    def execute(self, context):
        np.random.seed(self.Seed)
        obj = bpy.context.active_object
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)  # Go to edit mode
        bpy.ops.mesh.select_all(action="DESELECT")  # unselect everything

        bm = bmesh.from_edit_mesh(obj.data)  # load mesh
        bm.faces.ensure_lookup_table()

        if self.createNewVC or not obj.data.vertex_colors:
            obj.data.vertex_colors.new("Random Color")

        if self.createNewVC:
            color_layer =bm.loops.layers.color[-1]
        else:
            color_layer =bm.loops.layers.color.active

        faceIslandsList = []
        faces = bm.faces

        while faces:
            faces[0].select_set(True)  # select 1st face
            bpy.ops.mesh.select_linked()  # select all linked faces makes a full loop
            faceIslandsList.append([f for f in faces if f.select])
            bpy.ops.mesh.hide(unselected=False)  # hide the detected loop
            faces = [f for f in bm.faces if not f.hide]  # update faces

        bpy.ops.mesh.reveal()  # unhide all faces
        islandColor = {} #dictt will contain faceCount : Color pairs
        for facesIsland in faceIslandsList: # face islands list
            if self.mergeSimilar:
                islandFaceCount = len(facesIsland)
                if islandFaceCount in islandColor.keys():
                    random_color = islandColor[islandFaceCount]
                else:
                    random_color = np.random.random_sample(3).tolist()
                    islandColor[islandFaceCount] = random_color  #asign faceCount : Color"
            else:
                random_color = np.random.random_sample(3).tolist()
            for face in facesIsland: #island faces
                for loop in face.loops:
                    loop[color_layer] = random_color

        bm.free()  # free and prevent further access
        if self.createNewVC:
            obj.data.vertex_colors.active = obj.data.vertex_colors[-1]
        self.report({'INFO'}, 'Vertex colors have been generated')
        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        return {"FINISHED"}

# class CleanupUnusedHair(bpy.types.Operator):
#     bl_label = "Cleanup Hair data"
#     bl_idname = "object.cleanup_hair"
#     bl_description = "Cleanup unused Hair data. Cleans Orphans in blend file. Use with caution!"
#     bl_options = {"REGISTER", "UNDO"}
#
#
#     def execute(self, context):
#         curveHairs = []
#         meshRibbons = []
#         bevelCurve = []
#         hairOrphantObjs = [obj for obj in bpy.data.objects if obj.users == 1 and obj.use_fake_user and (obj.hair_settings.hair_mesh_parent != '' or obj.hair_settings.hair_curve_child != '')]
#         bevelObjs = [obj for obj in hairOrphantObjs if 'bevelCurve' in obj.name]
#         # __import__('code').interact(local={k: v for ns in (globals(), locals()) for k, v in ns.items()})
#         for obj in context.scene.objects: #what if in group? it is not in scene but may be still used...
#             if obj.hair_settings.hair_mesh_parent != '':
#                 curveHairs.append(obj.hair_settings.hair_mesh_parent)
#             if obj.hair_settings.hair_curve_child != '':
#                 meshRibbons.append(obj.hair_settings.hair_curve_child)
#             if obj.type == 'Curve' and obj.data.bevel_object is not None:
#                 bevelCurve.append(obj.data.bevel_object.name)
#         usedObjs = curveHairs + meshRibbons + bevelCurve
#         for orphan in hairOrphantObjs + bevelObjs :
#             if orphan.name not in usedObjs:
#                 print('Object removed: ' + orphan.name)
#                 orphan.use_fake_user = False
#                 bpy.data.objects.remove(orphan)
#
#         return {"FINISHED"}
