bl_info = {
    "name": "Bookmark View",
    "author": "Wayne Dixon",
    "version": (0, 1, 3),
    "blender": (2, 77, 0),
    "location": "Toolshelf > Layers > Bookmarked Views",
    "warning": "",
    "description": "Bookmark and restore 3d views",
    "wiki_url": "",
    "category": "3D View",
}

import bpy
from bpy.types import PropertyGroup, Panel, UIList, Menu
from bpy.props import FloatProperty, CollectionProperty, FloatVectorProperty, IntProperty, StringProperty, BoolProperty, EnumProperty


class bm_view(PropertyGroup):
    # add property to Scene to store the view data
    view_location = FloatVectorProperty(name="Location",
                                        description="location",
                                        default=(0.0, 0.0, 0.0))
    view_rotation = FloatVectorProperty(name="Rotation",
                                        description="rotation",
                                        size=4,
                                        default=(0.0, 0.0, 0.0, 0.0))
    view_distance = FloatProperty(name="Distance", description="distance", default=10.0)
    viewport_shade = StringProperty(name='Shading Mode')
    view_perspective = StringProperty(name='Perspective')
    locked = BoolProperty(name="Locked")


class SCENE_OT_bm_view_add(bpy.types.Operator):
    """Bookmark the current current view"""
    bl_idname = "scene.bm_view_add"
    bl_label = "Bookmark view"

    def execute(self, context):
        # find the current region id
        region_id = bpy.context.region.id

        # this will loop through the areas and match the view with the same id
        for area in bpy.context.screen.areas:
            for region in area.regions:
                if region.id == region_id:
                    view = area.spaces[0]

        my_view = bpy.context.scene.bm_view.add()
        my_view.name = 'View%.2d' % len(bpy.context.scene.bm_view)
        my_view.view_location = view.region_3d.view_location
        my_view.view_rotation = view.region_3d.view_rotation
        my_view.view_distance = view.region_3d.view_distance
        my_view.viewport_shade = view.viewport_shade
        my_view.view_perspective = view.region_3d.view_perspective

        # if the viewport is locked it won't behave properly
        lock_cursor = view.lock_cursor
        lock_object = view.lock_object
        if lock_cursor or lock_object:
            self.report({'INFO'}, 'Viewport locked! May not behave as planned.')
        return {'FINISHED'}


class SCENE_OT_bm_view_replace(bpy.types.Operator):
    """Replace the selected bookmark"""
    bl_idname = "scene.bm_view_replace"
    bl_label = "Replace the current Bookmarked view"

    view_idx = IntProperty()

    @classmethod
    def poll(self, context):
        """Enable if there's something in the list """
        return len(context.scene.bm_view) > 0

    def execute(self, context):
        bm_view = bpy.context.scene.bm_view
        view_idx = self.view_idx
        use_shading = bpy.context.scene.bm_view_use_shading

        # find the current region id
        region_id = bpy.context.region.id

        # this will loop through the areas and match the view with the same id
        for area in bpy.context.screen.areas:
            for region in area.regions:
                if region.id == region_id:
                    view = area.spaces[0]

        bm_view[view_idx].view_location = view.region_3d.view_location
        bm_view[view_idx].view_rotation = view.region_3d.view_rotation
        bm_view[view_idx].view_distance = view.region_3d.view_distance
        bm_view[view_idx].view_perspective = view.region_3d.view_perspective
        bm_view[view_idx].viewport_shade = view.viewport_shade

        # if the viewport is locked it won't behave properly
        lock_cursor = view.lock_cursor
        lock_object = view.lock_object
        if lock_cursor or lock_object:
            self.report({'INFO'}, 'Viewport locked. May not behave as planned.')
        return {'FINISHED'}


class SCENE_OT_bm_view_remove(bpy.types.Operator):
    """Delete the selected bookmark"""
    bl_idname = "scene.bm_view_remove"
    bl_label = "Delete Bookmarked view"

    view_idx = IntProperty()

    @classmethod
    def poll(self, context):
        """ Enable if there's something in the list """
        return len(context.scene.bm_view) > 0

    def execute(self, context):
        scene = context.scene
        view_idx = self.view_idx

        if not scene.bm_view[view_idx].locked:
            bpy.context.scene.bm_view.remove(view_idx)
            if len(scene.bm_view) > 0 and view_idx != 0:
                bpy.context.scene.bm_view_index = view_idx - 1
        return {'FINISHED'}


class SCENE_OT_bm_view_remove_all(bpy.types.Operator):
    """Delete all the bookmarked views"""
    bl_idname = "scene.bm_view_remove_all"
    bl_label = "Delete All Bookmarked Views"

    @classmethod
    def poll(self, context):
        """ Enable if there's something in the list """
        return len(context.scene.bm_view) > 0

    def execute(self, context):
        scene = context.scene

        for i in range(len(context.scene.bm_view) - 1, -1, -1):
            bpy.context.scene.bm_view.remove(i)
        return {'FINISHED'}


class SCENE_OT_bm_view_lock(bpy.types.Operator):
    """Lock functions for the bookmarked views"""
    bl_idname = "scene.bm_view_lock"
    bl_label = "Unlock all the bookmarked views"

    action = EnumProperty(
            items=(
                ('LOCK', 'Lock', ""),
                ('UNLOCK', 'Unlock', ""),
                ('INVERT', 'Invert', ""),))

    @classmethod
    def poll(self, context):
        """ Enable if there's something in the list """
        return len(context.scene.bm_view) > 0

    def execute(self, context):
        scene = context.scene
        action = self.action

        if action == 'LOCK':
            for i in range(len(context.scene.bm_view)):
                bpy.context.scene.bm_view[i].locked = True

        elif action == 'UNLOCK':
            for i in range(len(context.scene.bm_view)):
                bpy.context.scene.bm_view[i].locked = False

        elif action == 'INVERT':
            for i in range(len(context.scene.bm_view)):
                bpy.context.scene.bm_view[i].locked = not bpy.context.scene.bm_view[i].locked

        else:
            return{'CANCELLED'}

        return{'FINISHED'}


class SCENE_OT_bm_view_restore(bpy.types.Operator):
    """Restore a bookmarked view"""
    bl_idname = "scene.bm_view_restore"
    bl_label = "Restore Bookmarked View"

    view_idx = IntProperty()

    def execute(self, context):
        bm_view = bpy.context.scene.bm_view
        view_idx = self.view_idx
        use_shading = bpy.context.scene.bm_view_use_shading

        # find the current region id
        region_id = bpy.context.region.id

        # this will loop through the areas and match the view with the same id
        for area in bpy.context.screen.areas:
            for region in area.regions:
                if region.id == region_id:
                    view = area.spaces[0]

        view.region_3d.view_location = bm_view[view_idx].view_location
        view.region_3d.view_rotation = bm_view[view_idx].view_rotation
        view.region_3d.view_distance = bm_view[view_idx].view_distance
        view.region_3d.view_perspective = bm_view[view_idx].view_perspective
        if use_shading:
            view.viewport_shade = bm_view[view_idx].viewport_shade

        # if the view is locked it won't behave properly
        lock_cursor = view.lock_cursor
        lock_object = view.lock_object
        if lock_cursor or lock_object:
            self.report({'INFO'}, 'Viewport locked. May not behave as planned.')
        return {'FINISHED'}


class LIST_OT_MoveItem(bpy.types.Operator):
    """ Move Bookmark in the list """
    bl_idname = "bm_view.move_item"
    bl_label = "Move bookmark in the list"

    direction = EnumProperty(
                items=(
                    ('UP', 'Up', ""),
                    ('DOWN', 'Down', ""),))

    @classmethod
    def poll(self, context):
        """ Enable if there's something in the list. """
        return len(context.scene.bm_view) > 0

    def move_index(self):
        """Move index of a bookmark while clamping it."""
        index = bpy.context.scene.bm_view_index
        list_length = len(bpy.context.scene.bm_view) - 1  # (index starts at 0)
        new_index = 0

        if self.direction == 'UP':
            new_index = index - 1
        elif self.direction == 'DOWN':
            new_index = index + 1

        new_index = max(0, min(new_index, list_length))
        bpy.context.scene.bm_view_index = new_index

    def execute(self, context):
        bm_view = context.scene.bm_view
        index = context.scene.bm_view_index

        if self.direction == 'DOWN':
            neighbor = index + 1
            bm_view.move(index, neighbor)
            self.move_index()

        elif self.direction == 'UP':
            neighbor = index - 1
            bm_view.move(neighbor, index)
            self.move_index()
        else:
            return{'CANCELLED'}

        return{'FINISHED'}


class SCENE_UL_bm_views(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        bm_view = item

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # viewport shading icon
            if bm_view.viewport_shade == 'BOUNDBOX':
                vp_icon = 'BBOX'
            elif bm_view.viewport_shade == 'WIREFRAME':
                vp_icon = 'WIRE'
            elif bm_view.viewport_shade == 'SOLID':
                vp_icon = 'SOLID'
            elif bm_view.viewport_shade == 'TEXTURED':
                vp_icon = 'POTATO'
            elif bm_view.viewport_shade == 'MATERIAL':
                vp_icon = 'MATERIAL'
            elif bm_view.viewport_shade == 'RENDERED':
                vp_icon = 'SMOOTH'
            if not context.scene.bm_view_use_shading:
                vp_icon = 'NONE'
            layout.prop(bm_view, "name", text="", icon=vp_icon, emboss=False)

            # padlock
            icon = 'LOCKED' if bm_view.locked else 'UNLOCKED'
            emboss = True if bm_view.locked else False
            layout.prop(bm_view, "locked", text="", icon=icon, emboss=emboss)

            # restore operator
            icon = 'RESTRICT_VIEW_OFF'
            op = layout.operator("scene.bm_view_restore", text="", emboss=True, icon=icon)
            op.view_idx = index

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'


class SCENE_PT_bm_views(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category = "Layers"
    bl_label = "Bookmarked Views"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(self, context):
        return (context.area.spaces.active.type == 'VIEW_3D')

    def draw(self, context):
        scene = context.scene
        view_idx = scene.bm_view_index

        layout = self.layout
        row = layout.row()
        row.template_list("SCENE_UL_bm_views", "", scene, "bm_view", scene, "bm_view_index")

        col = row.column(align=True)
        col.operator("scene.bm_view_add", icon='ZOOMIN', text="")
        col.operator("scene.bm_view_replace", icon='ARROW_LEFTRIGHT', text="").view_idx = view_idx
        col.operator("scene.bm_view_remove", icon='ZOOMOUT', text="").view_idx = view_idx
        col.menu("SCENE_MT_bm_views_specials", icon='DOWNARROW_HLT', text="")

        col.separator()
        col.operator('bm_view.move_item', icon='TRIA_UP', text='').direction = 'UP'
        col.operator('bm_view.move_item', icon='TRIA_DOWN', text='').direction = 'DOWN'

        row = layout.row()
        row.prop(scene, "bm_view_use_shading", text="Viewport Shading")


class SCENE_MT_bm_views_specials(Menu):
    bl_label = "Bookmark View Specials"

    def draw(self, context):
        layout = self.layout
        layout.operator("scene.bm_view_remove_all", icon='X', text="Delete All Views")
        layout.separator()
        layout.operator("scene.bm_view_lock", icon='LOCKED', text="Lock All").action = 'LOCK'
        layout.operator("scene.bm_view_lock", icon='UNLOCKED', text="UnLock All").action = 'UNLOCK'
        layout.operator("scene.bm_view_lock", icon='LOCKED', text="Invert Locked").action = 'INVERT'


def register():
    bpy.utils.register_class(bm_view)
    bpy.types.Scene.bm_view = CollectionProperty(type=bm_view)
    bpy.types.Scene.bm_view_index = IntProperty(default=-1)
    bpy.types.Scene.bm_view_use_shading = BoolProperty(name="bm_view_use_shading", default=False)

    bpy.utils.register_class(SCENE_OT_bm_view_add)
    bpy.utils.register_class(SCENE_OT_bm_view_replace)
    bpy.utils.register_class(SCENE_OT_bm_view_remove)
    bpy.utils.register_class(SCENE_OT_bm_view_remove_all)
    bpy.utils.register_class(SCENE_OT_bm_view_lock)
    bpy.utils.register_class(SCENE_OT_bm_view_restore)
    bpy.utils.register_class(SCENE_UL_bm_views)
    bpy.utils.register_class(SCENE_PT_bm_views)
    bpy.utils.register_class(SCENE_MT_bm_views_specials)
    bpy.utils.register_class(LIST_OT_MoveItem)


def unregister():
    bpy.utils.unregister_class(bm_view)
    del bpy.types.Scene.bm_view
    del bpy.types.Scene.bm_view_index
    del bpy.types.Scene.bm_view_use_shading

    bpy.utils.unregister_class(SCENE_OT_bm_view_add)
    bpy.utils.unregister_class(SCENE_OT_bm_view_replace)
    bpy.utils.unregister_class(SCENE_OT_bm_view_remove)
    bpy.utils.unregister_class(SCENE_OT_bm_view_remove_all)
    bpy.utils.unregister_class(SCENE_OT_bm_view_lock)
    bpy.utils.unregister_class(SCENE_OT_bm_view_restore)
    bpy.utils.unregister_class(SCENE_UL_bm_views)
    bpy.utils.unregister_class(SCENE_PT_bm_views)
    bpy.utils.unregister_class(SCENE_MT_bm_views_specials)
    bpy.utils.unregister_class(LIST_OT_MoveItem)

if __name__ == "__main__":
    register()
