import bpy
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty


class CurvesRadius(bpy.types.Operator):
    bl_label = "Select tips/roots"
    bl_idname = "curve.select_tips"
    bl_description = "Select tips/roots"
    bl_options = {"REGISTER", "UNDO"}

    Randomize = BoolProperty(name="Randomize selection", description="Randomize strand length", default=False)
    roots = BoolProperty(name="Roots", description="Roots", default=False)
    seed = IntProperty(name="Seed", default=2, min=1, max=20)
    percentage = IntProperty(name="Percentage", description="Selection percent", default=50, min=0,
                                   max=100, subtype='PERCENTAGE')

    def check(self, context): #DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'Randomize')

        if self.Randomize:
            layout.prop(self, 'seed')
            layout.prop(self, 'percentage')

    def execute(self, context):
        selectedCurves = context.active_object
        if selectedCurves.type != 'CURVE':
            self.report({'INFO'}, 'Works only on curves')
            return {"CANCELLED"}
        bpy.ops.curve.select_all(action='DESELECT')

        index = 0 if self.roots else -1
        curveData = selectedCurves.data
        for polyline in curveData.splines:  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                if not polyline.points[index].hide:
                    polyline.points[index].select = True
            else:
                if not polyline.bezier_points[index].select:
                    polyline.bezier_points[index].select = True
        if self.Randomize:
            bpy.ops.curve.select_random(percent=100-self.percentage, seed=self.seed, action='DESELECT')
        return {"FINISHED"}

