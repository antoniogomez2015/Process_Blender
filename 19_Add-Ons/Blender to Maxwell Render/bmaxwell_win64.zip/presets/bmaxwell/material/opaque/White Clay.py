import bpy

opaque = bpy.context.object.active_material.maxwell.opaque

opaque.color = (0.862745, 0.862745, 0.862745)
opaque.color_map_enabled = False
opaque.shininess = 40.0
opaque.shininess_map_enabled = False
opaque.roughness = 25.0
opaque.roughness_map_enabled = False
opaque.clearcoat = False
