import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 1.5
translucent.ior = 1.3
translucent.color = (242/255, 234/255, 217/255)
translucent.color_map_enabled = False
translucent.hue_shift = 0.0
translucent.invert_hue = True
translucent.vibrance = 7.0
translucent.density = 90.0
translucent.opacity = 75.0
translucent.roughness = 20.0
translucent.roughness_map_enabled = False
translucent.specular_tint = 0.0
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
