import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 0.2
translucent.ior = 1.3
translucent.color = (236/255, 220/255, 122/255)
translucent.color_map_enabled = False
translucent.hue_shift = 19
translucent.invert_hue = False
translucent.vibrance = 10.0
translucent.density = 20.0
translucent.opacity = 50.0
translucent.roughness = 35.0
translucent.roughness_map_enabled = False
translucent.specular_tint = 20.0
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
