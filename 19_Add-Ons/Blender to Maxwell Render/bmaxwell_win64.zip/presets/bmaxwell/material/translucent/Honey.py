import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 0.7
translucent.ior = 1.3
translucent.color = (191/255, 121/255, 10/255)
translucent.color_map_enabled = False
translucent.hue_shift = 0.0
translucent.invert_hue = False
translucent.vibrance = 30.0
translucent.density = 20.0
translucent.opacity = 50.0
translucent.roughness = 0.0
translucent.roughness_map_enabled = False
translucent.specular_tint = 0.0
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
