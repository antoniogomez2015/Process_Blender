import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 8.0
translucent.ior = 1.3
translucent.color = (250/255, 245/255, 230/255)
translucent.color_map_enabled = False
translucent.hue_shift = 0
translucent.invert_hue = True
translucent.vibrance = 11.0
translucent.density = 90.0
translucent.opacity = 50.0
translucent.roughness = 17.0
translucent.roughness_map_enabled = False
translucent.specular_tint = 0.0
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
