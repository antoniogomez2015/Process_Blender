import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 0.2
translucent.ior = 1.3
translucent.color = (90/255, 1/255, 4/255)
translucent.color_map_enabled = False
translucent.hue_shift = 0.0
translucent.invert_hue = False
translucent.vibrance = 25.0
translucent.density = 40.0
translucent.opacity = 50.0
translucent.roughness = 40.0
translucent.roughness_map_enabled = False
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
