import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 0.8
translucent.ior = 1.3
translucent.color = (232/255, 169/255, 52/255)
translucent.color_map_enabled = False
translucent.hue_shift = 34
translucent.invert_hue = False
translucent.vibrance = 45.0
translucent.density = 50.0
translucent.opacity = 50.0
translucent.roughness = 0.0
translucent.roughness_map_enabled = False
translucent.specular_tint = 20.0
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
