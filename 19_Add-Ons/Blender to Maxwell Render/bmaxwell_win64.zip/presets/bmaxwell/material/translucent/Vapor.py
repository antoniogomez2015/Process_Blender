import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 1.0
translucent.ior = 1.001
translucent.color = (1.0, 1.0, 1.0)
translucent.color_map_enabled = False
translucent.hue_shift = 0.0
translucent.invert_hue = False
translucent.vibrance = 0.0
translucent.density = 30.0
translucent.opacity = 50.0
translucent.roughness = 0.0
translucent.roughness_map_enabled = False
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
