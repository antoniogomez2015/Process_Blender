import bpy

translucent = bpy.context.object.active_material.maxwell.translucent

translucent.scale = 1.0
translucent.ior = 1.3
translucent.color = (200/255, 233/255, 2/255)
translucent.color_map_enabled = False
translucent.hue_shift = 10.0
translucent.invert_hue = False
translucent.vibrance = 10.0
translucent.density = 50.0
translucent.opacity = 50.0
translucent.roughness = 30.0
translucent.roughness_map_enabled = False
translucent.clearcoat = False
translucent.clearcoat_ior = 1.3
