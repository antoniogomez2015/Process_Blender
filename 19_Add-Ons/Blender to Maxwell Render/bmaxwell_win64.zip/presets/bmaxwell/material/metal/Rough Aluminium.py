import bpy

metal = bpy.context.object.active_material.maxwell.metal

metal.ior = '0'
metal.tint = 0.0
metal.color = (167/255, 167/255, 168/255)
metal.color_map_enabled = False
metal.roughness = 70.0
metal.roughness_map_enabled = False
metal.anisotropy = 0.0
metal.anisotropy_map_enabled = False
metal.angle = 0.0
metal.angle_map_enabled = False
metal.dust = 30.0
metal.dust_map_enabled = False
