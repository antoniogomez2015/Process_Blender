import bpy

metal = bpy.context.object.active_material.maxwell.metal

metal.ior = '8'
metal.tint = 0.0
metal.color = (1.0, 1.0, 1.0)
metal.color_map_enabled = False
metal.roughness = 0.0
metal.roughness_map_enabled = False
metal.anisotropy = 0.0
metal.anisotropy_map_enabled = False
metal.angle = 0.0
metal.angle_map_enabled = False
metal.dust = 10.0
metal.dust_map_enabled = False
