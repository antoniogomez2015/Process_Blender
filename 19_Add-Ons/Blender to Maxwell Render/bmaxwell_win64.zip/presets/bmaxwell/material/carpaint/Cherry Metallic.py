import bpy

carpaint = bpy.context.object.active_material.maxwell.carpaint

carpaint.color = (100/255, 0/255, 16/255)
carpaint.metallic = 100.0
carpaint.topcoat = 50.0
