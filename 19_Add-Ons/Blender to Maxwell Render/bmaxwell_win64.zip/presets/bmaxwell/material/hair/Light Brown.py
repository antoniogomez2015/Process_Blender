import bpy

mx = bpy.context.object.active_material.maxwell
mx['hair'].clear()
hair = mx.hair

hair.color_map = "hairTex_lightBrown"
hair.color_map_enabled = True
hair.primary_strength = 55.0
hair.primary_spread = 40.0
hair.secondary_strength = 55.0
hair.secondary_spread = 55.0
hair.secondary_tint = (160/255, 116/135, 86/255)
