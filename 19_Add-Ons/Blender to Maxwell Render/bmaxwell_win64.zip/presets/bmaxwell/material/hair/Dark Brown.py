import bpy

mx = bpy.context.object.active_material.maxwell
mx['hair'].clear()
hair = mx.hair

hair.color = (40/255, 22/255, 11/255)
hair.color_map_enabled = False
hair.primary_strength = 65.0
hair.secondary_strength = 60.0
hair.secondary_tint = (128/255, 74/135, 58/255)
