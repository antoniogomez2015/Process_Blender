import bpy

mx = bpy.context.object.active_material.maxwell
mx['hair'].clear()
hair = mx.hair

hair.color_map = "hairTex_Red"
hair.color_map_enabled = True
hair.primary_strength = 100.0
hair.primary_spread = 90.0
hair.secondary_strength = 95.0
hair.secondary_spread = 75.0
hair.primary_tint = (241/255, 235/135, 226/255)
hair.secondary_tint = (226/255, 192/135, 113/255)
