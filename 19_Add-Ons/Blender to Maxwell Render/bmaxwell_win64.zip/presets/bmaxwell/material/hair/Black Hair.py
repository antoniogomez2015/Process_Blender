import bpy

mx = bpy.context.object.active_material.maxwell
mx['hair'].clear()
hair = mx.hair

hair.color = (6/255, 6/255, 7/255)
hair.color_map_enabled = False
hair.primary_tint = (245/255, 245/255, 255/255)
hair.secondary_tint = (131/255, 245/135, 140/255)
