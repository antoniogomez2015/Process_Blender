import bpy

transparent = bpy.context.object.active_material.maxwell.transparent

transparent.color = (162/255, 0/255, 0/255)
transparent.color_map_enabled = False
transparent.ior = 1.76
transparent.transparency = 3.0
transparent.roughness = 0.0
transparent.roughness_map_enabled = False
transparent.specular_tint = 0.0
transparent.dispersion = 27.8
transparent.clearcoat = False
