import bpy

transparent = bpy.context.object.active_material.maxwell.transparent

transparent.color = (1.0, 1.0, 1.0)
transparent.color_map_enabled = False
transparent.ior = 1.33
transparent.transparency = 0.0
transparent.roughness = 0.0
transparent.roughness_map_enabled = False
transparent.specular_tint = 0.0
transparent.dispersion = 0.0
transparent.clearcoat = False
