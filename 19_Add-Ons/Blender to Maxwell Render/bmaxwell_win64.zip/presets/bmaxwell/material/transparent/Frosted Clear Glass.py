import bpy

transparent = bpy.context.object.active_material.maxwell.transparent

transparent.color = (182/255, 182/255, 182/255)
transparent.color_map_enabled = False
transparent.ior = 1.51
transparent.transparency = 30.0
transparent.roughness = 100.0
transparent.roughness_map_enabled = False
transparent.specular_tint = 0.0
transparent.dispersion = 0.0
transparent.clearcoat = False
