import bpy

transparent = bpy.context.object.active_material.maxwell.transparent

transparent.color = (220/255, 220/255, 220/255)
transparent.color_map_enabled = False
transparent.ior = 2.41
transparent.transparency = 30.0
transparent.roughness = 0.0
transparent.roughness_map_enabled = False
transparent.specular_tint = 0.0
transparent.dispersion = 44.7
transparent.clearcoat = False
