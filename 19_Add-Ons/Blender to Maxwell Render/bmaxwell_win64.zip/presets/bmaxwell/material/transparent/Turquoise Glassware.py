import bpy

transparent = bpy.context.object.active_material.maxwell.transparent

transparent.color = (115/255, 226/255, 234/255)
transparent.color_map_enabled = False
transparent.ior = 1.51
transparent.transparency = 3.0
transparent.roughness = 0.0
transparent.roughness_map_enabled = False
transparent.specular_tint = 0.0
transparent.dispersion = 0.0
transparent.clearcoat = False
