import bpy

mx = bpy.context.object.particle_systems.active.settings.maxwell
grass = mx.grass

grass.type = '1'
grass.blade_points = 6
grass.density = 4500
grass.length = 8
grass.length_var = 50
grass.root_width = 5
grass.tip_width = 2
grass.direction = '0'
grass.angle = 80
grass.angle_var = 40
grass.start_bend = 30
grass.start_bend_var = 50
grass.bend_radius = 10
grass.bend_radius_var = 30
grass.bend_angle = 80
grass.bend_angle_var = 40
grass.cut_off = 100
grass.cut_off_var = 0
