import bpy

mx = bpy.context.object.particle_systems.active.settings.maxwell
grass = mx.grass

grass.type = '1'
grass.blade_points = 8
grass.density = 3000
grass.length = 7.5
grass.length_var = 60
grass.root_width = 6
grass.tip_width = 2.5
grass.direction = '0'
grass.angle = 60
grass.angle_var = 50
grass.start_bend = 40
grass.start_bend_var = 25
grass.bend_radius = 5
grass.bend_radius_var = 50
grass.bend_angle = 80
grass.bend_angle_var = 50
grass.cut_off = 100
grass.cut_off_var = 0
