import bpy

mx = bpy.context.object.particle_systems.active.settings.maxwell
grass = mx.grass

grass.type = '1'
grass.blade_points = 16
grass.density = 2500
grass.length = 40
grass.length_var = 30
grass.root_width = 11
grass.tip_width = 3
grass.direction = '0'
grass.angle = 10
grass.angle_var = 25
grass.start_bend = 30
grass.start_bend_var = 25
grass.bend_radius = 25
grass.bend_radius_var = 25
grass.bend_angle = 80
grass.bend_angle_var = 25
grass.cut_off = 100
grass.cut_off_var = 0
