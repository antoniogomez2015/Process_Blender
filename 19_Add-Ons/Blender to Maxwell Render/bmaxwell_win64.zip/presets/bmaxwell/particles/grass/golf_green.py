import bpy

mx = bpy.context.object.particle_systems.active.settings.maxwell
grass = mx.grass

grass.type = '1'
grass.blade_points = 4
grass.density = 150000
grass.length = 1.5
grass.length_var = 20
grass.root_width = 2
grass.tip_width = 0.5
grass.direction = '0'
grass.angle = 70
grass.angle_var = 50
grass.start_bend = 40
grass.start_bend_var = 25
grass.bend_radius = 1
grass.bend_radius_var = 25
grass.bend_angle = 80
grass.bend_angle_var = 50
grass.cut_off = 65
grass.cut_off_var = 15
