import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = 31.333
env.sun.latitude = 29.867
env.sun.day = 161
env.sun.time = 17.483333
env.sun.gmt = 1
env.sun.rotation = 0.0

env.sun.type = '1'
env.sun.temperature = 5234.704
env.sun.power = 1.5

env.physical.planetRefl = 4.0

env.physical.ozone = 0.88
env.physical.water = 52.0
env.physical.angstrom = 0.077
env.physical.wavelength = 1.0
env.physical.albedo = 90.0
env.physical.asymmetry = 0.822
