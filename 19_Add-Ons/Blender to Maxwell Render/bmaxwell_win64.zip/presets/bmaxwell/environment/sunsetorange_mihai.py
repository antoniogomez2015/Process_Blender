import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = 3.617
env.sun.latitude = 43.678
env.sun.day = 154
env.sun.time = 20.15
env.sun.gmt = 1
env.sun.rotation = 0.855211

env.sun.type = '1'
env.sun.temperature = 5777.0
env.sun.power = 1.0

env.physical.planetRefl = 32.0

env.physical.ozone = 0.425
env.physical.water = 3.0
env.physical.angstrom = 0.08
env.physical.wavelength = 2.2
env.physical.albedo = 85.0
env.physical.asymmetry = 0.813
