import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = 10.0
env.sun.latitude = 40.0
env.sun.day = 199
env.sun.time = 12.5
env.sun.gmt = 0
env.sun.rotation = 0.0

env.sun.type = '1'
env.sun.temperature = 5777.0
env.sun.power = 1.0

env.physical.planetRefl = 25.0
env.physical.ozone = 0.4
env.physical.water = 2.0
env.physical.angstrom = 0.04
env.physical.wavelength = 1.2
env.physical.albedo = 80.0
env.physical.asymmetry = 0.7
