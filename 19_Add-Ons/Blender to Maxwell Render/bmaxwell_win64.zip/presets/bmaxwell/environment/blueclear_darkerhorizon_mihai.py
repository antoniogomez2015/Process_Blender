import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = 3.617
env.sun.latitude = 43.678
env.sun.day = 153
env.sun.time = 17.0
env.sun.gmt = 1
env.sun.rotation = 3.266331

env.sun.type = '1'
env.sun.temperature = 5777.0
env.sun.power = 1.0

env.physical.planetRefl = 8.0
env.physical.ozone = 1.3
env.physical.water = 0.1
env.physical.angstrom = 0.002
env.physical.wavelength = 0.16
env.physical.albedo = 50.0
env.physical.asymmetry = 0.0
