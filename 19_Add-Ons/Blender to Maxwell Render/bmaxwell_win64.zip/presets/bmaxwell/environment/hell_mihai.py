import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = 3.617
env.sun.latitude = 43.678
env.sun.day = 154
env.sun.time = 17.0
env.sun.gmt = 1
env.sun.rotation = 3.390721

env.sun.type = '0'
env.sun.temperature = 1050.0
env.sun.power = 1.0

env.physical.planetRefl = 80.0
env.physical.ozone = 0.1
env.physical.water = 1.0
env.physical.angstrom = 0.06
env.physical.wavelength = 80.0
env.physical.albedo = 50.0
env.physical.asymmetry = 0.0
