import bpy

world = bpy.context.world
world['maxwell'].clear()
env = world.maxwell

env.sun.longitude = -122.383
env.sun.latitude = 37.617
env.sun.day = 200
env.sun.time = 14.983333
env.sun.gmt = -8
env.sun.rotation = 3.455752

env.sun.type = '1'
env.sun.temperature = 5777.0
env.sun.power = 1.0

env.physical.planetRefl = 25.0

env.physical.ozone = 3.0
env.physical.water = 50.0
env.physical.angstrom = 0.5
env.physical.wavelength = 1.2
env.physical.albedo = 80.0
env.physical.asymmetry = 0.5
