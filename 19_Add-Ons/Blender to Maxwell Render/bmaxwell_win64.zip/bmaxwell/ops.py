# -*- coding: utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Ildar Nikolaev"
__email__ = "nildar@users.sourceforge.net"

import os.path
import traceback

import bpy
from bpy.path import abspath as bpy_abspath
from bpy.types import Operator, SpaceView3D
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    IntVectorProperty,
    FloatProperty,
    EnumProperty
)
from bl_operators.presets import AddPresetBase
from bpy_extras.io_utils import (
    ImportHelper,
    ExportHelper,
    axis_conversion
)

from mathutils import Matrix, Vector

from . import MaxwellRenderEngine
from . import BMaxwellPreferences


@MaxwellRenderEngine.register_class
class MAXWELL_UI_OT_toggle(Operator):
    bl_idname = 'maxwell.ui_toggle'
    bl_options = {'INTERNAL'}
    bl_label = "Properties"

    attr = StringProperty(options={'HIDDEN'})

    def execute(self, context):
        attr = self.attr
        data = context.maxwell_ui
        setattr(data, attr, not getattr(data, attr))
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_report(Operator):
    bl_idname = 'maxwell.report'
    bl_label = "Show UI Message"
    bl_options = {'INTERNAL'}

    _TYPES = {'DEBUG', 'INFO', 'OPERATOR', 'PROPERTY', 'WARNING', 'ERROR',
              'ERROR_INVALID_INPUT', 'ERROR_INVALID_CONTEXT', 'ERROR_OUT_OF_MEMORY'}

    type = EnumProperty(
        items=[(t, t, "") for t in _TYPES],
        options={'ENUM_FLAG'},
        default={'INFO'}
    )
    message = StringProperty()

    def execute(self, context):
        self.report(self.type, self.message)
        return {'FINISHED'}


#region Texture

from .props import PROCEDURAL_TYPES


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_OT_procedural_add(Operator):
    bl_idname = 'maxwell.texture_procedural_add'
    bl_label = "Add"
    bl_description = "Add a new procedural texture"

    type = EnumProperty(
        name="Procedural Type",
        items=PROCEDURAL_TYPES,
        default='Checker'
    )

    def execute(self, context):
        tex = context.texture
        mx = tex.maxwell
        procedurals = mx.procedurals
        t = PROCEDURAL_TYPES[self.properties['type']][1]
        name = t
        n = 1
        while name in procedurals:
            name = "%s.%03d" % (t, n)
            n += 1
        i = len(procedurals)
        p = procedurals.add()
        p.name = name
        p.type = self.type
        mx.active_procedural_index = i
        # force to update preview
        tex.type = tex.type
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_OT_procedural_remove(Operator):
    bl_idname = 'maxwell.texture_procedural_remove'
    bl_label = "Remove"
    bl_description = "Remove the selected procedural texture"

    def execute(self, context):
        tex = context.texture
        mx = tex.maxwell
        procedurals = mx.procedurals
        i = mx.active_procedural_index
        if 0 <= i < len(procedurals):
            procedurals.remove(i)
            if i >= len(procedurals):
                mx.active_procedural_index = i - 1
            # force to update preview
            tex.type = tex.type
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_OT_procedural_up(Operator):
    bl_idname = 'maxwell.texture_procedural_up'
    bl_label = "Move Up"
    bl_description = "Move the selected procedural texture up in the list"

    def execute(self, context):
        tex = context.texture
        mx = tex.maxwell
        procedurals = mx.procedurals
        i = mx.active_procedural_index
        if 0 < i < len(procedurals):
            procedurals.move(i - 1, i)
            mx.active_procedural_index = i - 1
            # force to update preview
            tex.type = tex.type
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_OT_procedural_down(Operator):
    bl_idname = 'maxwell.texture_procedural_down'
    bl_label = "Move Down"
    bl_description = "Move the selected procedural texture down in the list"

    def execute(self, context):
        tex = context.texture
        mx = tex.maxwell
        i = mx.active_procedural_index + 1
        procedurals = mx.procedurals
        if 0 < i < len(procedurals):
            procedurals.move(i, i - 1)
            mx.active_procedural_index = i
            # force to update preview
            tex.type = tex.type
        return {'FINISHED'}

#endregion


#region Material

@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_browse_mxm(Operator):
    bl_idname = 'maxwell.material_browse_mxm'
    bl_label = "Browser"
    bl_description = "Browse and select a material from Maxwell Material Browser"

    def execute(self, context):
        from subprocess import check_output

        try:
            ret = check_output([
                BMaxwellPreferences.prefs(context).MXED,
                "-brwclose"
            ])
            ret = ret.decode().strip().split(":", 1)
            if len(ret) == 2 and ret[0] == "MXM":
                mxm = ret[1]
                if mxm and context.user_preferences.filepaths.use_relative_paths:
                    mxm = bpy.path.relpath(mxm)
                context.material.maxwell.mxm = mxm
                # update preview
                ob = context.object
                ob.active_material_index = ob.active_material_index
        except Exception as ex:
            self.report(type={'WARNING'}, message="Exception: {0}".format(ex))
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_edit_mxm(Operator):
    bl_idname = 'maxwell.material_edit_mxm'
    bl_label = "Editor"
    bl_description = "Edit the MXM file in Maxwell Material Editor"

    def execute(self, context):
        from subprocess import call

        try:
            call([
                BMaxwellPreferences.prefs(context).MXED,
                "-mxm:" + os.path.normpath(bpy_abspath(context.material.maxwell.mxm))
            ])
            # update preview
            ob = context.object
            ob.active_material_index = ob.active_material_index
        except Exception as ex:
            self.report(type={'WARNING'}, message="\n" + traceback.format_exc())
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_read_mxm(Operator):
    bl_idname = 'maxwell.material_read_mxm'
    bl_label = "Make Custom"
    bl_description = "Read material from MXM file and make it Custom"

    def execute(self, context):
        import pprint
        from .props import (
            EMITTER_TYPES,
            EMITTER_LOBE_TYPES,
            EMITTER_LUMINANCES,
            SPOT_FALLOFF_TYPES
        )
        from . import pymaxwell
        from .engine import MATERIALS_DATABASE

        if context.user_preferences.filepaths.use_relative_paths:
            _filepath = lambda p: bpy.path.relpath(p) if p else ""
        else:
            _filepath = lambda p: p

        _data_ = context.blend_data
        _material_ = getattr(context, 'material', None)
        if _material_ is None:
            _material_ = context.object.active_material

        mxm_path = _material_.maxwell.mxm
        embed = _material_.maxwell.embed
        _material_['maxwell'].clear()

        mx_mat = _material_.maxwell
        mx_mat.mxm = mxm_path
        mx_mat.embed = embed

        mxm_path = bpy_abspath(mxm_path)
        mxm_dir = os.path.dirname(mxm_path)

        _mxs_ = pymaxwell.Scene()
        _mxs_.AddSearchingPath(mxm_dir)
        if MATERIALS_DATABASE and MATERIALS_DATABASE != mxm_dir:
            _mxs_.AddSearchingPath(MATERIALS_DATABASE)
            _mxs_.AddSearchingPath(os.path.join(MATERIALS_DATABASE, "textures"))
            _mxs_.AddSearchingPath(os.path.join(MATERIALS_DATABASE, "ior files"))
        if context.scene:
            for p in context.scene.maxwell.render.searching_paths:
                p = bpy_abspath(p.name)
                if p:
                    _mxs_.AddSearchingPath(p)

        def search_file(path):
            if path:
                if not os.path.isfile(path):
                    found_path = _mxs_.SearchFile(path)
                    if found_path:
                        path = found_path
                path = os.path.abspath(path)
            return path

        textures = {}
        for tex in _data_.textures:
            if tex.type == 'IMAGE' and tex.image:
                mx_tex = tex.maxwell
                p = mx_tex.projection
                d = {
                    'filepath': bpy_abspath(tex.image.filepath),
                    'override': mx_tex.override,
                    'projection': {
                        'channel': p.channel,
                        'tile_x': p.tile_x,
                        'tile_y': p.tile_y,
                        'units': p.get('units', 0),
                        'repeat': p.repeat[:],
                        'mirror_x': p.mirror_x,
                        'mirror_y': p.mirror_y,
                        'offset': p.offset[:],
                        'rotation': p.rotation,
                    },
                    'flip_x': mx_tex.flip_x,
                    'flip_y': mx_tex.flip_y,
                    'wide': mx_tex.wide,
                    'invert': mx_tex.invert,
                    'alpha_only': mx_tex.alpha_only,
                    'interpolation': int(mx_tex.interpolation),
                    'brightness': mx_tex.brightness,
                    'saturation': mx_tex.saturation,
                    'contrast': mx_tex.contrast,
                    'hue': mx_tex.hue,
                    'clamp': mx_tex.clamp[:]
                }
                s_key = pprint.pformat(d)
                textures[s_key] = tex

        for i, slot in enumerate(_material_.texture_slots):
            if slot:
                _material_.texture_slots.clear(i)

        def add_texture_slot(texture):
            slot = _material_.texture_slots.add()
            slot.texture = texture

        def _texture(mxt):
            if mxt.isEmpty:
                return ""
            mxt_params = {
                'filepath': search_file(mxt.path),
                'override': mxt.globalMap,
                'projection': {
                    'channel': mxt.channel,
                    'tile_x': mxt.vIsTiled,
                    'tile_y': mxt.uIsTiled,
                    'units': 1 if mxt.absolute else 0,
                    'repeat': mxt.scale[:],
                    'mirror_x': mxt.vIsMirrored,
                    'mirror_y': mxt.uIsMirrored,
                    'offset': mxt.offset[:],
                    'rotation': mxt.rotation,
                },
                'flip_x': mxt.flipRed,
                'flip_y': mxt.flipGreen,
                'wide': mxt.fullRange,
                'invert': mxt.invert,
                'alpha_only': mxt.alpha,
                'interpolation': mxt.interpolation,
                'brightness': mxt.brightness * 100.0,
                'saturation': mxt.saturation * 100.0,
                'contrast': mxt.contrast * 100.0,
                'hue': mxt.hue * 100.0,
                'clamp': (int(mxt.clampMin * 255), int(mxt.clampMax * 255))
            }
            s_key = pprint.pformat(mxt_params)
            bl_tex = textures.get(s_key)
            if bl_tex:
                _name = bl_tex.name
                idx = _material_.texture_slots.find(_name)
                if idx < 0:
                    add_texture_slot(bl_tex)
            else:
                filepath = mxt_params.pop('filepath')
                tex_name = os.path.splitext(os.path.basename(filepath))[0]
                bl_tex = _data_.textures.new(tex_name, 'IMAGE')
                filepath = _filepath(filepath)
                try:
                    bl_tex.image = _data_.images.load(filepath)
                except Exception as ex:
                    self.report(type={'WARNING'}, message="Exception: {0}:".format(ex))
                bl_tex['maxwell'] = mxt_params
                textures[s_key] = bl_tex
                add_texture_slot(bl_tex)
                _name = bl_tex.name
            return _name

        _attribute = lambda a, v: (getattr(a, v), _texture(a.texture), a.type == 2)  # MAP_TYPE_BITMAP

        mxm = _mxs_.ReadMaterial(mxm_path)
        if not mxm.isNull:
            # TODO: import referenced and extension materials
            m = mxm.GlobalMap
            mx_map = mx_mat.override_map
            mx_map.channel = m.channel
            mx_map.tile_x = m.vIsTiled
            mx_map.tile_y = m.uIsTiled
            mx_map.units = '1' if m.absolute else '0'
            mx_map.mirror_x = m.vIsMirrored
            mx_map.mirror_y = m.uIsMirrored
            mx_map.repeat = m.scale
            mx_map.offset = m.offset
            mx_map.rotation = m.rotation

            mx_mat.bump, mx_mat.bump_map, mx_mat.bump_map_enabled = _attribute(mxm.Bump, 'value')
            mx_mat.bump_normal = mxm.NormalMapState

            mx_mat.matte = mxm.Matte
            mx_mat.shadow = mxm.MatteShadow
            mx_mat.nested_priority = mxm.NestedPriority
            mx_mat.dispersion = mxm.Dispersion
            mx_mat.color_id = mxm.ColorID

            # Displacement
            dp = mx_mat.displacement
            mxm_dp = mxm.Displacement
            dp.enabled = mxm_dp.Enabled
            dp.map = _texture(mxm_dp.Map)
            # parameters
            p = mxm_dp.Parameters
            dp_type = p['type']
            if dp_type != 1:
                dp['type'] = dp_type
            dp.level = p['level']
            dp.smooth = p['smooth']
            dp.offset = p['offset']
            dp_method = p['method']
            if dp_method:
                dp['method'] = dp_method
            dp_uvi = p['uvi']
            if dp_uvi != 2:
                dp['uvi'] = dp_uvi
            #  height map
            m = mxm_dp.HeightMap
            dp.absolute = m['absolute']
            dp.height = m['height']
            if dp.absolute:
                dp.height *= 100.0
            dp.adaptive = m['adaptive']
            #  vector
            v = mxm_dp.Vector
            dp.scale = v['scale']
            dp_transform = v['transform']
            if dp_transform:
                dp['transform'] = dp_transform
            dp_mapping = v['mapping']
            if dp_mapping:
                dp.mapping = dp_mapping
            dp_preset = v['preset']
            if dp_preset:
                dp['preset'] = dp_preset

            layers = mx_mat.layers
            for n_layer in range(mxm.NumLayers):
                mxm_layer = mxm.GetLayer(n_layer)
                layer = layers.add()
                layer.name = mxm_layer.Name
                layer.enabled = mxm_layer.Enabled
                layer_blend = mxm_layer.Blending
                if layer_blend:
                    layer['blend'] = layer_blend
                layer.opacity, layer.opacity_map, layer.opacity_map_eanbled = _attribute(mxm_layer.Opacity, 'value')

                # Emitter
                mxm_emitter = mxm_layer.GetEmitter()
                if not mxm_emitter.isNull:
                    emitter = layer.emitter
                    emitter.enabled = mxm_emitter.Enabled
                    emitter.type = EMITTER_TYPES[mxm_emitter.Type][0]
                    #  lobe
                    lobe = mxm_emitter.Lobe
                    emitter.lobe = EMITTER_LOBE_TYPES[lobe.Type][0]
                    ies = lobe.IES
                    if ies:
                        ies = _filepath(search_file(lobe.IES))
                    emitter.ies = ies
                    emitter.intensity = lobe.Intensity
                    # spot
                    spot = emitter.spot
                    enabled, image = lobe.Image
                    spot.map = _texture(image)
                    spot.map_enabled = enabled
                    spot.cone_angle = lobe.SpotConeAngle
                    spot.falloff_angle = lobe.SpotFallOffAngle
                    spot.falloff_type = SPOT_FALLOFF_TYPES[lobe.SpotFallOffType][0]
                    lobe.SpotBlur = spot.blur
                    #  temperature
                    emitter.temperature = mxm_emitter.Temperature
                    #  hdri
                    mxi = mxm_emitter.MXI
                    emitter.hdri_intensity = mxi.value
                    emitter.hdri_map = _texture(mxi)
                    #  pair
                    p = mxm_emitter.Pair
                    t, luminance = mxm_emitter.ActivePair
                    emitter.use_temperature = (t == 2)
                    emitter.luminance = EMITTER_LUMINANCES[luminance][0]
                    if luminance == 0:
                        emitter.power = p['watts']
                        emitter.efficacy = p['efficacy']
                    else:
                        emitter.output = p['luminous']
                    emitter.color = p['rgb']
                    emitter.color_temp = p['temperature']

                bsdfs = layer.bsdfs
                for n_bsdf in range(mxm_layer.NumBSDFs):
                    mxm_bsdf = mxm_layer.GetBSDF(n_bsdf)
                    bsdf = bsdfs.add()

                    bsdf.name = mxm_bsdf.Name
                    bsdf.enabled = mxm_bsdf.Enabled
                    bsdf.weight, bsdf.weight_map, bsdf.weight_map_enabled = _attribute(mxm_bsdf.Weight, 'value')

                    refl = mxm_bsdf.Reflectance
                    attrs = refl.Attributes

                    # BSDF Properties
                    ior = refl.ComplexIor
                    if ior:
                        ior = _filepath(search_file(ior))
                    bsdf.ior_file = ior
                    bsdf.ior_type = '1' if refl.ActiveIorMode else '0'
                    bsdf.color, bsdf.color_map, bsdf.color_map_enabled = _attribute(attrs['color'], 'rgb')
                    bsdf.tangential, bsdf.tangential_map, bsdf.tangential_map_enabled = _attribute(attrs['color.tangential'], 'rgb')
                    bsdf.transmittance, bsdf.transmittance_map, bsdf.transmittance_map_enabled = _attribute(attrs['transmittance.color'], 'rgb')
                    d = refl.AbsorptionDistance
                    bsdf.attenuation_units = str(d[0])
                    bsdf.attenuation = d[1]
                    bsdf.nd, bsdf.abbe = refl.IOR
                    bsdf.k = refl.Conductor
                    bsdf.force_fresnel = refl.ForceFresnel
                    bsdf.fresnel_custom_angle, bsdf.fresnel_custom_roughness, bsdf.fresnel_custom_enabled = refl.FresnelCustom

                    # Surface Properties
                    bsdf.roughness, bsdf.roughness_map, bsdf.roughness_map_enabled = _attribute(mxm_bsdf.Roughness, 'value')
                    bsdf.anisotropy, bsdf.anisotropy_map, bsdf.anisotropy_map_enabled = _attribute(mxm_bsdf.Anisotropy, 'value')
                    bsdf.angle, bsdf.angle_map, bsdf.angle_map_enabled = _attribute(mxm_bsdf.Angle, 'value')
                    bsdf.bump, bsdf.bump_map, bsdf.bump_map_enabled = _attribute(mxm_bsdf.Bump, 'value')
                    bsdf.bump_normal = mxm_bsdf.NormalMapState

                    # Subsurface Properties
                    bsdf.scattering, bsdf.scattering_map, bsdf.scattering_map_enabled = _attribute(attrs['scattering'], 'rgb')
                    bsdf.scattering_coefficient, bsdf.scattering_asymmetry, bsdf.use_thickness = refl.ScatteringParameters
                    val, texmap, enabled = _attribute(refl.ScatteringThickness, 'value')
                    bsdf.thickness = val * 1000.0
                    bsdf.thickness_map = texmap
                    bsdf.thickness_map_enabled = enabled
                    r = refl.ScatteringThicknessRange
                    bsdf.thickness_min = r[0] * 1000.0
                    bsdf.thickness_max = r[1] * 1000.0

                    # Coating
                    mxm_coating = mxm_bsdf.GetCoating(0)
                    if not mxm_coating.isNull:
                        coating = bsdf.coating
                        coating.enabled = mxm_coating.Enabled

                        val, texmap, enabled = _attribute(mxm_coating.Thickness, 'value')
                        coating.thickness = val * 1000000000.0
                        coating.thickness_map = texmap
                        coating.thickness_map_enabled = enabled

                        thickness_min, thickness_max = mxm_coating.ThicknessRange
                        coating.thickness_min = thickness_min * 1000000000.0
                        coating.thickness_max = thickness_max * 1000000000.0

                        refl = mxm_coating.Reflectance
                        ior = refl.ComplexIor
                        if ior:
                            ior = _filepath(search_file(ior))
                        coating.ior_file = ior
                        coating.ior_type = '1' if refl.ActiveIorMode else '0'
                        coating.nd = refl.IOR[0]
                        coating.k = refl.Conductor
                        coating.force_fresnel = refl.ForceFresnel
                        f = refl.FresnelCustom
                        coating.fresnel_custom_angle = f[0]
                        coating.fresnel_custom_enabled = f[2]

                        attrs = refl.Attributes
                        coating.color, coating.color_map, coating.color_map_enabled = _attribute(attrs['color'], 'rgb')
                        coating.tangential, coating.tangential_map, coating.tangential_map_enabled = _attribute(attrs['color.tangential'], 'rgb')
                if bsdfs:
                    layer.active_bsdf_index = 0
            if layers:
                mx_mat.active_layer_index = 0
        mx_mat.type = 'CUSTOM'
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_save_mxm(ExportHelper, Operator):
    bl_idname = 'maxwell.material_save_mxm'
    bl_label = "Save as MXM file"
    bl_description = "Save material as maxwell MXM file"

    filename_ext = ".mxm"
    filter_glob = StringProperty(default="*.mxm", options={'HIDDEN'})
    make_linked = BoolProperty(name="Make Linked")
    embed = BoolProperty(name="Embedded")

    def invoke(self, context, event):
        filepath = context.blend_data.filepath
        if filepath:
            self.filepath = os.path.join(
                os.path.split(filepath)[0],
                bpy.path.clean_name(context.material.name) + self.filename_ext
            )
        else:
            self.filename = "unknown"
        return super().invoke(context, event)

    def execute(self, context):
        from .engine import Logger, Textures, export_material
        from . import pymaxwell

        _log = Logger(report=self.report, context=context)

        filepath = self.filepath
        mat = context.material
        mx = mat.maxwell
        try:
            mxs = pymaxwell.Scene()
            mxm = mxs.CreateMaterial(mat.name)
            export_material(mxm, mat, Textures(context.blend_data.textures))
            mxm.Write(filepath)

            if self.make_linked:
                if context.user_preferences.filepaths.use_relative_paths:
                    mx.mxm = bpy.path.relpath(filepath)
                else:
                    mx.mxm = filepath
                mx.embed = self.embed
                mx.type = 'FILE'
        except Exception as ex:
            _log(text="Exception: {0}".format(ex), type={'WARNING'})
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(self, "make_linked")
        row = layout.row()
        row.prop(self, "embed")
        row.enabled = self.make_linked


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_layer_add(Operator):
    bl_idname = 'maxwell.material_layer_add'
    bl_label = "Add"
    bl_description = "Add a new material layer"

    def execute(self, context):
        mx = context.material.maxwell
        layers = mx.layers
        n = 1
        name = "Layer"
        while layers.find(name) >= 0:
            name = "Layer.%03d" % n
            n += 1
        i = len(layers)
        layer = layers.add()
        layer['name'] = name
        mx.active_layer_index = i
        # add bsdf
        bsdf = layer.bsdfs.add()
        bsdf.name = "BSDF"
        layer.active_bsdf_index = 0
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_layer_remove(Operator):
    bl_idname = 'maxwell.material_layer_remove'
    bl_label = "Remove"
    bl_description = "Remove the selected material layer"

    def execute(self, context):
        mx = context.material.maxwell
        i = mx.active_layer_index
        layers = mx.layers
        if 0 <= i < len(layers):
            layers.remove(i)
            if i >= len(layers):
                mx.active_layer_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_layer_up(Operator):
    bl_idname = 'maxwell.material_layer_up'
    bl_label = "Move Up"
    bl_description = "Move the selected material layer up in the list"

    def execute(self, context):
        mx = context.material.maxwell
        i = mx.active_layer_index
        layers = mx.layers
        if 0 < i < len(layers):
            layers.move(i - 1, i)
            mx.active_layer_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_layer_down(Operator):
    bl_idname = 'maxwell.material_layer_down'
    bl_label = "Move Down"
    bl_description = "Move the selected material layer down in the list"

    def execute(self, context):
        mx = context.material.maxwell
        i = mx.active_layer_index + 1
        layers = mx.layers
        if 0 < i < len(layers):
            layers.move(i, i - 1)
            mx.active_layer_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_layer(Operator):
    bl_idname = 'maxwell.material_layer'
    bl_label = "Material Layer Operator"

    action = EnumProperty(
        items=[
            ('COPY', "Copy Layer", "Copy the selected material layer", 'COPYDOWN', 0),
            ('PASTE', "Paste Layer", "Paste to the selected material Layer", 'PASTEDOWN', 1),
            ('DUPLICATE', "Duplicate Layer", "Duplicate selected material layer", 'BLANK1', 2)
        ],
        default='COPY'
    )
    _tmp = None

    def execute(self, context):
        mx = context.material.maxwell
        i = mx.active_layer_index
        layers = mx.get('layers')
        if layers and i <= 0 < len(layers):
            layer = layers[i]
            if self.action == 'PASTE':
                if self._tmp is not None:
                    layer.clear()
                    layer.update(self._tmp)
            else:
                tmp = layer.to_dict()
                del tmp['name']
                if self.action == 'COPY':
                    self.__class__._tmp = tmp
                elif self.action == 'DUPLICATE':
                    bpy.ops.maxwell.material_layer_add()
                    layers[mx.active_layer_index].update(tmp)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_bsdf_add(Operator):
    bl_idname = 'maxwell.material_bsdf_add'
    bl_label = "Add BSDF"
    bl_description = "Add a new material BSDF to the active layer"

    def execute(self, context):
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        bsdfs = layer.bsdfs
        n = 1
        name = "BSDF"
        while bsdfs.find(name) >= 0:
            name = "BSDF%d" % n
            n += 1
        i = len(bsdfs)
        bsdf = bsdfs.add()
        bsdf.name = name
        layer.active_bsdf_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_bsdf_remove(Operator):
    bl_idname = 'maxwell.material_bsdf_remove'
    bl_label = "Remove BSDF"
    bl_description = "Remove the selected material BSDF"

    def execute(self, context):
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        i = layer.active_bsdf_index
        bsdfs = layer.bsdfs
        if 0 <= i < len(bsdfs):
            bsdfs.remove(i)
            layer.active_bsdf_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_bsdf_up(Operator):
    bl_idname = 'maxwell.material_bsdf_up'
    bl_label = "Move BSDF Up"
    bl_description = "Move the selected material BSDF up in the list"

    def execute(self, context):
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        i = layer.active_bsdf_index
        bsdfs = layer.bsdfs
        if 0 < i < len(bsdfs):
            bsdfs.move(i - 1, i)
            layer.active_bsdf_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_bsdf_down(Operator):
    bl_idname = 'maxwell.material_bsdf_down'
    bl_label = "Move BSDF Down"
    bl_description = "Move the selected material BSDF down in the list"

    def execute(self, context):
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        i = layer.active_bsdf_index + 1
        bsdfs = layer.bsdfs
        if 0 < i < len(bsdfs):
            bsdfs.move(i, i - 1)
            layer.active_bsdf_index = 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_bsdf(Operator):
    bl_idname = 'maxwell.material_bsdf'
    bl_label = "Material BSDF Operator"

    action = EnumProperty(
        items=[
            ('COPY', "Copy BSDF", "Copy Material BSDF", 'COPYDOWN', 0),
            ('PASTE', "Paste BSDF", "Paste Material BSDF", 'PASTEDOWN', 1),
            ('DUPLICATE', "Duplicate BSDF", "Duplicate Material BSDF", 'BLANK1', 2)
        ],
        default='COPY'
    )
    _tmp = {}

    def execute(self, context):
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        i = layer.active_bsdf_index
        bsdfs = layer.get('bsdfs')
        if bsdfs and 0 <= i < len(bsdfs):
            bsdf = bsdfs[i]
            if self.action == 'PASTE':
                if self._tmp is not None:
                    bsdf.clear()
                    bsdf.update(self._tmp)
            else:
                tmp = bsdf.to_dict()
                del tmp['name']
                if self.action == 'COPY':
                    self.__class__._tmp = tmp
                elif self.action == 'DUPLICATE':
                    bpy.ops.maxwell.material_bsdf_add()
                    bsdfs[layer.active_bsdf_index].update(tmp)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_presets(AddPresetBase, Operator):
    bl_idname = "maxwell.material_preset_add"
    bl_label = "Add or remove a Material Preset"

    preset_menu = 'MAXWELL_MT_material_presets'
    preset_subdir = "bmaxwell/material"

    _preset_defines = """
import bpy

mat = bpy.context.object.active_material
mat['maxwell'].clear()

mx = mat.maxwell
"""

    def add(self, context, filepath):
        mx = context.object.active_material.maxwell

        with open(filepath, 'w') as f:
            fw = f.write
            fw(self._preset_defines)

            def _w(c, t, p):
                v = c.get(p)
                if v is not None:
                    v = getattr(c, p)
                    try:
                        v = v[:]
                    except:
                        pass
                    fw("%s.%s = %r\n" % (t, p, v))

            _w(mx, 'mx', 'type')
            _w(mx, 'mx', 'bump')
            _w(mx, 'mx', 'bump_normal')
            _w(mx, 'mx', 'dispersion')
            _w(mx, 'mx', 'shadow')
            _w(mx, 'mx', 'matte')
            _w(mx, 'mx', 'nested_priority')
            _w(mx, 'mx', 'color_id')

            if mx.type == 'FILE':
                _w(mx, 'mx', 'mxm')
                _w(mx, 'mx', 'embed')
            elif mx.type == 'CUSTOM':
                d = mx.displacement
                if d.enabled:
                    fw("\nd = mx.displacement\n")
                    _w(d, 'd', 'enabled')
                    _w(d, 'd', 'type')
                    _w(d, 'd', 'level')
                    _w(d, 'd', 'adaptive')
                    _w(d, 'd', 'smooth')
                    _w(d, 'd', 'offset')
                    _w(d, 'd', 'method')
                    _w(d, 'd', 'uvi')
                    if d.type == '2':  # Vector
                        _w(d, 'd', 'preset')
                        if d.preset == '0':  # Custom
                            _w(d, 'd', 'transform')
                            _w(d, 'd', 'mapping')
                        _w(d, 'd', 'scale')
                    else:
                        _w(d, 'd', 'height')
                        _w(d, 'd', 'absolute')
                for layer in mx.layers:
                    fw("\nlayer = mx.layers.add()\n")
                    _w(layer, 'layer', 'enabled')
                    _w(layer, 'layer', 'name')
                    _w(layer, 'layer', 'opacity')
                    _w(layer, 'layer', 'blend')
                    emitter = layer.emitter
                    if emitter.enabled:
                        fw("\nemitter= layer.emitter\n")
                        _w(emitter, 'emitter', 'enabled')
                        _w(emitter, 'emitter', 'type')
                        if emitter.type == 'COLOR':
                            _w(emitter, 'emitter', 'use_temperature')
                            if emitter.use_temperature:
                                _w(emitter, 'emitter', 'color_temp')
                            else:
                                _w(emitter, 'emitter', 'color')
                            _w(emitter, 'emitter', 'lobe')
                            if emitter.lobe == 'IES':
                                _w(emitter, 'emitter', 'ies')
                                _w(emitter, 'emitter', 'intensity')
                            else:
                                _w(emitter, 'emitter', 'luminance')
                                _w(emitter, 'emitter', 'power')
                                _w(emitter, 'emitter', 'efficacy')
                                _w(emitter, 'emitter', 'output')
                                if emitter.lobe == 'SPOT':
                                    spot = emitter.spot
                                    fw("\nspot = emitter.spot\n")
                                    _w(spot, 'spot', 'cone_angle')
                                    _w(spot, 'spot', 'falloff_angle')
                                    _w(spot, 'spot', 'falloff_type')
                                    _w(spot, 'spot', 'blur')
                        elif emitter.type == 'TEMP':
                            _w(emitter, 'emitter', 'temperature')
                        elif emitter.type == 'HDRI':
                            _w(emitter, 'emitter', 'hdri_intensity')
                    for bsdf in layer.bsdfs:
                        fw("\nbsdf = layer.bsdfs.add()\n")
                        _w(bsdf, 'bsdf', 'enabled')
                        _w(bsdf, 'bsdf', 'name')
                        _w(bsdf, 'bsdf', 'weight')
                        _w(bsdf, 'bsdf', 'ior_type')
                        if bsdf.ior_type == '0':  # Custom
                            _w(bsdf, 'bsdf', 'color')
                            _w(bsdf, 'bsdf', 'tangential')
                            _w(bsdf, 'bsdf', 'transmittance')
                            _w(bsdf, 'bsdf', 'attenuation')
                            _w(bsdf, 'bsdf', 'attenuation_units')
                            _w(bsdf, 'bsdf', 'nd')
                            _w(bsdf, 'bsdf', 'force_fresnel')
                            _w(bsdf, 'bsdf', 'k')
                            _w(bsdf, 'bsdf', 'abbe')
                            _w(bsdf, 'bsdf', 'fresnel_custom_enabled')
                            if bsdf.fresnel_custom_enabled:
                                _w(bsdf, 'bsdf', 'fresnel_custom_angle')
                                _w(bsdf, 'bsdf', 'fresnel_custom_roughness')
                        else:
                            _w(bsdf, 'bsdf', 'ior_file')
                        _w(bsdf, 'bsdf', 'roughness')
                        _w(bsdf, 'bsdf', 'bump')
                        _w(bsdf, 'bsdf', 'bump_normal')
                        _w(bsdf, 'bsdf', 'anisotropy')
                        _w(bsdf, 'bsdf', 'angle')
                        _w(bsdf, 'bsdf', 'scattering')
                        _w(bsdf, 'bsdf', 'scattering_coefficient')
                        _w(bsdf, 'bsdf', 'scattering_asymmetry')
                        _w(bsdf, 'bsdf', 'use_thickness')
                        if bsdf.use_thickness:
                            _w(bsdf, 'bsdf', 'thickness')
                            _w(bsdf, 'bsdf', 'thickness_min')
                            _w(bsdf, 'bsdf', 'thickness_max')
                        coating = bsdf.coating
                        if coating.enabled:
                            fw("\ncoating = bsdfs.coating\n")
                            _w(coating, 'coating', 'enabled')
                            _w(coating, 'coating', 'thickness')
                            _w(coating, 'coating', 'thickness_min')
                            _w(coating, 'coating', 'thickness_max')
                            _w(coating, 'coating', 'ior_type')
                            if coating.ior_type == '0':
                                _w(coating, 'coating', 'ior_file')
                            else:
                                _w(coating, 'coating', 'color')
                                _w(coating, 'coating', 'tangential')
                                _w(coating, 'coating', 'nd')
                                _w(coating, 'coating', 'force_fresnel')
                                _w(coating, 'coating', 'k')
                                _w(coating, 'coating', 'fresnel_custom_enabled')
                                if coating.fresnel_custom_enabled:
                                    _w(coating, 'coating', 'fresnel_custom_angle')
                    if layer.bsdfs:
                        fw("\nlayer.active_bsdf_index = 0\n")
                if mx.layers:
                    fw("\nmx.active_layer_index = 0\n")
            elif mx.type == 'AGS':
                ags = mx.ags
                fw("\nags = mx.ags\n")
                _w(ags, 'ags', 'color')
                _w(ags, 'ags', 'reflection')
                _w(ags, 'ags', 'type')
            elif mx.type == 'OPAQUE':
                opaque = mx.opaque
                fw("\nopaque = mx.opaque\n")
                _w(opaque, 'opaque', 'color')
                _w(opaque, 'opaque', 'shininess')
                _w(opaque, 'opaque', 'roughness')
                _w(opaque, 'opaque', 'clearcoat')
            elif mx.type == 'TRANSPARENT':
                transparent = mx.transparent
                fw("\ntransparent = mx.transparent\n")
                _w(transparent, 'transparent', 'color')
                _w(transparent, 'transparent', 'ior')
                _w(transparent, 'transparent', 'transparency')
                _w(transparent, 'transparent', 'roughness')
                _w(transparent, 'transparent', 'specular_tint')
                _w(transparent, 'transparent', 'dispersion')
                _w(transparent, 'transparent', 'clearcoat')
            elif mx.type == 'METAL':
                metal = mx.metal
                fw("\nmetal = mx.metal\n")
                _w(metal, 'metal', 'ior')
                _w(metal, 'metal', 'tint')
                _w(metal, 'metal', 'color')
                _w(metal, 'metal', 'roughness')
                _w(metal, 'metal', 'anisotropy')
                _w(metal, 'metal', 'angle')
                _w(metal, 'metal', 'dust')
            elif mx.type == 'TRANSLUCENT':
                translucent = mx.translucent
                fw("\ntranslucent = mx.translucent\n")
                _w(translucent, 'translucent', 'scale')
                _w(translucent, 'translucent', 'ior')
                _w(translucent, 'translucent', 'color')
                _w(translucent, 'translucent', 'hue_shift')
                _w(translucent, 'translucent', 'invert_hue')
                _w(translucent, 'translucent', 'vibrance')
                _w(translucent, 'translucent', 'density')
                _w(translucent, 'translucent', 'opacity')
                _w(translucent, 'translucent', 'roughness')
                _w(translucent, 'translucent', 'specular_tint')
                _w(translucent, 'translucent', 'clearcoat')
                _w(translucent, 'translucent', 'clearcoat_ior')
            elif mx.type == 'CARPAINT':
                carpaint = mx.carpaint
                fw("\ncarpaint = mx.carpaint\n")
                _w(carpaint, 'carpaint', 'color')
                _w(carpaint, 'carpaint', 'metallic')
                _w(carpaint, 'carpaint', 'topcoat')
            elif mx.type == 'HAIR':
                hair = mx.hair
                fw("\nhair = mx.hair\n")
                _w(hair, 'hair', 'color')
                _w(hair, 'hair', 'root_tip_weight')
                _w(hair, 'hair', 'primary_strength')
                _w(hair, 'hair', 'primary_spread')
                _w(hair, 'hair', 'primary_tint')
                _w(hair, 'hair', 'secondary_strength')
                _w(hair, 'hair', 'secondary_spread')
                _w(hair, 'hair', 'secondary_tint')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_opaque_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_opaque_preset_add'
    bl_label = "Add Opaque Material Preset"

    preset_menu = 'MAXWELL_MATERIAL_MT_opaque_presets'
    preset_subdir = "bmaxwell/material/opaque"

    preset_defines = [
        "opaque = bpy.context.object.active_material.maxwell.opaque",
    ]

    preset_values = [
        "opaque.color",
        "opaque.color_map_enabled",
        "opaque.shininess",
        "opaque.shininess_map_enabled",
        "opaque.roughness"
        "opaque.roughness_map_enabled",
        "opaque.clearcoat"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_transparent_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_transparent_preset_add'
    bl_label = "Add Transparent Material Preset"

    preset_menu = "MAXWELL_MT_material_transparent_presets"
    preset_subdir = "bmaxwell/material/transparent"

    preset_defines = [
        "transparent = bpy.context.object.active_material.maxwell.transparent",
    ]

    preset_values = [
        "transparent.color",
        "transparent.color_map_enabled",
        "transparent.ior",
        "transparent.transparency",
        "transparent.roughness"
        "transparent.roughness_map_enabled",
        "transparent.specular_tint",
        "transparent.dispersion",
        "transparent.clearcoat"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_metal_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_metal_preset_add'
    bl_label = "Add Metal Material Preset"

    preset_menu = 'MAXWELL_MATERIAL_MT_metal_presets'
    preset_subdir = "bmaxwell/material/metal"

    preset_defines = [
        "metal = bpy.context.object.active_material.maxwell.metal",
    ]

    preset_values = [
        "metal.ior",
        "metal.tint",
        "metal.color",
        "metal.color_map_enabled",
        "metal.roughness"
        "metal.roughness_map_enabled",
        "metal.anisotropy",
        "metal.anisotropy_map_enabled",
        "metal.angle",
        "metal.angle_map_enabled",
        "metal.dust",
        "metal.dust_map_enabled"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_translucent_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_translucent_preset_add'
    bl_label = "Add Translucent Material Preset"

    preset_menu = 'MAXWELL_MATERIAL_MT_translucent_presets'
    preset_subdir = "bmaxwell/material/translucent"

    preset_defines = [
        "translucent = bpy.context.object.active_material.maxwell.translucent",
    ]

    preset_values = [
        "translucent.scale",
        "translucent.ior",
        "translucent.color",
        "translucent.color_map_enabled",
        "translucent.hue_shift",
        "translucent.invert_hue",
        "translucent.vibrance",
        "translucent.density",
        "translucent.opacity",
        "translucent.roughness",
        "translucent.roughness_map_enabled",
        "translucent.specular_tint",
        "translucent.clearcoat",
        "translucent.clearcoat_ior"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_carpaint_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_carpaint_preset_add'
    bl_label = "Add Car Paint Material Preset"

    preset_menu = 'MAXWELL_MT_material_carpaint_presets'
    preset_subdir = "bmaxwell/material/carpaint"

    preset_defines = [
        "carpaint = bpy.context.object.active_material.maxwell.carpaint",
    ]

    preset_values = [
        "carpaint.color",
        "carpaint.metallic",
        "carpaint.topcoat"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_hair_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.material_hair_preset_add'
    bl_label = "Add Hair Material Preset"

    preset_menu = 'MAXWELL_MATERIAL_MT_hair_presets'
    preset_subdir = "bmaxwell/material/hair"

    preset_defines = [
        "mx = bpy.context.object.active_material.maxwell",
        "mx['hair'].clear()",
        "hair = mx.hair",
    ]

    preset_values = [
        "hair.color",
        "hair.color_map",
        "hair.color_map_enabled",
        "hair.primary_strength",
        "hair.primary_spread",
        "hair.primary_tint",
        "hair.secondary_strength",
        "hair.secondary_spread",
        "hair.secondary_tint"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_OT_preview_scene(Operator):
    bl_idname = 'maxwell.material_preview_scene_set'
    bl_label = "Material Preview Scene"
    bl_options = {'INTERNAL'}

    name = StringProperty()

    def execute(self, context):
        context.material.maxwell.preview.scene = self.name
        return {'FINISHED'}

#endregion


#region Scene

@MaxwellRenderEngine.register_class
class MAXWELL_OT_render_presets(AddPresetBase, Operator):
    """Add Maxwell Render Preset"""
    bl_idname = 'maxwell.render_preset_add'
    bl_label = "Add Render Preset"

    preset_menu = 'MAXWELL_MT_render_presets'
    preset_subdir = "bmaxwell/render"

    preset_defines = [
        "render = bpy.context.scene.maxwell.render"
    ]

    preset_values = [
        "render.time_limit",
        "render.sampling_level",
        "render.multilight",
        "render.multilight_save_lights",
        "render.threads",
        "render.quality",
        "render.output_depth",
        "render.output_image",
        "render.output_image_enabled",
        "render.output_mxi",
        "render.output_mxi_enabled",
        "render.motion_blur",
        "render.motion_blur_steps",
        "render.displacement",
        "render.dispersion",
        "render.illumination",
        "render.reflection_caustics",
        "render.refraction_caustics",
        "render.override_material_enabled",
        "render.override_material",
        "render.default_material",
        "render.searching_paths",
        "render.active_searching_path_index",
        "render.color_space",
        "render.gamma",
        "render.burn",
        "render.white_point",
        "render.tint",
        "render.sharpness_enabled",
        "render.sharpness",
        "render.diffraction_enabled",
        "render.diffraction",
        "render.frequency",
        "render.aperture_map",
        "render.obstacle_map",
        "render.scattering_enabled",
        "render.scattering",
        "render.devignetting_enabled",
        "render.devignetting",
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_searching_path_add(Operator):
    bl_idname = 'maxwell.scene_searching_path_add'
    bl_label = "Add Search Path"
    bl_options = {'INTERNAL'}

    directory = StringProperty(
        subtype='DIR_PATH',
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    filter_folder = BoolProperty(
        default=True,
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    def execute(self, context):
        render = context.scene.maxwell.render
        search_paths = render.searching_paths
        dir = self.directory
        if dir not in search_paths:
            sp = search_paths.add()
            sp.name = dir
            render.active_searching_path_index = len(search_paths) - 1
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_searching_path_remove(Operator):
    bl_idname = 'maxwell.scene_searching_path_remove'
    bl_label = "Remove Search Path"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        render = context.scene.maxwell.render
        i = render.active_searching_path_index
        search_paths = render.searching_paths
        if 0 <= i < len(search_paths):
            search_paths.remove(i)
            if i >= len(search_paths):
                render.active_searching_path_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alphas_add(Operator):
    bl_idname = 'maxwell.custom_alphas_add'
    bl_options = {'INTERNAL'}
    bl_label = "Add Alpha"
    bl_description = "Add a new custom alpha channel"

    def execute(self, context):
        channels = context.scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        # channel id must be unique for whole blend file
        channel_id = 1
        channel_ids = [
            a.id
            for s in context.blend_data.scenes
            for a in s.maxwell.render.channels.custom_alphas
        ]
        while channel_id in channel_ids:
            channel_id += 1
        n = 1
        name = "Channel.%03d" % n
        while name in custom_alphas:
            n += 1
            name = "Channel.%03d" % n
        i = len(custom_alphas)
        a = custom_alphas.add()
        a.id = channel_id
        a.name = name
        channels.active_custom_alpha_index = i
        return {'FINISHED'}


def _custom_alpha_add(id_data, channel_id):
    mx = id_data.maxwell
    ids = set(mx.custom_alphas)
    ids.add(channel_id)
    mx['_custom_alphas'] = list(ids)

def _custom_alpha_remove(id_data, channel_id):
    mx = id_data.maxwell
    ids = mx.get('_custom_alphas')
    if ids is not None:
        try:
            ids = set(ids)
            ids.discard(channel_id)
            if ids:
                mx['_custom_alphas'] = list(ids)
                return
        except TypeError:
            pass
        del mx['_custom_alphas']


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alphas_remove(Operator):
    bl_idname = 'maxwell.custom_alphas_remove'
    bl_options = {'INTERNAL'}
    bl_label = "Remove Alpha"
    bl_description = "Remove the selected custom alpha channel"

    def execute(self, context):
        render = context.scene.maxwell.render
        channels = render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            channel_id = custom_alphas[i].id
            for ob in context.blend_data.objects:
                _custom_alpha_remove(ob, channel_id)
            for mat in context.blend_data.materials:
                _custom_alpha_remove(mat, channel_id)
            custom_alphas.remove(i)
            if i >= len(custom_alphas):
                channels.active_custom_alpha_index = i - 1
            if render.extra_sampling.channel_id == channel_id:
                render.extra_sampling.channel_id = 0
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_assign(Operator):
    bl_idname = 'maxwell.custom_alpha_assign'
    bl_options = {'INTERNAL'}
    bl_label = "Assign"
    bl_description = "Assign selected objects to the active custom alpha channel"

    def execute(self, context):
        channels = context.scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            channel_id = custom_alphas[i].id
            for ob in context.selected_objects:
                _custom_alpha_add(ob, channel_id)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_select(Operator):
    bl_idname = 'maxwell.custom_alpha_select'
    bl_options = {'INTERNAL'}
    bl_label = "Select"
    bl_description = "Select assigned objects to the active custom alpha channel"

    def execute(self, context):
        scene = context.scene
        channels = scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            channel_id = custom_alphas[i].id
            for ob in scene.objects:
                if channel_id in ob.maxwell.custom_alphas:
                    ob.select = True
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_deselect(Operator):
    bl_idname = 'maxwell.custom_alpha_deselect'
    bl_options = {'INTERNAL'}
    bl_label = "Deselect"
    bl_description = "Deselect assigned objects to the active custom alpha channel"

    def execute(self, context):
        scene = context.scene
        channels = scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            channel_id = custom_alphas[i].id
            for ob in scene.objects:
                if channel_id in ob.maxwell.custom_alphas:
                    ob.select = False
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_object_add(Operator):
    bl_idname = 'maxwell.custom_alpha_object_add'
    bl_options = {'INTERNAL'}
    bl_label = "Add"
    bl_description = "Add the object to the custom alpha channel"

    channel_id = IntProperty()
    remove = BoolProperty()

    def execute(self, context):
        if self.remove:
            _custom_alpha_remove(context.object, self.channel_id)
        else:
            _custom_alpha_add(context.object, self.channel_id)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_material_add(Operator):
    bl_idname = 'maxwell.custom_alpha_material_add'
    bl_options = {'INTERNAL'}
    bl_label = "Add"
    bl_description = "Add the material to the custom alpha channel"

    channel_id = IntProperty()
    remove = BoolProperty()

    def execute(self, context):
        if self.remove:
            _custom_alpha_remove(context.material, self.channel_id)
        else:
            _custom_alpha_add(context.material, self.channel_id)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_object_remove(Operator):
    bl_idname = 'maxwell.custom_alpha_object_remove'
    bl_options = {'INTERNAL'}
    bl_label = "Remove"
    bl_description = "Remove the object from the custom alpha channel"

    def execute(self, context):
        channels = context.scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            _custom_alpha_remove(context.object, custom_alphas[i].id)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_custom_alpha_material_remove(Operator):
    bl_idname = 'maxwell.custom_alpha_material_remove'
    bl_options = {'INTERNAL'}
    bl_label = "Remove"
    bl_description = "Remove the material from the custom alpha channel"

    def execute(self, context):
        channels = context.scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            _custom_alpha_remove(context.material, custom_alphas[i].id)
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_OT_extra_sampling_custom_alpha_set(Operator):
    bl_idname = 'maxwell.extra_sampling_custom_alpha_set'
    bl_options = {'INTERNAL'}
    bl_label = ""

    channel_id = IntProperty(
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    def execute(self, context):
        context.scene.maxwell.render.extra_sampling.channel_id = self.channel_id
        return {'FINISHED'}


_SCRIPT_HEADER = """// Animation script, created with B-Maxwell
var i = 0;
var mxsList = [
"""

_SCRIPT_FOOTER = """];
if (i < mxsList.length)
{
  renderScene();
}
function renderScene()
{
  var mxsFile = mxsList[i];
  Maxwell.print("rendering Mxs file:" + mxsFile);
  Maxwell.openMxs(mxsFile);
  Maxwell.startRender();
}
function renderHasFinished()
{
  Maxwell.print("finished")
  if (++i < mxsList.length)
    renderScene();
}
RenderEvents["renderFinished()"].connect(renderHasFinished);
"""


@MaxwellRenderEngine.register_class
class MAXWELL_OT_scene_export(ExportHelper, Operator):
    bl_idname = 'maxwell.scene_export'
    bl_label = "Export MXS"
    bl_options = set()

    def _update_frame_start(self, context):
        fs = self.frame_start
        sfs = context.scene.frame_start
        if fs < sfs:
            self.frame_start = sfs
        if fs > self.frame_end:
            self.frame_end = fs

    def _update_frame_end(self, context):
        fe = self.frame_end
        sfe = context.scene.frame_end
        if fe > sfe:
            self.frame_end = sfe
        if fe < self.frame_start:
            self.frame_start = fe

    filename_ext = ".mxs"
    filter_glob = StringProperty(
        default="*.mxs",
        options={'HIDDEN'}
    )

    protection = BoolProperty(
        name="Protect MXS",
        default=True
    )
    use_animation = BoolProperty(
        name="Animation"
    )
    use_frames = BoolProperty(
        name="Frames Range",
        description="Use custom frames range"
    )
    frame_start = IntProperty(
        name="Start",
        min=0, max=500000,
        update=_update_frame_start
    )
    frame_end = IntProperty(
        name="End",
        min=0, max=500000,
        update=_update_frame_end
    )
    use_animation_script = BoolProperty(
        name="Create Animation Script"
    )
    animation_script = StringProperty(
        name="Script Filename",
        subtype='FILE_NAME'
    )
    run = EnumProperty(
        name="Open with",
        description="After export open file in program",
        items=[
            ('NONE', "None", "Only export scene to .mxs file"),
            ('STUDIO', "Maxwell Studio", "After export open .mxs file in Maxwell Studio"),
            ('RENDER', "Maxwell Render", "After export open .mxs file in Maxwell Render"),
            #('NETWORK', "Maxwell Network", "After export run Maxwell Network Monitor and add scene to it queue")
        ],
        default='NONE'
    )
    command_line = StringProperty(
        name="Command Line"
    )
    priority = EnumProperty(
        name="Priority",
        items=[
            ('NORMAL', "Normal", "Normal", 0),
            ('LOW', "Low", "Low", 1)
        ],
        default='LOW'
    )

    def _open(self, mxs, prefs):
        if self.run == 'STUDIO':
            exe = prefs.STUDIO
            args = [mxs]
        elif self.run == 'RENDER':
            exe = prefs.MAXWELL
            args = ["-mxs:" + mxs] + self.command_line.split()
        else:
            return

        from sys import platform
        from subprocess import Popen

        if platform == 'darwin':
            args = ["open", "-a", exe, "--args"] + args
        else:
            args = [exe] + args
        Popen(args)

    def __init__(self):
        self._use_scene_frame_start = False
        self._use_scene_frame_end = False

    @classmethod
    def poll(cls, context):
        return MaxwellRenderEngine.is_active(context)

    def execute(self, context):
        from .engine import Logger, gen_filename, export_scene

        logger = Logger(report=self.report, context=context)

        if not self.filepath:
            logger("Empty path specified", {'WARNING'})
            return {'CANCELLED'}

        data = context.blend_data
        scene = context.scene
        render = scene.render
        scale = render.resolution_percentage / 100
        priority = self.properties.get('priority', 1)
        cmdline = self.command_line
        protection = self.protection

        frame_current = scene.frame_current
        is_animation = self.use_animation
        if is_animation:
            if self.use_frames:
                frames = [self.frame_start, self.frame_end]
            else:
                frames = [scene.frame_start, scene.frame_end]
            frames = sorted(frames)
            frames[1] += 1
            frames = range(*frames)
            create_script = self.use_animation_script
        else:
            frames = [frame_current]
            create_script = False

        dir, name = os.path.split(self.filepath)
        gfn = gen_filename(data, scene, name, ".mxs", is_animation)

        try:
            if create_script:
                if self.animation_script:
                    ms_path = os.path.join(dir, self.animation_script)
                    if not ms_path.lower().endswith(".ms"):
                        ms_path += ".ms"
                else:
                    ms_path = os.path.splitext(self.filepath)[0] + ".ms"
                with open(ms_path, "w") as sf:
                    sf.write(_SCRIPT_HEADER)

            for frame in frames:
                if frame != scene.frame_current:
                    scene.frame_set(frame, 0)

                mxs = export_scene(
                    data=context.blend_data,
                    scene=scene,
                    active_camera=scene.camera,
                    xres=int(render.resolution_x * scale),
                    yres=int(render.resolution_y * scale),
                    _log=logger,
                    is_animation=is_animation,
                )
                mxs.ProtectionEnabled = protection
                mxs.CommandLine = cmdline
                mxs.Priority = priority

                filepath = os.path.join(dir, gfn(frame))
                logger("MXS: %s" % filepath, {'INFO'})
                mxs.WriteMXS(filepath)

                if create_script:
                    with open(ms_path, "a") as sf:
                        sf.write("\t\"%s\",\n" % filepath)

            if create_script:
                with open(ms_path, "a") as sf:
                    sf.write(_SCRIPT_FOOTER)
                logger("MS: %s" % ms_path, {'INFO'})
        except Exception:
            logger("Export failed\n" + traceback.format_exc(), {'ERROR'})
            return {'CANCELLED'}
        finally:
            if frame != frame_current:
                scene.frame_set(frame_current, 0)

        if not is_animation:
            self._open(filepath, BMaxwellPreferences.prefs(context))

        return {'FINISHED'}

    def invoke(self, context, event):
        props = self.properties
        scene = context.scene
        # set default range from the scene
        s = props.get('frame_start')
        if s is None:
            self._use_scene_frame_start = True
            self.frame_start = scene.frame_start
        elif s < scene.frame_start:
            self.frame_start = scene.frame_start
        e = props.get('frame_end')
        if e is None:
            self._use_scene_frame_end = True
            self.frame_end = scene.frame_end
        elif e > scene.frame_end:
            self.frame_end = scene.frame_end
        return super().invoke(context, event)

    def cancel(self, context):
        if self._use_scene_frame_start:
            del self.properties['frame_start']
        if self._use_scene_frame_end:
            del self.properties['frame_end']

    def draw(self, context):
        layout = self.layout
        props = self.properties

        col = layout.column()
        col.prop(props, 'use_animation')
        if self.use_animation:
            col.prop(props, 'use_frames')
            if self.use_frames:
                row = col.row(align=True)
                row.prop(props, 'frame_start')
                row.prop(props, 'frame_end')
            col.prop(props, 'use_animation_script')
            if self.use_animation_script:
                col.prop(props, 'animation_script')
        else:
            col = layout.column()
            col.prop(props, 'run')

        layout.prop(props, 'priority')
        layout.prop(props, 'command_line')
        layout.prop(props, 'protection')

    @classmethod
    def register(cls):
        def menu_func(self, context):
            self.layout.operator_context = 'INVOKE_DEFAULT'
            self.layout.operator(cls.bl_idname, text="Maxwell Render (.mxs)")
        bpy.types.INFO_MT_file_export.append(menu_func)


@MaxwellRenderEngine.register_class
class MAXWELL_OT_scene_import(ImportHelper, Operator):
    bl_idname = 'maxwell.import_mxs'
    bl_label = "Import MXS"
    bl_description = "Import Maxwell Render scene from MXS file"

    filename_ext = ".mxs"
    filter_glob = StringProperty(
        default="*.mxs",
        options={'HIDDEN'}
    )

    def execute(self, context):
        data = context.blend_data
        scene = context.scene
        objs = {}

        from . import pymaxwell
        from .engine import ROTATION_MATRIX, ROTATION_MATRIX_INV

        mxs = pymaxwell.Scene()
        mxs.ReadMXS(self.filepath)

        it = pymaxwell.ObjectIterator()
        mxobj = it.First(mxs)
        while not mxobj.isNull:
            mesh = None
            name = mxobj.Name
            if mxobj.isMesh:
                nv = mxobj.NumVertexes
                if nv:
                    mesh = data.meshes.new(name)
                    mesh.vertices.add(nv)
                    for i in range(nv):
                        v = mxobj.GetVertex(i)
                        mesh.vertices[i].co = (v[0], -v[2], v[1])

                    vn = {}
                    nt = mxobj.NumTriangles
                    mesh.tessfaces.add(nt)
                    for i in range(nt):
                        v1, v2, v3, n1, n2, n3 = mxobj.GetTriangle(i)
                        vn[v1] = n1
                        vn[v2] = n2
                        vn[v3] = n3
                        f = mesh.tessfaces[i]
                        f.vertices = (v1, v2, v3, 0)
                        f.use_smooth = n1 != n2 or n2 != n3 or n3 != n1

                    nn = mxobj.NumNormals
                    norms = [mxobj.GetNormal(i) for i in range(nn)]
                    for v, n in vn.items():
                        mesh.vertices[v].normal = norms[n]

                    nuv = mxobj.NumChannelsUVW
                    for i in range(nuv):
                        uv_map = mesh.tessface_uv_textures.new()
                        for j in range(nt):
                            u1, v1, w1, u2, v2, w2, u3, v3, w3 = mxobj.GetTriangleUVW(j, i)
                            uv_map.data[j].uv_raw = (u1, -v1, u2, -v2, u3, -v3, 0.0, 0.0)
                    mesh.update()

            obj = data.objects.new(name, mesh)
            scene.objects.link(obj)
            objs[name] = obj

            mxp = mxobj.Parent
            if not mxp.isNull:
                obj.parent = objs[mxp.Name]

            m = Matrix(mxobj.WorldTransform)
            obj.matrix_world = ROTATION_MATRIX * m * ROTATION_MATRIX_INV

            hide = mxobj.Hide
            obj.hide_render = hide
            obj.hide = hide

            mxobj = it.Next()
        return {'FINISHED'}

    @classmethod
    def register(cls):
        def menu_func(self, context):
            self.layout.operator_context = 'INVOKE_DEFAULT'
            self.layout.operator(cls.bl_idname, text="Maxwell Render (.mxs)")

        bpy.types.INFO_MT_file_import.append(menu_func)

#endregion


#region Environment

@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_OT_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.environment_preset_add'
    bl_label = "Environment Presets"

    preset_menu = 'MAXWELL_MT_environment_presets'
    preset_subdir = "bmaxwell/environment"

    preset_defines = [
        "world = bpy.context.world",
        "world['maxwell'].clear()",
        "env = world.maxwell"
    ]

    preset_values = [
        "env.type",
        "env.sky_type",

        "env.constant.luminance",
        "env.constant.zenith",
        "env.constant.horizon",
        "env.constant.control_point",

        "env.physical.intensity",
        "env.physical.planet_reflectance",
        "env.physical.ozone",
        "env.physical.water",
        "env.physical.angstrom",
        "env.physical.wavelength",
        "env.physical.albedo",
        "env.physical.asymmetry",

        "env.sun.type",
        "env.sun.power",
        "env.sun.radius",
        "env.sun.temperature",
        "env.sun.color",
        "env.sun.position",
        "env.sun.latitude",
        "env.sun.longitude",
        "env.sun.date",
        "env.sun.time",
        "env.sun.gmt",
        "env.sun.rotation",
        "env.sun.zenith",
        "env.sun.azimuth",
        "env.sun.direction",
        "env.sun.direction_object",

        "env.ibl.intensity",
        "env.ibl.interpolation",
        "env.ibl.screen_mapping",

        "env.ibl.background.type",
        "env.ibl.background.map",
        "env.ibl.background.intensity",
        "env.ibl.background.scale",
        "env.ibl.background.offset",

        "env.ibl.reflection.type",
        "env.ibl.reflection.map",
        "env.ibl.reflection.intensity",
        "env.ibl.reflection.scale",
        "env.ibl.reflection.offset",

        "env.ibl.refraction.type",
        "env.ibl.refraction.map",
        "env.ibl.refraction.intensity",
        "env.ibl.refraction.scale",
        "env.ibl.refraction.offset",

        "env.ibl.illumination.type",
        "env.ibl.illumination.map",
        "env.ibl.illumination.intensity",
        "env.ibl.illumination.scale",
        "env.ibl.illumination.offset"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_OT_datetime_now(Operator):
    bl_idname = 'maxwell.environment_datetime_now'
    bl_label = "Now"
    bl_description = "Sets the Date and Time to your computer's current date and time"

    def execute(self, context):
        import time

        world = context.world
        sun = world.maxwell.sun
        t = time.localtime()
        sun.day = t.tm_yday
        sun.time = t.tm_hour + t.tm_min / 60 + t.tm_sec / 3600
        sun.gmt = -time.timezone / 3600
        world.update_tag()
        return {'FINISHED'}

#endregion


#region Camera

@MaxwellRenderEngine.register_class
class MAXWELL_CAMERA_OT_exposure_preset(Operator):
    bl_idname = 'maxwell.camera_exposure_preset'
    bl_label = "Maxwell Camera Exposure"
    bl_options = {'REGISTER', 'INTERNAL'}

    index = IntProperty()
    iso = FloatProperty()
    shutter = FloatProperty()
    fstop = FloatProperty()

    def execute(self, context):
        mx = context.camera.maxwell
        mx.expsure = self.index
        if self.index > 0:
            mx.exposure = self.index
            mx['iso'] = self.iso
            mx['shutter_type'] = 'SPEED'
            mx['shutter'] = self.shutter
            mx['fstop'] = self.fstop
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_CAMERA_OT_response_preset(Operator):
    bl_idname = 'maxwell.camera_response_preset'
    bl_label = "Maxwell Camera Response"
    bl_options = {'REGISTER', 'INTERNAL'}

    preset = StringProperty()

    def execute(self, context):
        context.camera.maxwell.response = self.preset
        return {'FINISHED'}

#endregion


#region Object

@MaxwellRenderEngine.register_class
class MAXWELL_OBJECT_OT_blocked_emitters(Operator):
    bl_idname = 'maxwell.object_blocked_emitters_add'
    bl_label = "Add / Remove blocked emitter"
    bl_options = {'INTERNAL', 'UNDO'}

    name = StringProperty(name="Name")
    remove_active = BoolProperty(name="Remove")

    def execute(self, context):
        ob = context.object
        mx = ob.maxwell
        blocked_emitters = mx.blocked_emitters
        if self.remove_active:
            try:
                i = mx.active_blocked_emitter_index
                blocked_emitters.remove(i)
                if i >= len(blocked_emitters):
                    mx.active_blocked_emitter_index = i - 1
            except Exception as e:
                self.report(type={'WARNING'}, message=str(e))
        else:
            i = len(blocked_emitters)
            emitter = blocked_emitters.add()
            emitter.name = self.name
            mx.active_blocked_emitter_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OBDATA_OT_uvsets_add(Operator):
    bl_idname = 'maxwell.obdata_uvsets_add'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Add"
    bl_description = "Add a new UV projection"

    def execute(self, context):
        mx = context.object.data.maxwell
        projections = mx.projections
        i = len(projections)
        projections.add()
        mx.active_projection_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OBDATA_OT_uvsets_remove(Operator):
    bl_idname = 'maxwell.obdata_uvsets_remove'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Remove"
    bl_description = "Remove the selected UV projection"

    def execute(self, context):
        mx = context.object.data.maxwell
        i = mx.active_projection_index
        projections = mx.projections
        if 0 <= i < len(projections):
            projections.remove(i)
            if i >= len(projections):
                mx.active_projection_index = i - 1
        return {'FINISHED'}

#endregion


#region Extensions

@MaxwellRenderEngine.register_class
class MAXWELL_OT_volumetric_adjust(Operator):
    bl_idname = 'maxwell.object_volumetric_adjust'
    bl_label = "Adjust"
    bl_description = "Adjust volumetric shape to the parent object bound box"

    @classmethod
    def poll(cls, context):
        ob = context.object
        return (ob and ob.type == 'EMPTY' and ob.parent is not None)

    def execute(self, context):
        ob = context.object
        par = ob.parent
        bb = par.bound_box
        v1 = Vector(bb[6])
        v2 = Vector(bb[0])
        v = (v1 - v2) / 2
        mw = par.matrix_world
        t, r, s = mw.decompose()
        nmw = Matrix([
            [v.x * s.x, 0, 0],
            [0, v.y * s.y, 0],
            [0, 0, v.z * s.z]
        ])
        nmw.rotate(r)
        nmw = nmw.to_4x4()
        nmw.translation = mw * ((v1 + v2) / 2)
        ob.matrix_world = nmw
        ob.empty_draw_size = 1.0
        ob.empty_draw_type = 'CUBE'
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_sea_import(Operator):
    bl_idname = 'maxwell.sea_import'
    bl_label = "Import Sea"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    action = bpy.props.EnumProperty(
        items=[
            ('SINGLE_FRAME', "Single frame", "Import single frame"),
            ('FRAMES_RANGE', "Frames range", "Import frames range")
        ],
        default='SINGLE_FRAME'
    )

    def __init__(self):
        self._break = False
        self._thread = None
        self._event = None
        self._timer = None
        self._verts = None
        self._trigs = None
        self._frame = None
        self.frame_current = 0

    def _bake(self, sea, start, end, quality, mc_file):
        import numpy
        import struct
        from . import pymaxwell
        from .engine import PerfCounter

        verts = None
        trigs = None
        mcf = None

        n = 2 ** (quality + 2)
        nverts = (n + 1) ** 2 + n // 2
        nframes = abs(end - start) + 1

        pcb = PerfCounter()
        self._log("Sea: frames=%d verts=%d" % (nframes, nverts))

        try:
            if mc_file:
                mc_file = bpy_abspath(mc_file)
                self._log("Sea: %s" % mc_file)
                mcf = open(mc_file, 'wb')
                mcf.write(b"POINTCACHE2\x00")
                mcf.write(struct.pack("iiffi", 1, nverts, start, 1.0, nframes))

            mxs = pymaxwell.Scene()
            mxs.AxisConversion = 'ZXY'
            mxs.SetSinglePrecisionOfGeometry()
            em = pymaxwell.ExtensionManager()

            params = {
                'Resolution': quality,
                'Reference Time': sea.time,
                'Vertical Scale': sea.vertical_scale,
                'Ocean Dim': sea.dimension,
                'Ocean Depth': sea.depth,
                'Ocean Seed': sea.seed,
                'Enable Choppyness': sea.choppyness,
                'Choppy factor': sea.choppy_factor,
                'Ocean Wind Mod.': sea.wind_speed,
                'Ocean Wind Dir.': sea.wind_direction,
                'Damp Factor Against Wind': sea.weight_against_wind,
                'Ocean Wind Alignment': sea.wind_alignment,
                'Ocean Min. Wave Length': sea.min_wave_length,
                'Repeat U': sea.repeat_u,
                'Repeat V': sea.repeat_v
            }
            ext = em.CreateGeometryLoader('MaxwellSea', params)
            mxobj = mxs.CreateGeometryLoader('Sea', ext)
            if self._break:
                return
            i = 1 if start <= end else -1
            for f in range(start, end + i, i):
                self._frame = f

                self._event.wait()
                if self._break:
                    break
                self._event.clear()

                pc = PerfCounter()

                mxobj.SetGeometryLoaderParams({'Reference Time': sea.time})
                self._log("Sea: t=%f rt=%f f=%d" % (pc.next(), sea.time, f))
                if self._break:
                    break

                vbuf = numpy.array(mxobj.VerticesBuffer, copy=False)
                self._log("Sea: t=%f vbuf" % pc.next())
                if f == start:
                    verts = vbuf[0].copy()  # must be copy
                    self._log("Sea: t=%f verts" % pc.next())
                    trigs = numpy.array(mxobj.TrianglesBuffer)
                    self._log("Sea: t=%f trigs" % pc.next())
                if self._break:
                    break

                if mcf is not None:
                    mcf.write(vbuf[0])
                    self._log("Sea: t=%f file" % pc.next())

            if not self._break:
                self._verts = verts
                self._trigs = trigs
        finally:
            if mcf is not None:
                mcf.close()
        self._log("Sea: thread t=%f" % pcb())

    def cancel(self, context):  # called by blender, i.e. on closing
        self._log("Sea: cancel")

        wm = context.window_manager
        wm.event_timer_remove(self._timer)

        self._break = True
        self._event.set()
        self._thread.join()

        context.scene.frame_set(self.frame_current)
        wm.progress_end()

    def modal(self, context, event):
        if event.type == 'ESC':
            self.cancel(context)
            return {'CANCELLED'}

        if self._thread.is_alive():
            if event.type == 'TIMER':
                scene = context.scene
                if self._frame != scene.frame_current:
                    scene.frame_set(self._frame)
                    self._event.set()
                context.window_manager.progress_update(self._frame)
            return {'RUNNING_MODAL'}

        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        context.scene.frame_set(self.frame_current)

        if self._verts is None or self._trigs is None:
            return {'CANCELLED'}

        mesh = context.mesh
        if mesh is None:
            if context.object.type != 'MESH':
                self._log("Not a mesh", {'WARNING'})
                return {'CANCELLED'}
            mesh = context.object.data

        import bmesh
        from .engine import PerfCounter

        pc = PerfCounter()

        # fast clear the existing mesh
        bm = bmesh.new()
        bm.verts.new()
        bm.to_mesh(mesh)

        # load new geometry data
        verts = self._verts
        verts[:, 2] *= -1.0
        verts[:, 1:] = verts[:, :0:-1]
        mesh.vertices.add(len(verts) - 1)
        mesh.vertices.foreach_set('co', verts.reshape(-1))
        mesh.tessfaces.add(len(self._trigs))
        mesh.tessfaces.foreach_set('vertices', self._trigs.reshape(-1))
        mesh.update()

        self._log("Sea: mesh t=%f\n" % pc())

        if self.action == 'FRAMES_RANGE':
            sea = mesh.maxwell.sea
            mods = context.object.modifiers
            mod = mods.get(sea.mc_modifier)
            if mod is None or mod.type != 'MESH_CACHE':
                mod = mods.new(sea.mc_modifier, 'MESH_CACHE')
                sea.mc_modifier = mod.name
                mod.cache_format = 'PC2'
                mod.filepath = sea.mc_file
                mod.forward_axis = 'POS_Z'
                mod.up_axis = 'NEG_Y'

        wm.progress_end()
        return {'FINISHED'}

    def execute(self, context):
        import threading
        from .engine import Logger

        self._log = Logger(report=self.report, context=context)

        wm = context.window_manager
        scene = context.scene
        mesh = context.mesh
        if mesh is None:
            if context.object.type != 'MESH':
                self._log("Not a mesh", {'WARNING'})
                return {'CANCELLED'}
            mesh = context.object.data
        sea = mesh.maxwell.sea

        frame_current = scene.frame_current
        self.frame_current = frame_current
        if self.action == 'SINGLE_FRAME':
            sf = ef = frame_current
            quality = sea.get('quality', 6)
            mc_file = False
        elif self.action == 'FRAMES_RANGE':
            sf, ef = sea.mc_frames
            quality = sea.get('mc_quality', 4)
            mc_file = sea.mc_file
            # save defaults values to rna properties
            sea.mc_quality = str(quality)
            sea.mc_file = mc_file
        else:
            self._log("Invalid action", {'ERROR'})
            return {'CANCELLED'}
        self._frame = sf

        wm.progress_begin(sf, ef + 1)

        self._event = threading.Event()
        self._thread = threading.Thread(
            target=self._bake,
            args=(sea, sf, ef, quality, mc_file)
        )
        if frame_current != sf:
            scene.frame_set(sf)
        self._break = False
        self._thread.start()
        self._event.set()

        self._timer = wm.event_timer_add(0.1, context.window)

        wm.modal_handler_add(self)
        print("bla")
        return {'RUNNING_MODAL'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_grass_presets(AddPresetBase, Operator):
    bl_idname = 'maxwell.grass_preset_add'
    bl_label = "Add Grass Preset"

    preset_menu = 'MAXWELL_MT_grass_presets'
    preset_subdir = "bmaxwell/particles/grass"

    preset_defines = [
        "mx = bpy.context.object.particle_systems.active.settings.maxwell",
        "grass = mx.grass",
    ]

    preset_values = [
        "grass.type",
        "grass.blade_points",
        "grass.density",
        "grass.length",
        "grass.length_var",
        "grass.root_width",
        "grass.tip_width",
        "grass.direction",
        "grass.angle",
        "grass.angle_var",
        "grass.start_bend",
        "grass.start_bend_var",
        "grass.bend_radius",
        "grass.bend_radius_var",
        "grass.bend_angle",
        "grass.bend_angle_var",
        "grass.cut_off",
        "grass.cut_off_var"
    ]


@MaxwellRenderEngine.register_class
class MAXWELL_OT_grass_import(Operator):
    bl_idname = 'maxwell.grass_import'
    bl_label = "Import Grass"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        from . import pymaxwell
        from .engine import Textures, object_uvsets

        scene = context.scene
        ob = context.object
        ps = context.particle_system

        us = scene.unit_settings
        scale = us.scale_length if us.system != 'NONE' else 1.0

        pss = ps.settings
        grass = pss.maxwell.grass
        params = {
            # --- Primitive ---
            'Material': None,
            'Double Sided Material': None,
            'Primitive Type': grass.get('type', 0),
            'Points per Blade': grass.blade_points,
            # --- Grass Density ---
            'Density': grass.density,
            'Seed': grass.seed,
            # --- Blade Length ---
            'Length': grass.length,
            'Length Variation': grass.length_var,
            # --- Width ---
            'Root Width': grass.root_width,
            'Tip Width': grass.tip_width,
            # --- Angle ---
            'Direction Type': grass.get('direction', 0),
            'Initial Angle': grass.angle,
            'Initial Angle Variation': grass.angle_var,
            # --- Bend ---
            'Start Bend': grass.start_bend,
            'Start Bend Variation': grass.start_bend_var,
            'Bend Radius': grass.bend_radius,
            'Bend Radius Variation': grass.bend_radius_var,
            'Bend Angle': grass.bend_angle,
            'Bend Angle Variation': grass.bend_angle_var,
            # --- Cut off ---
            'Cut Off': grass.cut_off,
            'Cut Off Variation': grass.cut_off_var,
            # --- Level of Detail ---
            'Enable LOD': grass.lod_enabled,
            'LOD Min Distance': grass.lod_min,
            'LOD Max Distance': grass.lod_max,
            'LOD Max Distance Density': grass.lod_max_density,
            # --- Display ---
            'Display Percent': grass.display_percent,
            'Display Max. Blades': grass.display_blades,
        }
        textures = Textures(context.blend_data.textures)
        for param, map_name in [('Density Map', grass.density_map),
                                ('Length Map', grass.length_map),
                                ('Initial Angle Map', grass.angle_map),
                                ('Start Bend Map', grass.start_bend_map),
                                ('Bend Radius Map', grass.bend_radius_map),
                                ('Bend Angle Map', grass.bend_angle_map),
                                ('Cut Off Map', grass.cut_off_map)]:
            if map_name:
                tex = textures.get_by_name(map_name, True)
                if tex:
                    params[param] = tex

        mxs = pymaxwell.Scene()
        mxs.AxisConversion = 'ZXY'
        mxs.SetSinglePrecisionOfGeometry()

        mesh = ob.to_mesh(scene, True, 'RENDER', False)
        try:
            mesh.calc_normals_split()
            mesh.calc_tessface()
            args = {
                'name': mesh.name,
                'mesh': mesh.as_pointer(),
                'mats': []
            }
            uvsets = object_uvsets(scene, ob)
            if uvsets:
                args['uvs'] = uvsets
            mxob = mxs.ImportMesh(**args)
            if mxob is None:
                self.report({'WARNING'}, "Mesh without triangles")
                return {'CANCELED'}
        finally:
            context.blend_data.meshes.remove(mesh)

        mxob.BaseAndPivot = {'base': ob.matrix_world * scale}

        em = pymaxwell.ExtensionManager()
        ext = em.CreateGeometryModifier('MaxwellGrass', params)
        mxob.ApplyGeometryModifier(ext)

        def update_psys(nlines, hair_step):
            pss.emit_from = 'FACE'
            pss.count = nlines
            pss.hair_step = hair_step
            pss.hair_length = grass.length / (scale * 100.0)
            bpy.ops.particle.edited_clear()

        mxob.ExportGrass(ext, ps, update_psys, 1.0 / scale)
        ob.update_tag({'OBJECT'})

        bpy.ops.particle.connect_hair()
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_visualizer(Operator):
    bl_idname = 'maxwell.visualization_enable'
    bl_label = "Enable Visualization"
    bl_description = "Enabled / Disable visualization of maxwell extension objects and ies emitters"
    bl_options = {'INTERNAL'}

    _handle = None
    _visualizer = None

    @classmethod
    def is_enabled(cls):
        return cls._handle is not None

    @classmethod
    def _draw(cls, context):
        try:
            if MaxwellRenderEngine.is_active(context) and context.mode == 'OBJECT':
                cls._visualizer.Draw(
                    context.scene.as_pointer(),
                    context.space_data.as_pointer(),
                    context.region_data.as_pointer()
                )
        except Exception as e:
            bpy.ops.maxwell.report(type={'WARNING'}, message=str(e))

    def cancel(self, context):
        SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        MAXWELL_OT_visualizer._visualizer = None
        MAXWELL_OT_visualizer._handle = None

    def modal(self, context, event):
        return {'PASS_THROUGH'} if self._handle else {'PASS_THROUGH', 'FINISHED'}

    def execute(self, context):
        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()

        if self._handle:
            self.cancel(context)
            return {'FINISHED'}

        from . import pymaxwell
        from os.path import join, dirname

        d = join(dirname(__file__), "shaders")

        def shader_source(n):
            try:
                with open(join(d, n), 'r') as f:
                    return f.read()
            except:
                return None

        vsrc = shader_source("vertex.glsl")
        gsrc = shader_source("geometry.glsl")
        fsrc = shader_source("fragment.glsl")

        MAXWELL_OT_visualizer._visualizer = pymaxwell.Visualizer(
            context.blend_data.as_pointer(), vsrc, gsrc, fsrc,
        )
        MAXWELL_OT_visualizer._handle = SpaceView3D.draw_handler_add(
            self._draw, (context, ), 'WINDOW', 'POST_VIEW'
        )
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_vdb_grids_add(Operator):
    bl_idname = 'maxwell.vdb_grids_add'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Add"
    bl_description = "Add a new vdb grid"

    def execute(self, context):
        mx = context.object.maxwell.volumetric
        grids = mx.vdb_grids
        n = 1
        name = "Grid.001"
        while grids.find(name) >= 0:
            name = "Grid.%03d" % n
            n += 1
        i = len(grids)
        grid = grids.add()
        grid['name'] = name
        grid.base_grid = "density"
        mx.active_vdb_grid_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_vdb_grids_remove(Operator):
    bl_idname = 'maxwell.vdb_grids_remove'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Add"
    bl_description = "Remove the selected vdb grid"

    def execute(self, context):
        mx = context.object.maxwell.volumetric
        grids = mx.vdb_grids
        i = mx.active_vdb_grid_index
        if 0 <= i < len(grids):
            grids.remove(i)
            if i >= len(grids):
                mx.active_vdb_grid_index = i - 1
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_vdb_uv_grids_add(Operator):
    bl_idname = 'maxwell.vdb_uv_grids_add'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Add"
    bl_description = "Add a new uv grid"

    def execute(self, context):
        grid = context.maxwell_vdb_grid
        uv_grids = grid.uv_grids
        i = len(uv_grids)
        uv = uv_grids.add()
        uv.name = "density"
        grid.active_uv_grid_index = i
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class MAXWELL_OT_vdb_uv_grids_remove(Operator):
    bl_idname = 'maxwell.vdb_uv_grids_remove'
    bl_options = {'INTERNAL', 'UNDO'}
    bl_label = "Add"
    bl_description = "Remove the selected uv grid"

    def execute(self, context):
        grid = getattr(context, 'maxwell_vdb_grid', None)
        if grid is not None:
            uv_grids = grid.uv_grids
            i = grid.active_uv_grid_index
            if 0 <= i < len(uv_grids):
                uv_grids.remove(i)
                if i >= len(uv_grids):
                    grid.active_uv_grid_index = i - 1
        return {'FINISHED'}

#endregion


#region Headus UVLayout

@MaxwellRenderEngine.register_class
class HEADUS_UVLAYOUT_OT_export(ExportHelper, Operator):
    bl_idname = 'headus_uvlayout.export'
    bl_options = set()
    bl_label = "Export"
    bl_description = "Export or create UV map in Headus UVLayout"

    filename_ext = ".obj"
    filter_glob = StringProperty(
        default="*.obj",
        options={'HIDDEN'}
    )

    @classmethod
    def poll(cls, context):
        mesh = context.mesh
        return mesh and mesh.uv_layers.active

    def invoke(self, context, event):
        filepath = context.blend_data.filepath
        if filepath:
            mesh = context.mesh
            name = "%s-%s%s" % (
                bpy.path.clean_name(mesh.name),
                bpy.path.clean_name(mesh.uv_layers.active.name),
                self.filename_ext
            )
            self.filepath = os.path.join(os.path.split(filepath)[0], name)
        else:
            self.filename = "unknown"
        return super().invoke(context, event)

    def execute(self, context):
        try:
            uvs = {}
            mesh = context.mesh
            uv_data = mesh.uv_layers.active.data
            with open(self.filepath, "w") as file:
                for v in mesh.vertices:
                    file.write("v %f %f %f\n" % (v.co[0], -v.co[2], v.co[1]))
                for d in uv_data:
                    t = d.uv[:]
                    if not t in uvs:
                        file.write("vt %f %f\n" % t)
                        uvs[t] = len(uvs)
                for p in mesh.polygons:
                    line = ""
                    for i in p.loop_indices:
                        loop = mesh.loops[i]
                        v1 = loop.vertex_index + 1
                        v2 = uvs[uv_data[loop.index].uv[:]] + 1
                        line += " %d/%d" % (v1, v2)
                    if line:
                        file.write("f%s\n" % line)
            self.report(type={'INFO'}, message="Headus UVLayout: %s" % self.filepath)
        except Exception as ex:
            self.report(type={'WARNING'}, message="Exception: {0}".format(ex))
        return {'FINISHED'}


@MaxwellRenderEngine.register_class
class HEADUS_UVLAYOUT_OT_import(ImportHelper, Operator):
    bl_idname = 'headus_uvlayout.import'
    bl_label = "Import"
    bl_description = "Update the selected UV Map from an existing file"

    filename_ext = ".obj"
    filter_glob = StringProperty(
        default="*.obj",
        options={'HIDDEN'}
    )

    @classmethod
    def poll(cls, context):
        mesh = context.mesh
        return mesh and mesh.uv_layers.active

    def execute(self, context):
        verts = []
        faces = []
        with open(self.filepath, 'rb') as file:
            for line in file:
                data = line.split()
                if data:
                    s = data[0]
                    if s == b'vt':
                        v = float(data[1]), float(data[2])
                        verts.append(v)
                    elif s == b'f':
                        f = [t.split(b'/') for t in data[1:]]
                        faces.append(f)
        # TODO: Add validation for number of vertices and faces in uv
        mesh = context.mesh
        uv_map = mesh.uv_layers.active.data
        for i, polygon in enumerate(mesh.polygons):
            for j, loop_index in enumerate(polygon.loop_indices):
                k = int(faces[i][j][1])
                loop = mesh.loops[loop_index]
                uv_map[loop.index].uv = verts[k - 1]
        return {'FINISHED'}

#endregion
