# -*- coding: utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Ildar Nikolaev"
__email__ = "nildar@users.sourceforge.net"

import os
import sys
import time
import numpy
import ctypes
import traceback

from math import radians, modf
from mathutils import (
    Matrix,
    Euler,
    Vector,
    geometry
)

import bpy
from bpy.path import abspath as bpy_abspath

from . import (
    MaxwellRenderEngine,
    BMaxwellPreferences,
    pymaxwell
)

_M = 1 / 255

#ROTATION_MATRIX = Matrix.Rotation(radians(90.0), 4, 'X')
ROTATION_MATRIX = Matrix([
    [ 1,  0,  0,  0],
    [ 0,  0, -1,  0],
    [ 0,  1,  0,  0],
    [ 0,  0,  0,  1],
])
#ROTATION_MATRIX_INV = Matrix.Rotation(radians(-90.0), 4, 'X')
#ROTATION_MATRIX_INV = ROTATION_MATRIX.inverted()
ROTATION_MATRIX_INV = Matrix([
    [ 1,  0,  0,  0],
    [ 0,  0,  1,  0],
    [ 0, -1,  0,  0],
    [ 0,  0,  0,  1],
])

MATERIALS_DATABASE = os.environ.get(
    'MAXWELL3_MATERIALS_DATABASE',
    "/Applications/Maxwell 3/materials database" if sys.platform == 'darwin' else ""
)
_STATS_FMT = "SL: {:.02f} | Next SL: {} | Update: {} | Time Passed: {} | Time Left: {} | Benchmark: {:.02f}"

_request_license = True


class PerfCounter:
    def __init__(self):
        self._counter = time.perf_counter()

    def __call__(self):
        _counter = time.perf_counter()
        result = _counter - self._counter
        self._counter = _counter
        return result

    def next(self):
        return time.perf_counter() - self._counter


class Logger:
    def __init__(self, verbose=None, report=None, context=None):
        if verbose is None:
            verbose = BMaxwellPreferences.prefs(context).verbose_output
        self.verbose = verbose
        if report is None:
            report = bpy.ops.maxwell.report
        self.report = report

    def __call__(self, text, type=None):
        """Log message
        Arguments:
            text (str): message.
            type (set): message type.
        """
        if self.verbose:
            print("[BMAXWELL: {0}] {1}".format(time.strftime('%Y-%b-%d %H:%M:%S'), text))
        if type is not None:
            self.report(type=type, message=text)


class MxPath:
    def __init__(self, data):
        self._data = data
        self._default = None

    @property
    def default(self):
        _default = self._default
        if _default is None:
            if self._data.filepath:
                _default = os.path.splitext(os.path.basename(self._data.filepath))[0]
            else:
                _default = "unknown"
            self._default = _default
        return _default

    def __call__(self, path, ext=None):
        result = bpy_abspath(path)
        if result:
            directory, name = os.path.split(result)
            if name:
                if ext and not result.lower().endswith(ext.lower()):
                    result += ext
            else:
                result = os.path.join(directory, self.default)
                if ext:
                    result += ext
        else:
            result = self.default
            if ext:
                result += ext
        return result

def gen_filename(data, scene, name, ext, is_animation=False):
    if name:
        _name, _ext = os.path.splitext(name)
        if ext.lower() != _ext.lower():
            _name = name
            _ext = ext
    else:
        if data.filepath:
            _name = os.path.splitext(os.path.basename(data.filepath))[0]
        else:
            _name = "unknown"
        _ext = ext
    i = _name.rfind("#")
    if i < 0:
        if is_animation:
            _digits = max(6, len(str(scene.frame_end)))
            gen = lambda f: "{0}_{2:0{3}}{1}".format(_name, _ext, f, _digits)
        else:
            gen = lambda f: _name + _ext
    else:
        n = _name[:i].rstrip("#")
        gen = lambda f: "{0}{3:0{4}}{1}{2}".format(n, _name[i + 1:], _ext, f, i - len(n) + 1)
    return gen


class Textures:
    def __init__(self, textures):
        self._textures = textures
        self._mxts = {}

    def get(self, tex, add_procedurals):
        name = tex.name
        mxt = self._mxts.get(name)
        if mxt is None:
            mxt = self.create(tex, add_procedurals)
            self._mxts[name] = mxt
        return mxt

    def get_by_name(self, name, add_procedurals):
        mxt = self._mxts.get(name)
        if mxt is None:
            tex = self._textures.get(name)
            if tex is not None:
                mxt = self.create(tex, add_procedurals)
                self._mxts[name] = mxt
        return mxt

    def create(self, tex, add_procedurals):
        if tex.type == 'IMAGE':
            img = tex.image
            mx = tex.maxwell
            p = mx.projection
            mxt = pymaxwell.Texture(
                # Bitmap Properties
                path=img.filepath_from_user() if img else None,
                # Projection Properties
                globalMap=mx.override,
                channel=p.channel,
                uIsTiled=p.tile_x,
                vIsTiled=p.tile_y,
                absolute=p.get('units', 0),
                scale=p.repeat,
                uIsMirrored=p.mirror_x,
                vIsMirrored=p.mirror_y,
                offset=p.offset,
                rotation=p.rotation,
                # Image Properties
                flipRed=mx.flip_x,
                flipGreen=mx.flip_y,
                fullRange=mx.wide,
                #gamma=mx.gamma,
                invert=mx.invert,
                alpha=mx.alpha_only,
                interpolation=mx.interpolation,
                brightness=mx.brightness / 100,
                saturation=mx.saturation / 100,
                contrast=mx.contrast / 100,
                hue=mx.hue / 100,
                clampMin=mx.clamp[0] / 255,
                clampMax=mx.clamp[1] / 255,
                #cosA=mx.cosA,
                #sinA=mx.sinA
            )
            if add_procedurals:
                self.export_prcedurals(mxt, mx.procedurals)
            return mxt
        return None

    def export_prcedurals(self, mxt, procedurals):
        em = pymaxwell.ExtensionManager()
        for p in procedurals:
            pt = p.type
            if pt == 'Brick':
                brick = p.brick
                params = {
                    'Blend procedural': brick.blend,
                    'Brick width': brick.width,
                    'Brick height': brick.height,
                    'Brick offset': brick.brick_offset,
                    'Random offset': brick.random_offset,
                    'Double brick': brick.double,
                    'Small brick width': brick.small_width,
                    'Round corners': brick.round_corners,
                    'Boundary sharpness U': brick.sharpness_u,
                    'Boundary sharpness V': brick.sharpness_v,
                    'Boundary noise detail': brick.noise_detail,
                    'Boundary noise region U': brick.noise_region_u,
                    'Boundary noise region V': brick.noise_region_v,
                    'Seed': brick.seed,
                    'Random rotation': brick.random_rotation,
                    'Color variation': brick.color_variation,
                    'Brick color 0': brick.color0,
                    'Sampling factor 0': brick.factor0,
                    'Weight 0': brick.weight0,
                    'Brick color 1': brick.color1,
                    'Sampling factor 1': brick.factor1,
                    'Weight 1': brick.weight1,
                    'Brick color 2': brick.color2,
                    'Sampling factor 2': brick.factor2,
                    'Weight 2': brick.weight2,
                    'Mortar thickness': brick.mortar_thickness,
                    'Mortar color': brick.mortar_color,
                }
                maps = (
                    ('Brick texture 0', brick.texture0),
                    ('Brick texture 1', brick.texture1),
                    ('Brick texture 2', brick.texture2),
                    ('Mortar texture', brick.mortar_texture)
                )
                _name = procedurals.id_data.name
                for param, name in maps:
                    if name and name != _name:  # avoid recursion
                        _mxt = self.get_by_name(name, False)
                        if _mxt:
                            params[param] = _mxt
            elif pt == 'Checker':
                checker = p.checker
                params = {
                    'Blend procedural': checker.blend,
                    'Color0': checker.color0,
                    'Color1': checker.color1,
                    'Number of elements U': checker.checks_u,
                    'Number of elements V': checker.checks_v,
                    'Transition sharpness': checker.sharpness,
                    'Fall-off': checker.get('fall_off', 0)
                }
            elif pt == 'Circle':
                circle = p.circle
                params = {
                    'Blend procedural': circle.blend,
                    'Background color': circle.background,
                    'Circle color': circle.circle,
                    'RadiusU': circle.radius_u,
                    'RadiusV': circle.radius_v,
                    'Transition factor': circle.sharpness,
                    'Fall-off': circle.get('fall_off', 0)
                }
            elif pt == 'Gradient3':
                gradient3 = p.gradient3
                params = {
                    'Blend procedural': gradient3.blend,
                    'Gradient U': gradient3.use_u,
                    'Color0 U': gradient3.start_u,
                    'Color1 U': gradient3.middle_u,
                    'Color2 U': gradient3.end_u,
                    'Color1 U position': gradient3.position_u,
                    'Gradient type U': gradient3.get('type_u', 0),
                    'Gradient V': gradient3.use_v,
                    'Color0 V': gradient3.start_v,
                    'Color1 V': gradient3.middle_v,
                    'Color2 V': gradient3.end_v,
                    'Color1 V position': gradient3.position_v,
                    'Gradient type V': gradient3.get('type_v', 0),
                }
            elif pt == 'Gradient':
                gradient = p.gradient
                params = {
                    'Blend procedural': gradient.blend,
                    'Gradient U': gradient.use_u,
                    'Color0 U': gradient.start_u,
                    'Color1 U': gradient.end_u,
                    'Transition factor U': gradient.position_u,
                    'Gradient type U': gradient.get('type_u', 0),
                    'Gradient V': gradient.use_v,
                    'Color0 V': gradient.start_v,
                    'Color1 V': gradient.end_v,
                    'Transition factor V': gradient.position_v,
                    'Gradient type V': gradient.get('type_v', 0),
                }
            elif pt == 'Grid':
                grid = p.grid
                params = {
                    'Blend procedural': grid.blend,
                    'Cell color': grid.cell,
                    'Boundary color': grid.background,
                    'Cell width': grid.width,
                    'Cell height': grid.height,
                    'Boundary thickness U': grid.thickness_u,
                    'Boundary thickness V': grid.thickness_v,
                    'Transition sharpness': grid.sharpness,
                    'Fall-off': grid.get('fall_off', 0)
                }
            elif pt == 'Marble':
                marble = p.marble
                params = {
                    'Blend procedural': marble.blend,
                    'Coordinates type': marble.get('coordinates', 0),
                    'Seed': marble.seed,
                    'Frequency': marble.frequency,
                    'Detail': marble.detail,
                    'Octaves': marble.octaves,
                    'Color0': marble.color0,
                    'Color1': marble.color1,
                    'Color2': marble.color2
                }
            elif pt == 'Noise':
                noise = p.noise
                params = {
                    'Blend procedural': noise.blend,
                    'Coordinates type': noise.get('coordinates', 0),
                    'Seed': noise.seed,
                    'Low value': noise.low_clip,
                    'High value': noise.hight_clip,
                    'Octaves': noise.octaves,
                    'Persistance': noise.persistance,
                    'Detail': noise.detail,
                    'Noise color': noise.noise,
                    'Background color': noise.background
                }
            elif pt == 'Voronoi':
                voronoi = p.voronoi
                params = {
                    'Blend procedural': voronoi.blend,
                    'Coordinates type': voronoi.get('coordinates', 0),
                    'Low value': voronoi.low_clip,
                    'High value': voronoi.hight_clip,
                    'Seed': voronoi.seed,
                    'Detail': voronoi.detail,
                    'Distance': voronoi.get('distance', 0),
                    'Combination': voronoi.get('combination', 0),
                    'Color0': voronoi.cell,
                    'Color1': voronoi.background
                }
            elif pt == 'TiledTexture':
                tiled = p.tiled
                params = {
                    'Blend factor': tiled.blend,
                    'Base Color': tiled.base,
                    'Use base color': tiled.use_base,
                    'FileName': tiled.filename,
                    'Filename_mask': tiled.mask,
                }
            elif pt == 'WireframeTexture':
                wire = p.wireframe
                params = {
                    'Fill Color': wire.fill_color,
                    'Edge Color': wire.edge_color,
                    'Coplanar Edge Color': wire.coplanar_edge_color,
                    'Edge Width': wire.edge_width,
                    'Coplanar Edge Width': wire.coplanar_edge_width,
                    'Coplanar Threshold': wire.coplanar_threshold
                }
            else:
                continue
            params['EXTENSION_ISENABLED'] = p.enabled
            ext = em.CreateTexture(pt, params)
            mxt.AddProcedural(ext)

    def as_value_attribute(self, value, tex_name, tex_enabled=True):
        if tex_name:
            mxtex = self.get_by_name(tex_name, True)
            if mxtex is not None and not mxtex.isEmpty:
                return pymaxwell.Attribute(
                    type=2 if tex_enabled else 0,
                    texture=mxtex,
                    value=value
                )
        return pymaxwell.Attribute(type=0, value=value)

    def as_color_attribute(self, color, tex_name, tex_enabled=True):
        if tex_name and tex_enabled:
            mxtex = self.get_by_name(tex_name, True)
            if mxtex is not None and not mxtex.isEmpty:
                return pymaxwell.Attribute(
                    type=2 if tex_enabled else 1,
                    texture=mxtex,
                    color=color
                )
        return pymaxwell.Attribute(type=1, color=color)


class _ChildParticle(ctypes.Structure):
    _fields_ = [
        ('num', ctypes.c_int),
        ('parent', ctypes.c_int),
        ('pa', ctypes.c_int * 4),
        ('w', ctypes.c_float * 4),
        ('fuv', ctypes.c_float * 4),
        ('foffset', ctypes.c_float),
        ('rt', ctypes.c_float)
    ]


def temporary_directory(context=None):
    if context is None:
        context = bpy.context
    dir = context.user_preferences.filepaths.temporary_directory
    if not dir:
        dir = os.environ.get('TEMP')
        if not dir:
            dir = os.environ.get('TMP', '/tmp')
    return dir

def export_material(mxm, mat, textures):
    """Export blender material to maxwell material

    mxm (maxwell.Material): maxwell material.
    mat (bpy.types.Material): blender material.
    textures (Textures): .
    """
    mx_mat = mat.maxwell
    mx_type = mx_mat.type
    if mx_type == 'FILE':
        path = mx_mat.mxm
        if path:
            path = bpy_abspath(path)
        if mx_mat.embed and path:
            mxm.Read(path)
        else:
            mxm.Reference = (path, bool(path))
    else:
        mx_map = mx_mat.override_map
        mxm.GlobalMap = pymaxwell.Texture(
            channel=mx_map.channel,
            uIsTiled=mx_map.tile_x,
            vIsTiled=mx_map.tile_y,
            absolute=mx_map.get('units', False),
            scale=mx_map.repeat,
            uIsMirrored=mx_map.mirror_x,
            vIsMirrored=mx_map.mirror_y,
            offset=mx_map.offset,
            rotation=mx_map.rotation
        )

        mxm.Bump = textures.as_value_attribute(mx_mat.bump, mx_mat.bump_map)
        mxm.NormalMapState = mx_mat.bump_normal

        mxm.Matte = mx_mat.matte
        mxm.MatteShadow = mx_mat.shadow
        mxm.NestedPriority = mx_mat.nested_priority
        mxm.Dispersion = mx_mat.dispersion
        mxm.ColorID = mx_mat.color_id

        if mx_type == 'CUSTOM':
            ##############################
            # Displacement
            d = mx_mat.displacement
            if d.enabled:
                mxm_d = mxm.Displacement
                mxm_d.Enabled = True  # d.enabled
                mxm_d.Map = textures.get_by_name(d.map, True)
                mxm_d.Parameters = {
                    'type': d.get('type', 1),
                    'level': d.level,
                    'smooth': d.smooth,
                    'offset': d.offset,
                    'method': d.get('method', 0),
                    'uvi': d.get('uvi', 2)
                }
                mxm_d.HeightMap = {
                    'absolute': d.absolute,
                    'height': d.height / 100 if d.absolute else d.height,
                    'adaptive': d.adaptive
                }
                mxm_d.Vector = {
                    'scale': d.scale,
                    'transform': d.get('transform', 0),
                    'mapping': d.get('mapping', 0),
                    'preset': d.get('preset', 0)
                }
            ##############################
            # Layers
            for layer in mx_mat.layers:
                mxm_layer = mxm.AddLayer()
                mxm_layer.Name = layer.name
                mxm_layer.Enabled = layer.enabled
                mxm_layer.Blending = layer.get('blend', 0)
                mxm_layer.Opacity = textures.as_value_attribute(
                    layer.opacity, layer.opacity_map, layer.opacity_map_enabled
                )
                ##############################
                # Emitter
                emitter = layer.emitter
                if emitter.enabled:
                    mxm_emitter = mxm_layer.CreateEmitter()

                    mxm_emitter.Enabled = True
                    mxm_emitter.Type = emitter.get('type', 0)

                    lobe = mxm_emitter.Lobe
                    lobe.Type = emitter.get('lobe', 0)
                    # IES
                    lobe.IES = bpy_abspath(emitter.ies)
                    lobe.Intensity = emitter.intensity
                    # Spot
                    spot = emitter.spot
                    mxtex = textures.get_by_name(spot.map, True)
                    if mxtex:
                        lobe.Image = (spot.map_enabled, mxtex)
                    lobe.SpotConeAngle = spot.cone_angle
                    lobe.SpotFallOffAngle = spot.falloff_angle
                    lobe.SpotFallOffType = spot.get('falloff_type', 0)
                    lobe.SpotBlur = spot.blur

                    mxm_emitter.Temperature = emitter.temperature
                    mxm_emitter.MXI = textures.as_value_attribute(emitter.hdri_intensity, emitter.hdri_map)

                    mxm_emitter.ActivePair = (
                        # colorType: 0 = EMISSION_RGB, 2 = EMISSION_COLOR_TEMPERATURE
                        2 if emitter.use_temperature else 0,  # Luminance Units
                        emitter.get('luminance', 0)
                    )
                    luminance = emitter.luminance
                    if luminance == 'POWER':
                        pair = {
                            'watts': emitter.power,
                            'efficacy': emitter.efficacy
                        }
                    else:
                        output = emitter.output
                        pair = {
                            'luminous': output,  # only this used
                            'illuminance': output,
                            'intensity': output,
                            'luminance': output
                        }
                    pair['rgb'] = emitter.color
                    pair['temperature'] = emitter.color_temp
                    mxm_emitter.Pair = pair
                ##############################
                # BSDFs
                for bsdf in layer.bsdfs:
                    mxm_bsdf = mxm_layer.AddBSDF()
                    mxm_bsdf.Name = bsdf.name
                    mxm_bsdf.Enabled = bsdf.enabled
                    mxm_bsdf.Weight = textures.as_value_attribute(
                        bsdf.weight, bsdf.weight_map, bsdf.weight_map_enabled
                    )

                    refl = mxm_bsdf.Reflectance
                    attrs = refl.Attributes
                    ##############################
                    # BSDF Properties
                    refl.ComplexIor = bpy_abspath(bsdf.ior_file)
                    refl.ActiveIorMode = bsdf.get('ior_type', 0)
                    attrs['color'] = textures.as_color_attribute(
                        bsdf.color, bsdf.color_map, bsdf.color_map_enabled
                    )
                    attrs['color.tangential'] = textures.as_color_attribute(
                        bsdf.tangential, bsdf.tangential_map, bsdf.tangential_map_enabled
                    )
                    attrs['transmittance.color'] = textures.as_color_attribute(
                        bsdf.transmittance, bsdf.transmittance_map, bsdf.transmittance_map_enabled
                    )
                    refl.AbsorptionDistance = (bsdf.get('attenuation_units', 0), bsdf.attenuation)
                    refl.IOR = (bsdf.nd, bsdf.abbe)
                    refl.Conductor = bsdf.k
                    refl.ForceFresnel = bsdf.force_fresnel
                    refl.FresnelCustom = (
                        bsdf.fresnel_custom_angle,
                        bsdf.fresnel_custom_roughness,
                        bsdf.fresnel_custom_enabled
                    )
                    ##############################
                    # Surface Properties
                    mxm_bsdf.Roughness = textures.as_value_attribute(
                        bsdf.roughness, bsdf.roughness_map, bsdf.roughness_map_enabled
                    )
                    mxm_bsdf.Anisotropy = textures.as_value_attribute(
                        bsdf.anisotropy, bsdf.anisotropy_map, bsdf.anisotropy_map_enabled
                    )
                    mxm_bsdf.Angle = textures.as_value_attribute(
                        bsdf.angle, bsdf.angle_map, bsdf.angle_map_enabled
                    )
                    mxm_bsdf.Bump = textures.as_value_attribute(
                        bsdf.bump, bsdf.bump_map, bsdf.bump_map_enabled
                    )
                    mxm_bsdf.NormalMapState = bsdf.bump_normal
                    ##############################
                    # Subsurface Properties
                    attrs['scattering'] = textures.as_color_attribute(
                        bsdf.scattering, bsdf.scattering_map, bsdf.scattering_map_enabled
                    )
                    refl.ScatteringParameters = (
                        bsdf.scattering_coefficient,
                        bsdf.scattering_asymmetry,
                        bsdf.use_thickness
                    )
                    refl.ScatteringThickness = textures.as_value_attribute(
                        bsdf.thickness / 1000.0, bsdf.thickness_map, bsdf.thickness_map_enabled
                    )
                    refl.ScatteringThicknessRange = (
                        bsdf.thickness_min / 1000.0,
                        bsdf.thickness_max / 1000.0
                    )
                    ##############################
                    # Coating
                    coating = bsdf.coating
                    if coating.enabled:
                        mxm_coating = mxm_bsdf.AddCoating()
                        mxm_coating.Enabled = True
                        mxm_coating.Thickness = textures.as_value_attribute(
                            coating.thickness / 1000000000.0, coating.thickness_map, coating.thickness_map_enabled
                        )
                        mxm_coating.ThicknessRange = (
                            coating.thickness_min / 1000000000.0,
                            coating.thickness_max / 1000000000.0
                        )

                        refl = mxm_coating.Reflectance
                        refl.ComplexIor = bpy_abspath(coating.ior_file)
                        refl.ActiveIorMode = coating.get('ior_type', 0)
                        refl.IOR = (coating.nd, 0.0)
                        refl.Conductor = coating.k
                        refl.ForceFresnel = coating.force_fresnel
                        refl.FresnelCustom = (coating.fresnel_custom_angle, 0.0, coating.fresnel_custom_enabled)

                        attrs = refl.Attributes
                        attrs['color'] = textures.as_color_attribute(
                            coating.color, coating.color_map, coating.color_map_enabled
                        )
                        attrs['color.tangential'] = textures.as_color_attribute(
                            coating.tangential, coating.tangential_map, coating.tangential_map_enabled
                        )
        else:
            if mx_type == 'AGS':
                ags = mx_mat.ags
                params = {
                    'Color': ags.color,
                    'Reflection': ags.reflection,
                    'Type': ags.get('type', 0)
                }
                maps = {}
                name = 'AGS'
            elif mx_type == 'OPAQUE':
                opaque = mx_mat.opaque
                params = {
                    'Color': opaque.color,
                    'Color Type': opaque.color_map_enabled,
                    'Shininess': opaque.shininess,
                    'Shininess Type': opaque.shininess_map_enabled,
                    'Roughness': opaque.roughness,
                    'Roughness Type': opaque.roughness_map_enabled,
                    'Clearcoat': opaque.clearcoat
                }
                maps = {
                    'Color Map': (opaque.color_map, opaque.color_map_enabled),
                    'Shininess Map': (opaque.shininess_map, opaque.shininess_map_enabled),
                    'Roughness Map': (opaque.roughness_map, opaque.roughness_map_enabled)
                }
                name = 'Opaque'
            elif mx_type == 'TRANSPARENT':
                transparent = mx_mat.transparent
                params = {
                    'Color': transparent.color,
                    'Color Type': transparent.color_map_enabled,
                    'Ior': transparent.ior,
                    'Transparency': transparent.transparency,
                    'Roughness': transparent.roughness,
                    'Roughness Type': transparent.roughness_map_enabled,
                    'Specular Tint': transparent.specular_tint,
                    'Dispersion': transparent.dispersion,
                    'Clearcoat': transparent.clearcoat
                }
                maps = {
                    'Color Map': (transparent.color_map, transparent.color_map_enabled),
                    'Roughness Map': (transparent.roughness_map, transparent.roughness_map_enabled)
                }
                name = 'Transparent'
            elif mx_type == 'METAL':
                metal = mx_mat.metal
                params = {
                    'IOR': metal.get('ior', 0),
                    'Tint': metal.tint,
                    'Color': metal.color,
                    'Color Type': metal.color_map_enabled,
                    'Roughness': metal.roughness,
                    'Roughness Type': metal.roughness_map_enabled,
                    'Anisotropy': metal.anisotropy,
                    'Anisotropy Type': metal.anisotropy_map_enabled,
                    'Angle': metal.angle,
                    'Angle Type': metal.angle_map_enabled,
                    'Dust': metal.dust,
                    'Dust Type': metal.dust_map_enabled,
                    'Perforation Enabled': metal.perforation_map_enabled
                }
                maps = {
                    'Color Map': (metal.color_map, metal.color_map_enabled),
                    'Roughness Map': (metal.roughness_map, metal.roughness_map_enabled),
                    'Anisotropy Map': (metal.anisotropy_map, metal.anisotropy_map_enabled),
                    'Angle Map': (metal.angle_map, metal.angle_map_enabled),
                    'Dust Map': (metal.dust_map, metal.dust_map_enabled),
                    'Perforation Map': (metal.perforation_map, metal.perforation_map_enabled),
                }
                name = 'Metal'
            elif mx_type == 'TRANSLUCENT':
                translucent = mx_mat.translucent
                params = {
                    'Scale': translucent.scale,
                    'Ior': translucent.ior,
                    'Color': translucent.color,
                    'Color Type': translucent.color_map_enabled,
                    'Hue Shift': translucent.hue_shift,
                    'Invert Hue': translucent.invert_hue,
                    'Vibrance': translucent.vibrance,
                    'Density': translucent.density,
                    'Opacity': translucent.opacity,
                    'Roughness': translucent.roughness,
                    'Roughness Type': translucent.roughness_map_enabled,
                    'Specular Tint': translucent.specular_tint,
                    'Clearcoat': translucent.clearcoat,
                    'Clearcoat Ior': translucent.clearcoat_ior
                }
                maps = {
                    'Color Map': (translucent.color_map, translucent.color_map_enabled),
                    'Roughness Map': (translucent.roughness_map, translucent.roughness_map_enabled)
                }
                name = 'Translucent'
            elif mx_type == 'CARPAINT':
                carpaint = mx_mat.carpaint
                params = {
                    'Color': carpaint.color,
                    'Metallic': carpaint.metallic,
                    'Topcoat': carpaint.topcoat
                }
                maps = {}
                name = 'Car Paint'
            elif mx_type == 'HAIR':
                hair = mx_mat.hair
                params = {
                    'Color': hair.color,
                    'Color Type': hair.color_map_enabled,
                    'Root-Tip Weight': hair.root_tip_weight,
                    'Root-Tip Weight Type': hair.root_tip_weight_map_enabled,
                    'Primary Highlight Strength': hair.primary_strength,
                    'Primary Highlight Spread': hair.primary_spread,
                    'Primary Highlight Tint': hair.primary_tint,
                    'Secondary Highlight Strength': hair.secondary_strength,
                    'Secondary Highlight Spread': hair.secondary_spread,
                    'Secondary Highlight Tint': hair.secondary_tint
                }
                maps = {
                    'Color Map': (hair.color_map, hair.color_map_enabled),
                    'Root-Tip Map': (hair.root_tip_map, True),
                    'Root-Tip Weight Map': (hair.root_tip_weight_map, hair.root_tip_weight_map_enabled)
                }
                name = 'Hair'
            for param, (tex_name, tex_enabled) in maps.items():
                if tex_name and tex_enabled:
                    mxtex = textures.get_by_name(tex_name, True)
                    if mxtex:
                        params[param] = mxtex
            em = pymaxwell.ExtensionManager()
            ext = em.CreateMaterial(name, params)
            mxm.ApplyModifier(ext)

def _dupli_group_objects(group):
    for ob in group.objects:
        if ob.dupli_type == 'GROUP':
            yield from _dupli_group_objects(ob.dupli_group)
        else:
            yield ob

def _export_object_properties(mxob, mx):
    mxob.Opacity = mx.opacity / 100.0
    mxob.ColorID = mx.color_id
    mxob.HideToCamera = mx.hide_to_camera
    mxob.HideToReflRefr = mx.hide_to_refl_refr
    mxob.HideToGI = mx.hide_to_gi
    mxob.ExcludedOfCutPlanes = mx.ecp

    add = mxob.ExcludedLights.Add
    for e in mx.blocked_emitters:
        add(e.name)

def _export_particles(psys, params):
    pss = psys.settings
    particles = psys.particles

    nch = len(psys.child_particles)
    if pss.use_parent_particles or not nch:
        np = len(particles)
    else:
        np = 0

    n = 0
    ntot = np + nch
    locs = numpy.ndarray((ntot, 3), 'f')
    radii = numpy.ndarray(ntot, 'f')

    if np > 0:
        for p in particles:
            if p.alive_state == 'ALIVE':
                x, y, z = p.location
                locs[n] = x, z, -y
                radii[n] = p.size
                n += 1

    if nch > 0:
        flat = pss.child_roundness
        rad = pss.child_radius

        from_address = _ChildParticle.from_address
        for p in psys.child_particles:
            p = from_address(p.as_pointer())
            pp = particles[p.parent]
            if pp.alive_state == 'ALIVE':
                v = Vector(p.fuv[:3]) * rad
                v.x *= flat
                x, y, z = pp.rotation * v + pp.location
                locs[n] = x, z, -y
                radii[n] = pp.size
                n += 1

    if n > 0:
        locs.resize(n, 3, refcheck=False)
        radii.resize(n, refcheck=False)

        params['PARTICLE_POSITIONS'] = locs
        params['PARTICLE_RADII'] = radii
        params['PARTICLE_IDS'] = numpy.arange(1, n + 1, 1, 'i')

def object_uvsets(scene, ob):
    uvsets = []
    mx = ob.data.maxwell
    if mx.use_projections:
        for p in mx.projections:
            if p.type == 'LOCKED':
                uvsets.append((p, None))
                continue

            if p.object:
                o = scene.objects.get(p.object)
                if o:
                    base = ob.matrix_world.inverted() * o.matrix_world
                    base *= ROTATION_MATRIX
                else:
                    base = Matrix()
            else:
                x = p.scale[0]
                y = p.scale[1]
                z = p.scale[2]
                if p.type == 'PLANAR':
                    z = y
                    y = 0
                elif p.type == 'CUBIC':
                    if x:
                        x = 1.0 / (x * 2.0)
                    if y:
                        y = 1.0 / (y * 2.0)
                    if z:
                        z = 1.0 / (z * 2.0)
                base = Matrix([
                    [x, 0, 0],
                    [0, y, 0],
                    [0, 0, z]
                ])
                base.rotate(Euler(p.rotation))
                base = base.to_4x4()
                base.translation = p.position
            uvsets.append((p, base))
    return uvsets

def export_scene(data, scene, active_camera, xres, yres,
                 _log, is_animation=False, request_license=False):
    from . import bl_info
    _log("Begin export (B-Maxwell: v{0}.{1}.{2})".format(*bl_info["version"]))

    PC = PerfCounter()

    mx_scene = scene.maxwell
    mx_render = mx_scene.render

    mxs = pymaxwell.Scene()
    if mx_render.quality != 'RS0' and request_license:
        lic = BMaxwellPreferences.prefs().maxwell_license
        if not lic:
            lic = BMaxwellPreferences.prefs().mxpath("maxwell_license.lic")
            if not os.path.isfile(lic):
                # TODO: other places for the license file
                lic = None
        ret = mxs.InitLicensing(lic)
        _log("Initialize licensing (%d)" % ret)
        if ret:
            _log("Couldn't initialize license (%d)" % ret, {'WARNING'})
        ret = mxs.RequestLicense("maxwell_node")
        _log("Request license (%d)" % ret)
        if ret:
            _log("Failed to request Maxwell Render license (%d)" % ret, {'ERROR'})
            _log("Release license (%d)" % mxs.ReleaseLicense())
            return
        global _request_license
        _request_license = False

    mxs.AxisConversion = 'ZXY'
    # Blender uses floats for geometry
    mxs.SetSinglePrecisionOfGeometry()

    mx_channels = mx_render.channels
    custom_alphas = {}
    for a in mx_channels.custom_alphas:
        mxs.CreateCustomAlpha(a.name, a.opaque)
        custom_alphas[a.id] = a.name

    active_layers = [i for i, j in enumerate(scene.layers) if j]
    frame_current = scene.frame_current

    us = scene.unit_settings
    global_scale = us.scale_length if us.system != 'NONE' else 1.0

    render = scene.render
    aspect = render.pixel_aspect_x / render.pixel_aspect_y
    aspect_x = xres * render.pixel_aspect_x
    aspect_y = yres * render.pixel_aspect_y
    fps = render.fps

    if render.use_border:
        x_1 = xres - 1
        y_1 = yres - 1
        border = (
            int(x_1 * render.border_min_x), int(y_1 * (1.0 - render.border_max_y)),
            int(x_1 * render.border_max_x), int(y_1 * (1.0 - render.border_min_y))
        )
    else:
        border = None

    # TODO: different cameras have own shutter value
    if mx_render.motion_blur and active_camera.type == 'CAMERA':
        mx_camera = active_camera.data.maxwell
        if mx_camera.shutter_type == 'ANGLE':
            shutter = 360 * fps / mx_camera.angle
        elif mx_camera.shutter_type == 'SPEED':
            shutter = mx_camera.shutter
        motion_blur_frames = fps / shutter
        motion_blur_steps = mx_render.motion_blur_steps
    else:
        motion_blur_frames = 0
        motion_blur_steps = 0

    mxpath = MxPath(data)
    output_image = mxpath(mx_render.output_image)
    outputs_name, ext = os.path.splitext(output_image)
    if not (ext and mxs.IsDepthSupported(ext[1:], 8)):
        outputs_name = output_image
        output_image += ".png"
    output_mxi = mxpath(mx_render.output_mxi, ".mxi")

    frame_digits = max(6, len(str(scene.frame_end)))
    outputs_suffix = "_{0:0{1}}".format(frame_current, frame_digits) if is_animation else ""


    class _Materials:
        def __init__(self, textures):
            self.textures = textures
            self.materials = {}

        def get(self, mat: bpy.types.Material):
            mxm = None
            if mat:
                _log("           : [MATERIAL] %r" % mat.name)
                mxm = self.materials.get(mat, False)
                if mxm is False:
                    mxm = mxs.CreateMaterial(mat.name, True)
                    export_material(mxm, mat, self.textures)
                    for i in mat.maxwell.custom_alphas:
                        name = custom_alphas.get(i)
                        if name:
                            mxm.AddToCustomAlpha(name)
                    self.materials[mat] = mxm
            return mxm

        def get_by_name(self, name):
            if name:
                mat = data.materials.get(name)
                if mat:
                    return self.get(mat)
            return None

        def get_by_slot(self, slots, slot):
            if slot or slot == 0:
                try:
                    return self.get(slots[slot].material)
                except (KeyError, IndexError):
                    pass
            return None

    textures = Textures(data.textures)
    materials = _Materials(textures)


    class _Object:
        slots = (
            'type',         # maxwell type
            'flags',        # {'HIDE', 'EMPTY', 'INSTANCE', 'DUPLICATOR', 'DUPLI'}
            'object',       # blender object
            'mxobject',     # maxwell object
            'hobject',      # maxwell hierarchy object
            'base',
            'pivot',
            'instances',    # number of instances
            'dupli_list',   # if object is duplicator cache instanced objects for motion blur
            'smoke_modifier',
            'scatter_modifiers'
        )

        def __init__(self, ob, flags):
            self.object = ob
            self.flags = flags

            self.base = ob.matrix_world.copy()
            self.pivot = Matrix()

            _type = ob.type
            if _type == 'EMPTY':
                _type = ob.maxwell.type
            elif _type == 'MESH':
                if ob.data.maxwell.sea.enabled:
                    _type = 'SEA'
            elif _type in {'CURVE', 'SURFACE', 'META', 'FONT'}:
                _type = 'MESH'
            self.type = _type

            self.hobject = None
            self.mxobject = None
            self.instances = 0
            self.dupli_list = {}
            self.smoke_modifier = None
            self.scatter_modifiers = []

        def export(self, name):
            mx_type = self.type
            ob = self.object

            _log("%11s: %r" % (mx_type, ob.name))

            if mx_type == 'NONE':
                self.flags.add('EMPTY')
                return None

            obdata = ob.data
            shared = (
                obdata and
                obdata.users > 1 and
                not ob.is_modified(scene, 'RENDER') and
                # object data can be shared but have different materials
                not any(s.link == 'OBJECT' for s in ob.material_slots)
            )
            if shared:
                mxob = shared_objects.get(obdata, False)
                if mxob:
                    mxob = mxs.CreateInstance(name, mxob)
                    self.mxobject = mxob
                    self.flags.add('INSTANCE')
                    return mxob

                if mxob is None:
                    self.flags.add('EMPTY')
                    return None

            mxob = None
            if mx_type == 'MESH':
                mesh = ob.to_mesh(scene, True, 'RENDER', False)
                if mesh:
                    try:
                        mesh.calc_normals_split()
                        mesh.calc_tessface()
                        args = {
                            'name': name,
                            'mesh': mesh.as_pointer(),
                            'mats': [materials.get(m) for m in mesh.materials]
                        }
                        uvsets = object_uvsets(scene, ob)
                        if uvsets:
                            args['uvs'] = uvsets
                        # can be None if mesh doesn't have triangles
                        mxob = mxs.ImportMesh(**args)
                        if mxob:
                            # TODO: crashes without this, inspect
                            #if not mxob.NumChannelsUVW:
                            #    i = mxob.AddChannelUVW()
                            #    mxob.GenerateCubicUVW(i, Matrix())
                            #    _log("           : Default UV created", {'DEBUG'})
                            mxm = materials.get_by_slot(
                                ob.material_slots, ob.maxwell.backface_material
                            )
                            if mxm:
                                mxob.BackfaceMaterial = mxm
                    finally:
                        data.meshes.remove(mesh)
            elif mx_type == 'REFERENCE':
                reference = ob.maxwell.reference
                path = os.path.abspath(bpy_abspath(reference.path))
                _log("           : %s" % path)
                mxob = mxs.CreateReferencedObject(name, path)
                mxob.ReferencedFlags = reference.get('flags', 0)
                mxm = materials.get_by_name(reference.material)
                if mxm is not None:
                    mxob.Material = mxm
            elif mx_type == 'ASSET':
                reference = ob.maxwell.reference
                path = os.path.abspath(bpy_abspath(reference.path))
                _log("           : %s" % path)
                params = {
                    'FileName': path,
                    'Axis': reference.get('axis', 2)
                }
                em = pymaxwell.ExtensionManager()
                ext = em.CreateGeometryLoader('AssetReference', params)
                mxob = mxs.CreateGeometryLoader(name, ext)
                mxm = materials.get_by_name(reference.material)
                if mxm is not None:
                    mxob.Material = mxm
            elif mx_type == 'SEA':
                sea = ob.data.maxwell.sea
                params = {
                    'Resolution': sea.get('quality', 6),
                    'Reference Time': sea.time,
                    'Vertical Scale': sea.vertical_scale,
                    'Ocean Dim': sea.dimension,
                    'Ocean Depth': sea.depth,
                    'Ocean Seed': sea.seed,
                    'Enable Choppyness': sea.choppyness,
                    'Choppy factor': sea.choppy_factor,
                    'Ocean Wind Mod.': sea.wind_speed,
                    'Ocean Wind Dir.': sea.wind_direction,
                    'Damp Factor Against Wind': sea.weight_against_wind,
                    'Ocean Wind Alignment': sea.wind_alignment,
                    'Ocean Min. Wave Length': sea.min_wave_length,
                    'Repeat U': sea.repeat_u,
                    'Repeat V': sea.repeat_v
                }
                em = pymaxwell.ExtensionManager()
                ext = em.CreateGeometryLoader('MaxwellSea', params)
                mxob = mxs.CreateGeometryLoader(name, ext)
                mxm = materials.get_by_slot(ob.material_slots, sea.material)
                if mxm:
                    mxob.Material = mxm
            elif mx_type == 'VOLUMETRIC':
                volumetric = ob.maxwell.volumetric
                if volumetric.field_type == 'CONSTANT':
                    custom_uvsets = []
                    params = {
                        'Create Constant Density': 1,  # Constant
                        'ConstantDensity': volumetric.field_density
                    }
                elif volumetric.field_type == 'NOISE':
                    custom_uvsets = []
                    params = {
                        'Create Constant Density': 2,  # Noise 3D
                        'ConstantDensity': volumetric.field_density,
                        'Low value': volumetric.low_value,
                        'High value': volumetric.high_value,
                        'Seed': volumetric.seed,
                        'Octaves': volumetric.octaves,
                        'Persistance': volumetric.persistence,
                        'Detail': volumetric.detail,
                    }
                elif volumetric.field_type == 'OPENVDB':
                    custom_uvsets, params = volumetric.vdb_grid.to_maxwell()
                    params['FileName'] = bpy_abspath(volumetric.vdb_file)
                    params['VDBAxis'] = volumetric.get('vdb_axis', 2)
                em = pymaxwell.ExtensionManager()
                ext = em.CreateGeometryProcedural('MaxwellVolumetric', params)
                mxob = mxs.CreateGeometryProcedural(name, ext)
                for uv_type in custom_uvsets:
                    i = mxob.AddChannelUVW()
                    mxob.GenerateCustomUVW(i, uv_type)
                mxm = materials.get_by_name(volumetric.material)
                if mxm is not None:
                    mxob.Material = mxm
            elif mx_type == 'LAMP':
                # TODO: export as simple emitter
                pass

            if mxob:
                self.mxobject = mxob
            else:
                self.flags.add('EMPTY')

            if shared:
                shared_objects[obdata] = mxob

            return mxob

        def bnp(self, mxob):
            self.hobject = mxob

            parent = self.object.parent
            if parent is not None:
                _obp = objects.get(parent)
                if _obp is not None:
                    mxp = _obp.hobject
                    if mxp is None:
                        mxp = mxs.CreateNullObject(parent.name)
                        _obp.bnp(mxp)
                    mxob.BaseAndPivot = {
                        'base': _obp.base.inverted() * self.base,
                        'pivot': _obp.pivot
                    }
                    mxob.Parent = mxp
                    return

            mxob.BaseAndPivot = {
                'base': self.base * global_scale,
                'pivot': self.pivot
            }


    class _Camera:
        __slots__ = (
            'add_step',
            'export',
        )

        def __init__(self, ob):
            camera = ob.data
            mx = camera.maxwell
            steps = []

            def _dof(matrix_world):
                _ob = camera.dof_object
                if _ob:
                    dof = geometry.distance_point_to_plane(
                        matrix_world.translation,
                        _ob.matrix_world.translation,
                        matrix_world.col[2][:3]
                    )
                elif camera.dof_distance:
                    dof = camera.dof_distance
                else:
                    dof = 1.0
                return dof

            def add_step(time):
                mw = ob.matrix_world.copy()
                step = {
                    'matrix': mw,
                    'fstop': mx.fstop,
                }
                if camera.type == 'ORTHO':
                    step['dof'] = camera.ortho_scale
                    step['lens'] = 32.0
                else:
                    step['dof'] = _dof(mw)
                    step['lens'] = camera.lens
                steps.append((time, step))

            def export():
                _log("     CAMERA: %r" % ob.name)

                sensor_fit = camera.sensor_fit
                if sensor_fit == 'VERTICAL':
                    asp = aspect_x / aspect_y
                    sensor_width = camera.sensor_height * asp
                    sensor_height = camera.sensor_height
                    shift_x = camera.shift_x / asp
                    shift_y = camera.shift_y
                elif sensor_fit == 'HORIZONTAL' or aspect_x >= aspect_y:
                    asp = aspect_y / aspect_x
                    sensor_width = camera.sensor_width
                    sensor_height = camera.sensor_width * asp
                    shift_x = camera.shift_x
                    shift_y = camera.shift_y / asp
                else:
                    asp = aspect_x / aspect_y
                    sensor_width = camera.sensor_width * asp
                    sensor_height = camera.sensor_width
                    shift_x = camera.shift_x / asp
                    shift_y = camera.shift_y

                if mx.shutter_type == 'ANGLE':
                    shutter = 360 * fps / mx.rotary
                elif mx.shutter_type == 'SPEED':
                    shutter = mx.shutter

                from .pymaxwell import Camera

                if camera.type == 'PERSP':
                    if mx.persp_lens == 'THIN':
                        lens_type = Camera.TYPE_THIN_LENS
                    elif mx.persp_lens == 'PIN_HOLE':
                        lens_type = Camera.TYPE_PINHOLE_LENS
                elif camera.type == 'ORTHO':
                    lens_type = Camera.TYPE_ORTHO_LENS
                elif camera.type == 'PANO':
                    if mx.pano_lens == 'FISH_EYE':
                        lens_type = Camera.TYPE_FISHEYE_LENS
                    elif mx.pano_lens == 'SPHERICAL':
                        lens_type = Camera.TYPE_SPHERICAL_LENS
                    elif mx.pano_lens == 'CYLINDRICAL':
                        lens_type = Camera.TYPE_CYLINDRICAL_LENS
                    elif mx.pano_lens in {'LATLONG_STEREO', 'FISH_STEREO'}:
                        lens_type = Camera.TYPE_EXTENSION_LENS

                if len(steps) > 1:
                    # motion blur enabled, clean unchanged steps
                    _steps = []
                    it = iter(steps)
                    s1 = next(it)
                    s2 = next(it)
                    eq = (s1[1] == s2[1])
                    _steps.append(s1)
                    for s1 in it:
                        if s2[1] != s1[1]:
                            eq = False
                            _steps.append(s2)
                        elif not eq:
                            eq = True
                            _steps.append(s2)
                        s2 = s1
                    if not eq or len(_steps) > 1:
                        _steps.append(s2)
                else:
                    _steps = steps

                mxcam = mxs.AddCamera(
                    name=ob.name,
                    xres=xres,
                    yres=yres,
                    film_width=sensor_width / 1000.0,
                    film_height=sensor_height / 1000.0,
                    aspect=aspect,
                    iso=mx.iso,
                    shutter=1 / shutter,
                    diaphragm=mx.diaphragm,
                    blades=mx.blades,
                    angle=mx.angle,
                    steps=len(_steps),
                    fps=fps,
                    lens_type=lens_type
                )
                mxcam.ShiftLens = (
                    shift_x * 100, shift_y * -100
                )
                mxcam.CutPlanes = (
                    camera.clip_start * global_scale,
                    camera.clip_end * global_scale,
                    True
                )
                mxcam.ExposurePreset = mx.exposure
                mxcam.ResponsePreset = mx.response
                mxcam.CustomBokeh = (mx.custom_bokeh, mx.bokeh_ratio, mx.bokeh_angle)

                if camera.type == 'PANO':
                    if mx.pano_lens == 'FISH_EYE':
                        mxcam.FishLens = mx.aperture
                    elif mx.pano_lens == 'SPHERICAL':
                        mxcam.SphericalLens = mx.aperture
                    elif mx.pano_lens == 'CYLINDRICAL':
                        mxcam.CylindricalLens = mx.aperture
                    elif mx.pano_lens == 'LATLONG_STEREO':
                        p = mx.latlong_stereo
                        params = {
                            'EXTENSION_NAME': "Lat-Long Stereo",
                            'Type': p.get('type', 0),
                            'FOV Vertical': p.fov_vertical,
                            'FOV Horizontal': p.fov_horizontal,
                            'Flip Ray X': p.flip_ray_x,
                            'Flip Ray Y': p.flip_ray_y,
                            'Parallax Distance': p.parallax,
                            'Zenith Mode': p.zenith,
                            'Separation': p.separation,
                        }
                        if p.separation_map:
                            tex = textures.get_by_name(p.separation_map, True)
                            if tex:
                                params['Separation Map'] = tex
                        mxcam.LensExtension = params
                    elif mx.pano_lens == 'FISH_STEREO':
                        p = mx.fish_stereo
                        params = {
                            'EXTENSION_NAME': "Fish Stereo",
                            'Type': p.get('type', 0),
                            'FOV': p.fov,
                            'Separation': p.separation,
                            'Dome Tilt Compensation': p.dome_tilt_compensation,
                            'Dome Tilt': p.dome_tilt,
                            'Vertical Mode': p.vertical,
                            'Dome Radius': p.dom_radius,
                        }
                        for p, m in (('Separation Map', p.separation_map),
                                     ('Turn Map', p.turn_map),
                                     ('Tilt Map', p.tilt_map)):
                            if m:
                                tex = textures.get_by_name(m, True)
                                if tex:
                                    params[p] = tex
                        mxcam.LensExtension = params

                if border:
                    mxcam.ScreenRegion = ('REGION', border)

                for i, (t, step) in enumerate(_steps):
                    matrix = step['matrix'] * global_scale
                    mxcam.SetStep(
                        step=i,
                        origin=matrix.to_translation(),
                        focal_point=matrix * Vector([0, 0, -step['dof']]),
                        up=matrix.col[1][:3],
                        focal_length=step['lens'] / 1000,
                        f_stop=step['fstop'],
                        step_time=t
                    )

                if ob == active_camera:
                    mxcam.SetActive()

            self.add_step = add_step
            self.export = export

            add_step(0.0)

    ### Objects #######################################
    objects = {}
    direct_objects = []
    extension_objects = []

    shared_objects = {}

    duplicator_parent = False
    dupli_objects = set()
    dupli_groups = set()
    duplicators = []

    cameras = []

    for ob in scene.objects:
        flags = set()
        _ob = _Object(ob, flags)
        objects[ob] = _ob

        if ob.hide_render or not any(ob.layers[i] for i in active_layers):
            flags.add('HIDE')
            continue

        if ob.type == 'CAMERA':
            cameras.append(_Camera(ob))
            continue

        if duplicator_parent is not False:
            parent = ob.parent
            if parent is None or parent == duplicator_parent:
                duplicator_parent = False
            else:
                flags.add('HIDE')
                continue

        hidden = True if ob.particle_systems else None

        for modifier in ob.modifiers:
            show_render = modifier.show_render
            modifier_type = modifier.type
            if modifier_type == 'SMOKE':
                if show_render and modifier.smoke_type == 'DOMAIN':
                    ds = modifier.domain_settings
                    if ds.cache_file_format == 'OPENVDB':
                        extension_objects.append(('VOLUMETRIC', _ob, None))
                        _ob.smoke_modifier = modifier
                        if hidden is None:
                            hidden = True
            elif modifier_type == 'PARTICLE_SYSTEM':
                ps = modifier.particle_system
                pss = ps.settings
                if pss.use_render_emitter:
                    hidden = False
                if show_render:
                    if pss.render_type == 'OBJECT':
                        if pss.dupli_object:
                            mx_pss = pss.maxwell
                            if pss.type == 'HAIR' and mx_pss.scatter.enabled:
                                extension_objects.append(('SCATTER', _ob, ps))
                                _ob.scatter_modifiers.append(modifier)
                                hidden = False
                            else:
                                dupli_objects.add(pss.dupli_object)
                    elif pss.render_type == 'GROUP':
                        if pss.dupli_group:
                            dupli_groups.add(pss.dupli_group)
                    else:
                        if pss.type == 'HAIR':
                            if pss.render_type == 'PATH':
                                extension_objects.append((pss.maxwell.h_type, _ob, ps))
                        else:
                            extension_objects.append((pss.maxwell.p_type, _ob, ps))

        if hidden and ob.dupli_type == 'FRAMES':
            flags.add('HIDE')
            continue

        if ob.is_duplicator:
            if ob.dupli_type in {'VERTS', 'FACES'}:
                duplicator_parent = ob.parent
                if hidden is None:
                    hidden = True
                order = 2
            elif ob.dupli_type == 'GROUP' and ob.dupli_group:
                dupli_groups.add(ob.dupli_group)
                if hidden is None:
                    hidden = True
                    order = 0  # prefered parent is the current object (duplicator)
                else:
                    order = 2
            else:
                order = 1

            if order == 0:
                duplicators.insert(0, _ob)
            else:
                duplicators.append(_ob)
            flags.add('DUPLICATOR')

        if hidden is True:
            flags.add('HIDE')
        else:
            direct_objects.append(_ob)

    for ob in dupli_objects:
        _ob = objects.get(ob)
        if _ob is None:
            # object is not belonging to the current scene
            objects[ob] = _Object(ob, {'HIDE'})
        else:
            try:
                direct_objects.remove(_ob)
            except ValueError:
                pass
            _ob.flags.add('HIDE')

    for group in dupli_groups:
        for ob in _dupli_group_objects(group):
            if ob not in objects:
                objects[ob] = _Object(ob, {'HIDE'})

    # create maxwell objects
    for _ob in direct_objects:
        ob = _ob.object
        mxob = _ob.export(ob.name)
        if mxob is not None:
            _ob.bnp(mxob)
            mx = ob.maxwell
            for i in mx.custom_alphas:
                name = custom_alphas.get(i)
                if name:
                    mxob.AddToCustomAlpha(name)
            _export_object_properties(mxob, mx)

    if duplicators:
        prefs = BMaxwellPreferences.prefs()
        fmt = prefs.instances_name_format
        if not fmt:
            fmt = prefs.rna_type.properties['instances_name_format'].default
        format_name = fmt.format

        for _obd in duplicators:
            duplicator = _obd.object
            _log(" DUPLICATOR: %r" % duplicator.name)

            if motion_blur_steps:
                dupli_list = _obd.dupli_list

            # temporary disable scatter particle systems before creating dupli list
            for m in _obd.scatter_modifiers:
                m.show_render = False

            dmx = duplicator.maxwell

            alphas = []
            for i in dmx.custom_alphas:
                name = custom_alphas.get(i)
                if name:
                    alphas.append(name)

            duplicator.dupli_list_create(scene, 'RENDER')
            try:
                cur = None
                mxp = None
                skip = False

                for dupli in duplicator.dupli_list:
                    ob = dupli.object
                    if ob.dupli_type in {'VERTS', 'FACES', 'GROUP'}:
                        continue

                    if cur != ob:
                        cur = ob
                        _ob = objects[ob]
                        skip = 'EMPTY' in _ob.flags
                        if skip:
                            continue

                        mxob = _ob.mxobject
                        if 'INSTANCE' in flags:
                            mxob = mxob.Instanced
                        name = ob.name
                    elif skip:
                        continue

                    if mxob is None:
                        mxob = _ob.export(format_name(name, 0))
                        if mxob is None:
                            skip = True
                            continue

                        if 'INSTANCE' in _ob.flags:
                            mxob = mxob.Instanced
                        _ob.flags.add('DUPLI')
                        mxinst = mxob
                    else:
                        _ob.instances += 1
                        mxinst = mxs.CreateInstance(format_name(name, _ob.instances), mxob)

                    if mxp is None:
                        if dupli.type == 'FRAMES':
                            parent = duplicator.parent
                            _obp = objects[parent]
                        else:
                            parent = duplicator
                            _obp = _obd

                        mxp = _obp.hobject
                        if mxp is None:
                            mxp = mxs.CreateNullObject(parent.name)
                            _obp.bnp(mxp)

                    mxinst.BaseAndPivot = {'base': _obp.base.inverted() * dupli.matrix}
                    mxinst.Parent = mxp

                    for name in alphas:
                        mxinst.AddToCustomAlpha(name)
                    _export_object_properties(mxinst, dmx)

                    if motion_blur_steps:
                        dupli_list[dupli.persistent_id[:]] = mxinst
            finally:
                duplicator.dupli_list_clear()
                for m in _obd.scatter_modifiers:
                    m.show_render = True

    ###################################
    #region Extensions (Smoke or Particle Systems)
    if extension_objects:
        bin_files = {}

        if data.filepath:
            bin_outputs_name = os.path.splitext(data.filepath)[0]
        else:
            bin_outputs_name = os.path.join(temporary_directory(), "unknown")

        def bin_file(ob, ps, overwrite=True):
            path = bin_files.get(ps, False)
            if path is False:
                binfile = bpy_abspath(ps.settings.maxwell.binfile)
                directory, file = os.path.split(binfile)
                if file:
                    _file, ext = os.path.splitext(file)
                    fn = "{0}_{1:0{2}}.bin".format(
                        _file if ext.lower() == ".bin" else file,
                        frame_current,
                        frame_digits
                    )
                else:
                    fn = "{0}-{1}-{2}_{3:0{4}}.bin".format(
                        bin_outputs_name, ob.name, ps.name, frame_current, frame_digits
                    )
                path = os.path.join(directory, fn)
                if overwrite or not os.path.exists(path):
                    ret = mxs.CreateParticlesFile(
                        psys=ps,
                        file=path,
                        scene_scale=global_scale,
                        frame=frame_current,
                        fps=fps,
                        radius=ps.settings.particle_size,
                        #emitter_position=ob.matrix_world.translation,
                        #emitter_scale=(global_scale, ) * 3,
                    )
                    if not ret:
                        path = None
                bin_files[ps] = path
            _log("           : %r" % path)
            return path

        em = pymaxwell.ExtensionManager()
        for et, _ob, ps in extension_objects:
            ob = _ob.object

            if ps is None:
                grids = ob.maxwell.volumetric.vdb_grids
                if grids:
                    smoke_modifier = _ob.smoke_modifier
                    ds = smoke_modifier.domain_settings
                    d, f = os.path.split(data.filepath)
                    n = ds.point_cache.name
                    if not n:
                        n = "".join("%02X" % ord(c) for c in ob.name)
                    n += "_%06d_00.vdb" % frame_current
                    filename = os.path.join(d, "blendcache_" + os.path.splitext(f)[0], n)

                    uvsets = object_uvsets(scene, ob)

                    mxp = _ob.hobject
                    if mxp is None:
                        mxp = mxs.CreateNullObject(ob.name)
                        _ob.bnp(mxp)
                    bnp = {
                        'base': Matrix(),
                        'pivot': _ob.base.inverted() * ROTATION_MATRIX_INV
                    }

                    for grid in grids:
                        _log("  EXTENSION: [%s:VDB] %r.%r" % (et, ob.name, grid.name))

                        uvgen, params = grid.to_maxwell()
                        params['FileName'] = filename
                        mxe = mxs.CreateGeometryProcedural(
                            "[%s] %s" % (grid.name, ob.name),
                            em.CreateGeometryProcedural('MaxwellVolumetric', params)
                        )
                        # TODO: uvsets from object
                        for uvg in uvgen:
                            i = mxe.AddChannelUVW()
                            mxe.GenerateCustomUVW(i, uvg)
                        mxm = materials.get_by_slot(ob.material_slots, grid.material)
                        if mxm is not None:
                            mxe.Material = mxm
                        mxe.BaseAndPivot = bnp
                        mxe.Parent = mxp
                continue

            _log("  EXTENSION: [%s] %r.%r" % (et, ob.name, ps.name))

            pss = ps.settings
            mx_pss = pss.maxwell
            # TODO: can be instanced object?
            mxob = _ob.mxobject

            if et == 'HAIR':
                ps.set_resolution(scene, ob, 'RENDER')
                try:
                    mxext = mxs.ImportHair(
                        ps.as_pointer(), ob.as_pointer(), "[%s] %s" % (ob.name, ps.name)
                    )
                finally:
                    ps.set_resolution(scene, ob, 'PREVIEW')
            elif et == 'MESHER':
                mesher = mx_pss.mesher
                params = {
                    # --- Globals ---
                    'Mesher': mesher.get('mesher', 0),
                    'Reference Frame': frame_current,
                    'fps': fps,
                    # --- Sequence 0 ---
                    'Sequence 0 On': True,
                    'File 0': bin_file(ob, ps, mx_pss.overwrite_binfile),
                    'Radius 0': mesher.radius,
                    'Core 0': mesher.core,
                    'Splash 0': mesher.splash,
                    'maxVelocity 0': mesher.velocity,
                    # --- Mesh parameters ---
                    'PolygonSize': mesher.poly,
                    'WeightNormalization': mesher.wn,
                    'Smooth': mesher.smooth,
                    'IsoLevel': mesher.iso_level,
                    'FixBoundingBox': mesher.fix_bbox,
                    'FieldType': mesher.get('field_type', 1),
                    # --- Mesh filtering ---
                    'FilterMesh': mesher.filter,
                    'Relax': mesher.relax,
                    'Tension': mesher.tension,
                    'Thinning': mesher.thinning,
                    'Steps': mesher.steps,
                    'SplashThinning': mesher.splash_thinning,
                    'SplashThreshold': mesher.splash_threshold,
                    'ThinningSize': mesher.thinning_size,
                    'CoreSmoothing': mesher.core_smooth,
                    'CoreThreshold': mesher.core_threshold,
                    'SmoothingSteps': mesher.smooth_steps,
                    # --- Mesh optimization ---
                    'Optimize': mesher.get('optimize', 0),
                    'CameraDistance': mesher.distance,
                    # --- System parameters ---
                    'Threads': mesher.threads,
                    # --- Export and lazy compute ---
                    'Action': mesher.get('action', 0),
                    'MD File': mesher.md_file,
                    'MD Frame# Offset': mesher.md_offset,
                    'MD compression': mesher.md_compression,
                    'MD invertNormals': mesher.md_normals
                }
                ext = em.CreateGeometryLoader('MaxwellMesher', params)
                mxext = mxs.CreateGeometryLoader("[%s] %s" % (ob.name, ps.name), ext)
            elif et == 'PARTICLES':
                particles = mx_pss.particles
                params = {
                    'Frame#': frame_current,
                    'fps': fps,
                    'Radius Factor': particles.radius,
                    'MB Factor': particles.motion_blur,
                    'Shutter 1/': particles.shutter_speed,
                    'Create N particles per particle': particles.extra_particles,
                    'Extra particles dispersion': particles.extra_dispersion,
                    'Extra particles deformation': particles.extra_deformation
                }
                if mx_pss.use_binfile:
                    params['FileName'] = bin_file(ob, ps, mx_pss.overwrite_binfile)
                else:
                    _export_particles(ps, params)
                ext = em.CreateGeometryProcedural('MaxwellParticles', params)
                mxext = mxs.CreateGeometryProcedural("[%s] %s" % (ob.name, ps.name), ext)
            elif et == 'VOLUMETRIC':
                volumetric = mx_pss.volumetric
                params = {
                    'Create Constant Density': 0,
                    'Frame#': frame_current,
                    'fps': fps,
                    'Load particles %': volumetric.load_particles,
                    'Radius Factor': volumetric.radius_factor,
                    'densityScale': volumetric.density_scale,
                    'minFinalDensity': volumetric.min_density,
                    'maxFinalDensity': volumetric.max_density,
                    'cellSize': volumetric.cell_size,
                    'Create N particles per particle': volumetric.extra_particles,
                    'Extra particles dispersion': volumetric.extra_dispersion,
                    'Extra particles deformation': volumetric.extra_deformation,
                    'MB Factor': volumetric.motion_blur_factor,
                    'Shutter 1/': volumetric.shutter_speed
                }
                if mx_pss.use_binfile:
                    params['FileName'] = bin_file(ob, ps, mx_pss.overwrite_binfile)
                else:
                    _export_particles(ps, params)
                ext = em.CreateGeometryProcedural('MaxwellVolumetric', params)
                mxext = mxs.CreateGeometryProcedural("[%s] %s" % (ob.name, ps.name), ext)
            else:
                if mxob is not None: # TODO: create object, if None?
                    if et == 'GRASS':
                        grass = mx_pss.grass
                        params = {
                            # --- Primitive ---
                            'Primitive Type': grass.get('type', 0),
                            'Points per Blade': grass.blade_points,
                            # --- Grass Density ---
                            'Density': grass.density,
                            'Seed': grass.seed,
                            # --- Blade Length ---
                            'Length': grass.length,
                            'Length Variation': grass.length_var,
                            # --- Width ---
                            'Root Width': grass.root_width,
                            'Tip Width': grass.tip_width,
                            # --- Angle ---
                            'Direction Type': grass.get('direction', 0),
                            'Initial Angle': grass.angle,
                            'Initial Angle Variation': grass.angle_var,
                            # --- Bend ---
                            'Start Bend': grass.start_bend,
                            'Start Bend Variation': grass.start_bend_var,
                            'Bend Radius': grass.bend_radius,
                            'Bend Radius Variation': grass.bend_radius_var,
                            'Bend Angle': grass.bend_angle,
                            'Bend Angle Variation': grass.bend_angle_var,
                            # --- Cut off ---
                            'Cut Off': grass.cut_off,
                            'Cut Off Variation': grass.cut_off_var,
                            # --- Level of Detail ---
                            'Enable LOD': grass.lod_enabled,
                            'LOD Min Distance': grass.lod_min,
                            'LOD Max Distance': grass.lod_max,
                            'LOD Max Distance Density': grass.lod_max_density,
                            # --- Display ---
                            'Display Percent': grass.display_percent,
                            'Display Max. Blades': grass.display_blades,
                        }
                        mxm = materials.get_by_slot(ob.material_slots, pss.material - 1)
                        if mxm:
                            params['Material'] = mxm.Name
                        mxm = materials.get_by_slot(ob.material_slots, grass.backface)
                        if mxm:
                            params['Double Sided Material'] = mxm.Name
                        for param, map_name in [('Density Map', grass.density_map),
                                                ('Length Map', grass.length_map),
                                                ('Initial Angle Map', grass.angle_map),
                                                ('Start Bend Map', grass.start_bend_map),
                                                ('Bend Radius Map', grass.bend_radius_map),
                                                ('Bend Angle Map', grass.bend_angle_map),
                                                ('Cut Off Map', grass.cut_off_map)]:
                            if map_name:
                                tex = textures.get_by_name(map_name, True)
                                if tex:
                                    params[param] = tex
                        ext = em.CreateGeometryModifier('MaxwellGrass', params)
                        mxob.ApplyGeometryModifier(ext)
                    elif et == 'SCATTER':
                        # TODO: add to the mxob a uvmap if it not have
                        _ob = objects[pss.dupli_object]
                        flags = _ob.flags
                        mxdupli = None
                        if 'EMPTY' not in flags:
                            mxdupli = _ob.mxobject
                            if mxdupli is None:
                                mxdupli = _ob.export(pss.dupli_object.name)
                                if 'HIDE' in flags:
                                    mxdupli.Hide = True

                        scatter = mx_pss.scatter
                        params = {
                            'Object': mxdupli.Name if mxdupli else "",
                            'Inherit ObjectID': scatter.inherit_oid,
                            'Density': scatter.density,
                            'Remove Overlapped': scatter.remove_overlaps,
                            'Seed': scatter.seed,
                            'Scale X': scatter.scale[0],
                            'Scale Y': scatter.scale[1],
                            'Scale Z': scatter.scale[2],
                            'Uniform Scale': scatter.uniform_scale,
                            'Scale X Variation': scatter.scale_var[0],
                            'Scale Y Variation': scatter.scale_var[1],
                            'Scale Z Variation': scatter.scale_var[2],
                            'Rotation X': scatter.rotation[0],
                            'Rotation Y': scatter.rotation[1],
                            'Rotation Z': scatter.rotation[2],
                            'Rotation X Variation': scatter.rotation_var[0],
                            'Rotation Y Variation': scatter.rotation_var[1],
                            'Rotation Z Variation': scatter.rotation_var[2],
                            'Direction Type': scatter.direction,
                        }
                        for param, map_name in [('Density Map', scatter.density_map),
                                                ('Scale Map', scatter.scale_map),
                                                ('Rotation Map', scatter.rotation_map)]:
                            if map_name:
                                tex = textures.get_by_name(map_name, True)
                                if tex:
                                    params[param] = tex
                        ext = em.CreateGeometryModifier('MaxwellScatter', params)
                        mxob.ApplyGeometryModifier(ext)
                continue

            mxm = materials.get_by_slot(ob.material_slots, pss.material - 1)
            if mxm:
                mxext.Material = mxm

            if mxob is None:
                mxext.BaseAndPivot = {
                    'base': ob.matrix_world * global_scale,
                    'pivot': ob.matrix_world.inverted()
                }
            else:
                mxext.BaseAndPivot = {
                    'base': Matrix(),
                    'pivot': ob.matrix_world.inverted()
                }
                mxext.Parent = mxob
    #endregion

    ###################################
    #region Motion Blur
    if motion_blur_steps:
        try:
            for step in range(1, motion_blur_steps + 1):
                step_time = step / motion_blur_steps
                subframe, frame = modf(frame_current + motion_blur_frames * step_time)
                scene.frame_set(frame, subframe)
                # objects motion blur
                for _ob in objects.values():
                    ob = _ob.object
                    mxob = _ob.hobject
                    if mxob:
                        mw = ob.matrix_world.copy()
                        isNull = mxob.Parent.isNull
                        if isNull:
                            mw *= global_scale
                        if mxob.TransformSubstepsCount:
                            mxob.BaseAndPivot = {'base': mw, 'time': step_time}
                        else:
                            _mw = _ob.base
                            if _mw != mw:
                                if step > 1:
                                    mxob.BaseAndPivot = {
                                        'base': _mw * global_scale if isNull else _mw,
                                        'time': (step - 1) / motion_blur_steps
                                    }
                                mxob.BaseAndPivot = {'base': mw, 'time': step_time}
                    # duplicators
                    dupli_list = _ob.dupli_list
                    if dupli_list:
                        mwi = None
                        ob.dupli_list_create(scene, 'RENDER')
                        try:
                            for dupli in ob.dupli_list:
                                mxob = dupli_list.get(dupli.persistent_id[:])
                                if mxob:
                                    if mwi is None:
                                        if dupli.type == 'FRAMES':
                                            ob = objects[ob.parent].object
                                        mwi = ob.matrix_world.inverted()
                                    mxob.BaseAndPivot = {
                                        'base': mwi * dupli.matrix,
                                        'time': step_time
                                    }
                        finally:
                            ob.dupli_list_clear()
                # calculate cameras motion blur
                for c in cameras:
                    c.add_step(step_time)
        finally:
            scene.frame_set(frame_current)
    #endregion

    ###################################
    #region Cameras
    _ob = objects.get(active_camera)
    if _ob is None or 'HIDE' in _ob.flags:
        cameras.append(_Camera(active_camera))
    for c in cameras:
        c.export()
    #endregion

    ###################################
    #region Environment
    world = scene.world
    mxs_environ = mxs.Environment
    if world is None:
        mxs_environ.ActiveSky = None
        mxs_environ.EnvironmentEnabled = False
    else:
        mx_world = world.maxwell
        # Sky
        sky = mx_world.physical
        mxs_environ.PhysicalSkyAtmosphere = {
            'intensity': sky.intensity,
            'ozone': sky.ozone,
            'water': sky.water,
            'angstrom': sky.angstrom,
            'wavelength': sky.wavelength,
            'albedo': sky.albedo / 100,
            'asymmetry': sky.asymmetry,
            'reflectance': sky.planet_reflectance / 100
        }
        sky = mx_world.constant
        mxs_environ.SkyConstant = {
            'luminance': sky.luminance,
            'zenith': sky.zenith,
            'horizon': sky.horizon,
            'controlPoint': sky.control_point
        }
        mxs_environ.ActiveSky = mx_world.sky_type
        # Sun
        sun = mx_world.sun
        mxs_environ.SunProperties = {
            'type': sun.get('type', 1),
            'power': sun.power,
            'radius': sun.radius,
            'temperature': sun.temperature,
            'color': sun.color
        }
        mxs_environ.SunLongitudeAndLatitude = {
            'latitude': sun.latitude,
            'longitude': sun.longitude,
            'gmt': sun.gmt,
            'dayOfYear': sun.day,
            'timeOfDay': sun.time
        }
        mxs_environ.SunAngles = {
            'zenith': sun.zenith,
            'azimuth': sun.azimuth
        }
        mxs_environ.SunRotation = sun.rotation
        direction = sun.direction
        if sun.direction_object:
            ob = scene.objects.get(sun.direction_object)
            if ob:
                direction = ob.matrix_world.col[2].xyz
        mxs_environ.SunDirection = direction
        mxs_environ.SunPositionType = sun.get('position', 0)
        # IBL
        ibl = mx_world.ibl
        mxs_environ.EnvironmentEnabled = (mx_world.type == 'IBL')
        mxs_environ.EnvironmentWeight = ibl.intensity
        # IBL Layers
        mxs_layers = mxs_environ.Layers
        interpolation = ibl.interpolation

        def ibl_layer_params(mx, state):
            return {
                'filename': bpy_abspath(mx.map) if mx.map else None,
                'intensity': mx.intensity,
                'interpolate': interpolation,
                'offset': mx.offset,
                'scale': mx.scale,
                'state': state,
            }

        def ibl_layer_params_set(layer, mx):
            state = mx.get('type', 3)
            if state == 3:
                params = {'state': 3}
            else:
                params = ibl_layer_params(mx, state)
            mxs_layers[layer] = params

        background = ibl_layer_params(ibl.background, ibl.background.get('type', 1))
        background['spherical'] = not ibl.screen_mapping
        mxs_layers[mxs_layers.BACKGROUND] = background
        ibl_layer_params_set(mxs_layers.REFLECTION, ibl.reflection)
        ibl_layer_params_set(mxs_layers.REFRACTION, ibl.refraction)
        ibl_layer_params_set(mxs_layers.ILLUMINATION, ibl.illumination)
    #endregion

    ###################################
    #region Render Params
    mxs_rp = mxs.RenderParams
    mxs_rp['ENGINE'] = mx_render.quality
    mxs_rp['NUM THREADS'] = mx_render.threads
    mxs_rp['STOP TIME'] = mx_render.time_limit * 60
    mxs_rp['SAMPLING LEVEL'] = mx_render.sampling_level
    # Multilight
    mxs_rp['USE MULTILIGHT'] = mx_render.get('multilight', 0)
    mxs_rp['SAVE LIGHTS IN SEPARATE FILES'] = mx_render.get('multilight_save_lights', 0)
    # Globals
    mxs_rp['DO MOTION BLUR'] = mx_render.motion_blur
    mxs_rp['DO DISPLACEMENT'] = mx_render.displacement
    mxs_rp['DO DISPERSION'] = mx_render.dispersion
    # Illumination & Caustics
    illumination = mx_render.get('illumination', 0b11)
    mxs_rp['DO DIRECT LAYER'] = bool(illumination & 0b01)
    mxs_rp['DO INDIRECT LAYER'] = bool(illumination & 0b10)
    reflection_caustics = mx_render.get('reflection_caustics', 0b11)
    mxs_rp['DO DIRECT REFLECTION CAUSTIC LAYER'] = bool(reflection_caustics & 0b01)
    mxs_rp['DO INDIRECT REFLECTION CAUSTIC LAYER'] = bool(reflection_caustics & 0b10)
    refraction_caustics = mx_render.get('refraction_caustics', 0b11)
    mxs_rp['DO DIRECT REFRACTION CAUSTIC LAYER'] = bool(refraction_caustics & 0b01)
    mxs_rp['DO INDIRECT REFRACTION CAUSTIC LAYER'] = bool(refraction_caustics & 0b10)
    # Materials
    if mx_render.override_material:
        mxs.OverrideMaterial = bpy_abspath(mx_render.override_material)
    mxs.EnableOverrideMaterial = mx_render.override_material_enabled
    if mx_render.default_material:
        mxs.DefaultMaterial = bpy_abspath(mx_render.default_material)
        mxs.EnableDefaultMaterial = True
    for p in mx_render.searching_paths:
        if p:
            mxs.AddSearchingPath(bpy_abspath(p.name))
    mxs.AddSearchingPath(os.path.join(MATERIALS_DATABASE, "textures"))
    mxs.AddSearchingPath(os.path.join(MATERIALS_DATABASE, "ior files"))
    # Tone Mapping
    mxs.ColorSpace = mx_render.get('colorspace', 0)
    mxs.ToneMapping = {
        'gamma': mx_render.gamma,
        'burn': mx_render.burn
    }
    mxs.WhitePoint = (mx_render.white_point, mx_render.tint)
    mxs_rp['DO SHARPNESS'] = mx_render.sharpness_enabled
    mxs_rp['SHARPNESS'] = mx_render.sharpness / 100
    # Simulens
    mxs.Diffraction = {
        'enabled': mx_render.diffraction_enabled,
        'intensity': mx_render.diffraction / 2500.0,
        'frequency': mx_render.frequency / 2500.0,
        'aperture': mx_render.aperture_map,
        'obstacle': mx_render.obstacle_map
    }
    mxs_rp['DO SCATTERING_LENS'] = mx_render.scattering_enabled
    mxs_rp['SCATTERING_LENS'] = mx_render.scattering / 2500.0
    mxs_rp['DO DEVIGNETTING'] = mx_render.devignetting_enabled
    mxs_rp['DEVIGNETTING'] = mx_render.devignetting / 100.0
    # Output
    mxs_paths = mxs.Paths
    mxs_rp['MXI FULLNAME'] = "{0[0]}{1}{0[1]}".format(
        os.path.splitext(output_mxi), outputs_suffix
    )
    mxs_rp['DO NOT SAVE MXI FILE'] = not mx_render.output_mxi_enabled
    mxs_paths['RENDER'] = {
        'path': "{0[0]}{1}{0[1]}".format(os.path.splitext(output_image), outputs_suffix),
        'depth': mx_render.get('output_depth', 8)
    }
    mxs_rp['DO NOT SAVE IMAGE FILE'] = not mx_render.output_image_enabled
    # Channels
    embed_channels = mx_channels.get('output_mode', 0)

    def channel_path(fmt, channel_name, is_alpha=False):
        ext, depth = fmt.split("_")
        if embed_channels and (ext == 'exr' or (is_alpha and ext in {'tga', 'png', 'tif'})):
            path = "%s%s.%s" % (outputs_name, outputs_suffix, ext)
        else:
            path = "%s_%s%s.%s" % (outputs_name, channel_name, outputs_suffix, ext)
        return {'path': path, 'depth': int(depth)}

    # Output paths of the channels:
    #  'RENDER', 'ALPHA', 'SHADOW', 'OBJECT', 'MATERIAL', 'MOTION', 'Z', 'ROUGHNESS',
    #  'FRESNEL', 'NORMALS', 'POSITION', 'DEEP', 'UV', 'ALPHA_CUSTOM', 'REFLECTANCE'.
    mxs_rp['EMBED CHANNELS'] = embed_channels
    mxs_rp['RENDER LAYERS'] = mx_channels.get('render_type', 0)
    mxs_rp['DO RENDER CHANNEL'] = mx_channels.render_enabled
    # Alpha
    mxs_paths['ALPHA'] = channel_path(mx_channels.alpha_format, "alpha", True)
    mxs_rp['DO ALPHA CHANNEL'] = mx_channels.alpha_enabled
    mxs_rp['OPAQUE ALPHA'] = mx_channels.alpha_opaque
    # Z-Buffer
    mxs_paths['Z'] = channel_path(mx_channels.z_buffer_format, "zbuffer")
    mxs_rp['DO ZBUFFER CHANNEL'] = mx_channels.z_buffer_enabled
    mxs_rp['ZBUFFER RANGE'] = mx_channels.z_buffer_range
    # Shadow
    mxs_paths['SHADOW'] = channel_path(mx_channels.shadow_format, "shadow")
    mxs_rp['DO SHADOW PASS CHANNEL'] = mx_channels.shadow_enabled
    # Material ID
    mxs_paths['MATERIAL'] = channel_path(mx_channels.material_id_format, "material")
    mxs_rp['DO IDMATERIAL CHANNEL'] = mx_channels.material_id_enabled
    # Object ID
    mxs_paths['OBJECT'] = channel_path(mx_channels.object_id_format, "object")
    mxs_rp['DO IDOBJECT CHANNEL'] = mx_channels.object_id_enabled
    # Motion Vector
    mxs_paths['MOTION'] = channel_path(mx_channels.motion_vector_format, "motion")
    mxs_rp['DO MOTION CHANNEL'] = mx_channels.motion_vector_enabled
    # Roughness
    mxs_paths['ROUGHNESS'] = channel_path(mx_channels.roughness_format, "roughness")
    mxs_rp['DO ROUGHNESS CHANNEL'] = mx_channels.roughness_enabled
    # Fresnel
    mxs_paths['FRESNEL'] = channel_path(mx_channels.fresnel_format, "fresnel")
    mxs_rp['DO FRESNEL CHANNEL'] = mx_channels.fresnel_enabled
    # Normals
    mxs_paths['NORMALS'] = channel_path(mx_channels.normals_format, "normals")
    mxs_rp['NORMALS CHANNEL SPACE'] = mx_channels.get('normals_space', 0)
    mxs_rp['DO NORMALS CHANNEL'] = mx_channels.normals_enabled
    # Position
    mxs_paths['POSITION'] = channel_path(mx_channels.position_format, "position")
    mxs_rp['POSITION CHANNEL SPACE'] = mx_channels.get('position_space', 0)
    mxs_rp['DO POSITION CHANNEL'] = mx_channels.position_enabled
    # Deep (always separate)
    mxs_paths['DEEP'] = {
        'path': "%s_deep%s.%s" % (outputs_name, outputs_suffix, mx_channels.deep_format.lower()),
        'depth': 32
    }
    mxs_rp['DO DEEP CHANNEL'] = mx_channels.deep_enabled
    mxs_rp['DEEP CHANNEL TYPE'] = mx_channels.get('deep_channels', 0)
    mxs_rp['DEEP MIN DISTANCE'] = mx_channels.deep_distance
    mxs_rp['DEEP MAX SAMPLES'] = mx_channels.deep_samples
    # UV
    mxs_paths['UV'] = channel_path(mx_channels.uv_format, "uv")
    mxs_rp['DO UV CHANNEL'] = mx_channels.uv_enabled
    # Custom Alpha
    mxs_paths['ALPHA_CUSTOM'] = channel_path(mx_channels.custom_alpha_format, "custom_alpha", True)
    mxs_rp['DO ALPHA CUSTOM CHANNEL'] = mx_channels.custom_alpha_enabled
    # Reflectance
    mxs_paths['REFLECTANCE'] = channel_path(mx_channels.reflectance_format, "reflectance")
    mxs_rp['DO REFLECTANCE CHANNEL'] = mx_channels.reflectance_enabled
    # Extra Sampling
    extra_sampling = mx_render.extra_sampling
    mxs_rp['DO EXTRA SAMPLING'] = extra_sampling.enabled
    mxs_rp['EXTRA SAMPLING SL'] = extra_sampling.sampling_level
    mxs_rp['EXTRA SAMPLING MASK'] = extra_sampling.get('mask', 0)
    mxs_rp['EXTRA SAMPLING CUSTOM ALPHA'] = custom_alphas.get(extra_sampling.channel_id)
    if extra_sampling.bitmap:
        mxs_rp['EXTRA SAMPLING USER BITMAP'] = bpy_abspath(extra_sampling.bitmap)
    mxs_rp['EXTRA SAMPLING INVERT'] = extra_sampling.invert_mask
    # Overlay Text
    overlay_text = mx_render.get('overlay_text')
    if overlay_text:
        mxs.OverlayText = overlay_text.to_dict()
    #endregion

    _log("End export (%fs)" % PC())
    return mxs

def _texture_preview_update(engine, tex):
    mxt = Textures(bpy.data.textures).create(tex, True)
    mxs = pymaxwell.Scene()
    image = tex.image

    def preview_callback(re):
        result = re.begin_result(0, 0, re.resolution_x, re.resolution_y)
        mxt.UpdatePreviewResult(result.as_pointer(), mxs, image)
        re.end_result(result)

    engine.session['preview_callback'] = preview_callback

def _material_preview_update(engine, scene):
    mat = scene.objects['preview'].active_material
    if mat is None:
        return

    mx = mat.maxwell
    if mx.type == 'FILE':
        mxm_path = bpy_abspath(mx.mxm)
        if mxm_path:
            mxp = pymaxwell.MaterialPreview(mxm=mxm_path)

            def preview_callback(re):
                result = re.begin_result(0, 0, re.resolution_x, re.resolution_y)
                mxp.UpdateResult(result.as_pointer())
                re.end_result(result)

            engine.session['preview_callback'] = preview_callback
    else:
        # TODO: hack
        try:
            _mat = bpy.context.scene.objects.active.active_material
            mxp = _mat.maxwell.preview
            preview = _mat.preview
        except:
            return

        if mxp.state == MaxwellRenderEngine.PREVIEW_START:
            mxs_path = BMaxwellPreferences.prefs().mxpath("preview", mxp.scene + ".mxs")
            mxs = pymaxwell.Scene()
            mxs.ReadMXS(mxs_path)
            mxs.RenderParams.update({
                'ENGINE': 'RS0',
                'STOP TIME': mxp.time_limit,
                'SAMPLING LEVEL': mxp.sampling_level,
                'DO NOT SAVE IMAGE FILE': True,
                'DO NOT SAVE MXI FILE': True,
            })
            mxm = mxs.GetMaterial("preview")
            mxm.Empty(True)

            export_material(mxm, mat, Textures(bpy.data.textures))

            def preview_callback(re):
                xres = re.resolution_x
                yres = re.resolution_y

                def cb(code, *data):
                    if code == 4:
                        result = re.begin_result(0, 0, xres, yres)
                        mxs.UpdatePreviewResult(result.as_pointer())
                        re.end_result(result)
                    elif code == 8:
                        re.report({'WARNING'}, *data)
                    elif code == 9:
                        re.report({'ERROR'}, *data)
                    return re.test_break()

                mxp.started()
                try:
                    mxs.Render(cb)
                    buf = mxs.GetPreviewBuffer()
                    if buf is not None:
                        height, width = buf.shape[:2]
                        pixels = numpy.array(buf, 'f', copy=False).reshape(-1)
                        try:
                            preview.image_size = width, height
                            preview.image_pixels_float = pixels
                        except AttributeError as e:
                            re.report({'WARNING'}, str(e))
                finally:
                    mxp.stop()

            engine.session['preview_callback'] = preview_callback
        else:
            width, height = preview.image_size
            if width and height:
                mxp = pymaxwell.MaterialPreview(
                    pixels=(preview.image_pixels_float, width, height)
                )

                def preview_callback(re):
                    result = re.begin_result(0, 0, re.resolution_x, re.resolution_y)
                    mxp.UpdateResult(result.as_pointer())
                    re.end_result(result)

                engine.session['preview_callback'] = preview_callback

def create(engine):
    engine.session = {}

def update(engine, data, scene):
    _log = Logger(report=engine.report)
    try:
        if engine.is_preview:
            ob = scene.objects['texture']
            if ob.is_visible(scene):
                tex = ob.active_material.active_texture
                if tex.type == 'IMAGE':
                    _texture_preview_update(engine, tex)
            else:
                _material_preview_update(engine, scene)
        else:
            is_animation = engine.is_animation
            mxs = export_scene(data, scene, engine.camera_override,
                               engine.resolution_x, engine.resolution_y,
                               _log, is_animation, _request_license)
            if mxs is not None:
                # TODO: bug? motion blur doesn't work
                # save and reload exported scene from a file
                PC = PerfCounter()

                props = scene.maxwell.render
                path = props.output_mxs
                if path:
                    dir, name = os.path.split(bpy_abspath(path))
                else:
                    dir = temporary_directory()
                    name = ""
                gfn = gen_filename(data, scene, name, ".mxs", is_animation)
                path = os.path.join(dir, gfn(scene.frame_current))
                _log("MXS: %s" % path, {'DEBUG'})

                mxs.WriteMXS(path)
                mxs.FreeScene()

                try:
                    mxs.ReadMXS(path)
                finally:
                    if not props.output_mxs_enabled:
                        os.unlink(path)
                _log("Reload scene (%fs)" % PC())

                engine.session['mxs'] = mxs
    except:
        _log("engine.update(...) failed\n" + traceback.format_exc(), {'ERROR'})

def render(engine, scene):
    _log = Logger(report=engine.report)
    try:
        session = engine.session
        if engine.is_preview:
            preview_callback = session.get('preview_callback')
            if preview_callback is not None:
                preview_callback(engine)
            else:  # clear
                result = engine.begin_result(
                    0, 0, engine.resolution_x, engine.resolution_y
                )
                engine.end_result(result)
        else:
            mxs = session.get('mxs')
            if mxs is not None:
                PC = PerfCounter()
                _log("Begin render (Engine: v%s, SDK: v%s)" % (
                    pymaxwell.engine_version(), pymaxwell.sdk_version()
                ))

                xres = engine.resolution_x
                yres = engine.resolution_y

                slf = mxs.RenderParams['SAMPLING LEVEL']

                def _fmt_time(seconds):
                    h, r = divmod(seconds, 3600)
                    m, s = divmod(r, 60)
                    if seconds > 0:
                        f = ""
                        if h > 0:
                            f += str(h) + "h"
                        if m > 0:
                            f += str(m) + "m"
                        if s > 0:
                            f += str(s) + "s"
                    else:
                        f = "..."
                    return f

                _fmt_stats = lambda bench, sl, tp, tl, nup, nsl: _STATS_FMT.format(
                    sl, _fmt_time(nsl), _fmt_time(nup), _fmt_time(tp), _fmt_time(tl), bench
                )

                def cb(code, *data):
                    if code == 1:  # TODO: voxelization end?
                        engine.update_progress(0)
                    elif code == 4:
                        session['time'] = time.clock()
                        session['stats'] = data
                        bench, sl, tp, tl, nup, nsl = data
                        _log("M~R: SL {:6.02f} ({:.02f})".format(sl, bench))
                        if tl < 0:  # Draft
                            engine.update_progress(sl / slf)
                        else:  # Production
                            engine.update_progress(tp / (tp + tl))
                        engine.update_stats(_fmt_stats(*data), "")
                        result = engine.begin_result(0, 0, xres, yres)
                        mxs.UpdateResult(result.as_pointer())
                        engine.end_result(result)
                    elif code == 5:
                        result = engine.begin_result(0, 0, xres, yres)
                        mxs.UpdateResult(result.as_pointer())
                        engine.end_result(result)
                    elif code == 6:
                        engine.update_progress(data[0] / 100.0)
                    elif code == 7:
                        stats = session.get('stats')
                        if stats is not None:
                            t = int(time.clock() - session['time'])
                            bench, sl, tp, tl, nup, nsl = stats
                            if tl < 0:  # Draft
                                engine.update_progress(sl / slf)
                            else:  # Production
                                engine.update_progress((tp + t) / (tp + tl))
                            engine.update_stats(_fmt_stats(
                                bench, sl, tp + t, tl - t, nup - t, nsl - t
                            ), "")
                    elif code == 8:
                        _log("M~R: {[0]}".format(data), {'WARNING'})
                    elif code == 9:
                        _log("M~R: {[0]}".format(data), {'ERROR'})
                    elif code == 10:
                        engine.update_stats(data[0], "")
                        _log("M~R: {[0]}".format(data), {'DEBUG'})
                    elif code == 11:
                        engine.update_stats(data[0], "")
                        _log("M~R: {[0]}".format(data), {'INFO'})
                    return engine.test_break()

                mxs.Render(cb)

                _log("End render (%fs)" % PC())
    except:
        _log("engine.render(...) failed\n" + traceback.format_exc(), {'ERROR'})

def view_update(engine, context):
    mxr = engine.session.get('mxr')
    try:
        if mxr is None:
            mxr = pymaxwell.Render(
                engine=engine.as_pointer(),
                data=context.blend_data.as_pointer(),
                scene=context.scene.as_pointer(),
                region=context.region.as_pointer(),
                v3d=context.space_data.as_pointer(),
                rv3d=context.region_data.as_pointer()
            )
            engine.session['mxr'] = mxr
        else:
            mxr.Update()
    except Exception as e:
        if mxr is not None:
            del engine.session['mxr']
        bpy.ops.maxwell.report(
            type={'WARNING'},
            message="%s\n%s" % (e, traceback.format_exc())
        )

def view_draw(engine, context):
    mxr = engine.session.get('mxr')
    if mxr is not None:
        mxr.Draw()

def free(engine):
    if hasattr(engine, 'session'):
        del engine.session
