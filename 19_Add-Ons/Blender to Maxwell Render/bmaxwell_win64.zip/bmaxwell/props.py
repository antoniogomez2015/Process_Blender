# -*- coding: utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Ildar Nikolaev"
__email__ = "nildar@users.sourceforge.net"

import os
import sys
import time as _tm

from operator import setitem
from math import pi as _PI

from bpy.types import (
    PropertyGroup,
    ImageTexture,
    Material,
    Scene,
    World,
    Camera,
    Object,
    Lamp,
    Mesh,
    Curve,
    TextCurve,
    MetaBall,
    ParticleSettings
)
from bpy.props import (
    PointerProperty,
    BoolProperty,
    IntProperty,
    EnumProperty,
    FloatProperty,
    StringProperty,
    IntVectorProperty,
    FloatVectorProperty,
    CollectionProperty
)
from . import (
    MaxwellRenderEngine,
    engine
)

_DEFAULT_MATERIAL = os.path.join(
    engine.MATERIALS_DATABASE,
    "mxm files",
    "default.mxm"
)

_OUTPUT_FORMATS = [
    ('png_8', "PNG 8", "PNG 8"),
    ('png_16', "PNG 16", "PNG 16"),
    ('tga_8', "TGA", "TGA"),
    ('tif_8', "TIF 8", "TIF 8"),
    ('tif_16', "TIF 16", "TIF 16"),
    ('tif_32', "TIF 32", "TIF 32"),
    ('exr_16', "EXR 16", "EXR 16"),
    ('exr_32', "EXR 32", "EXR 32"),
    ('jpg_8', "JPG", "JPG"),
    ('jp2_8', "JP2", "JP2"),
]

_OUTPUT_ALPHA_FORMATS = [
    ('png_8', "PNG 8", "PNG 8"),
    ('png_16', "PNG 16", "PNG 16"),
    ('tga', "TGA", "TGA"),
    ('tif_8', "TIF 8", "TIF 8"),
    ('tif_16', "TIF 16", "TIF 16"),
    ('tif_32', "TIF 32", "TIF 32"),
    ('exr_16', "EXR 16", "EXR 16"),
    ('exr_32', "EXR 32", "EXR 32"),
]

_AXIS = [
    ('YXZ', "YXZ (lw c4d rf)", "YXZ (lw c4d rf)", 0),
    ('ZXY', "ZXY (3dsmax maya)", "ZXY (3dsmax maya)", 1),
    ('YZX', "YZX (xsi maya houdini)", "YZX (xsi maya houdini)", 2)
]


def _EnableOnUpdate(prop, prop_enabled):
    def _update(self, context):
        if getattr(self, prop):
            if prop_enabled not in self:
                self[prop_enabled] = True
        else:
            try:
                del self[prop_enabled]
            except KeyError:
                pass
    return _update

def _UiEnabledProperty(prop, prop_enabled, **kwargs):
    def _get(self):
        if getattr(self, prop):
            return getattr(self, prop_enabled)
        return False
    def _set(self, value):
        if getattr(self, prop):
            setattr(self, prop_enabled, value)
    return BoolProperty(get=_get, set=_set, **kwargs)


#############################
#region Texture

PROCEDURAL_TYPES = [
    ('Brick', "Brick", "Brick", 0),
    ('Checker', "Checker", "Checker", 1),
    ('Circle', "Circle", "Circle", 2),
    ('Gradient3', "Gradient3", "Gradient3", 3),
    ('Gradient', "Gradient", "Gradient", 4),
    ('Grid', "Grid", "Grid", 5),
    ('Marble', "Marble", "Marble", 6),
    ('Noise', "Noise", "Noise", 7),
    ('Voronoi', "Voronoi", "Voronoi", 8),
    ('TiledTexture', "Tiled", "Tiled", 9),
    ('WireframeTexture', "Wireframe", "Wireframe", 10)
]
_TRANSITION_TYPES = [
    ('LINEAR', "Linear", "Linear", 0),
    ('QUADRATIC', "Quadratic", "Quadratic", 1),
    ('SINUSOIDAL', "Sinusoidal", "Sinusoidal", 2)
]
_COORDINATES_TYPES = [
    ('WORLD', "World", "World coordinates", 0),
    ('TEXTURE', "Texture", "Texture coordinates", 1)
]

def _texture_update(self, context):
    tex = self.id_data
    # force to update preview
    tex.type = tex.type

def _texture_preview(cls):
    for n in cls.__update__:
        cls.__dict__[n][1]['update'] = _texture_update
    return cls


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_brick(PropertyGroup):
    __update__ = (
        'blend',
        'width',
        'height',
        'brick_offset',
        'random_offset',
        'double',
        'small_width',
        'round_corners',
        'sharpness_u',
        'sharpness_v',
        'noise_detail',
        'noise_region_u',
        'noise_region_v',
        'seed',
        'random_rotation',
        'color_variation',
        'color0',
        'texture0',
        'factor0',
        'weight0',
        'color1',
        'texture1',
        'factor1',
        'weight1',
        'color2',
        'texture2',
        'factor2',
        'weight2',
        'mortar_thickness',
        'mortar_color',
        'mortar_texture'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    width = FloatProperty(
        name="Brick Width",
        default=0.24,
        min=0.0, max=100.0,
        precision=3,
        step=0.1
    )
    height = FloatProperty(
        name="Brick Height",
        default=0.11,
        min=0.0, max=100.0,
        precision=3,
        step=0.1
    )
    brick_offset = IntProperty(
        name="Brick Offset",
        default=50,
        min=0, max=100,
        subtype='UNSIGNED'
    )
    random_offset = IntProperty(
        name="Random Offset",
        min=0, max=100,
        subtype='UNSIGNED'
    )
    double = BoolProperty(
        name="Double Brick"
    )
    small_width = FloatProperty(
        name="Small Brick Width",
        default=0.105,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    round_corners = BoolProperty(
        name="Round Corners"
    )
    sharpness_u = FloatProperty(
        name="Boundary Sharpness U",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    sharpness_v = FloatProperty(
        name="Boundary Sharpness V",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    noise_detail = IntProperty(
        name="Boundary Noise Detail",
        min=0, max=100,
        subtype='UNSIGNED'
    )
    noise_region_u = FloatProperty(
        name="Boundary Noise Region U",
        min=0.0, max=1.0,
        precision=4,
        step=0.01
    )
    noise_region_v = FloatProperty(
        name="Boundary Noise Region V",
        min=0.0, max=1.0,
        precision=4,
        step=0.01
    )
    seed = IntProperty(
        name="Seed",
        default=4357,
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    random_rotation = BoolProperty(
        name="Random Rotation"
    )
    color_variation = IntProperty(
        name="Brightness Variation",
        default=10,
        min=0, max=100,
        subtype='UNSIGNED'
    )
    color0 = FloatVectorProperty(
        name="Color",
        description="Brick color 1",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    texture0 = StringProperty(
        name="Texture",
        description="Brick texture 1",
    )
    factor0 = IntProperty(
        name="Sample Size",
        description="Sample size 1",
        default=70,
        min=1, max=100,
        subtype='UNSIGNED'
    )
    weight0 = IntProperty(
        name="Weight",
        description="Weight 1",
        default=100,
        min=0, max=100,
        subtype='UNSIGNED'
    )
    color1 = FloatVectorProperty(
        name="Color",
        description="Brick color 2",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    texture1 = StringProperty(
        name="Texture",
        description="Brick texture 2"
    )
    factor1 = IntProperty(
        name="Sample Size",
        description="Sample size 2",
        default=70,
        min=1, max=100,
        subtype='UNSIGNED'
    )
    weight1 = IntProperty(
        name="Weight",
        description="Weight 2",
        default=100,
        min=0, max=100,
        subtype='UNSIGNED'
    )
    color2 = FloatVectorProperty(
        name="Color",
        description="Brick Color 3",
        size=3,
        default=(0.35, 0.35, 0.35),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    texture2 = StringProperty(
        name="Texture",
        description="Brick texture 3"
    )
    factor2 = IntProperty(
        name="Sample Size",
        description="Sample size 3",
        default=70,
        min=1, max=100,
        subtype='UNSIGNED'
    )
    weight2 = IntProperty(
        name="Weight",
        description="Weight 3",
        default=100,
        min=0, max=100,
        subtype='UNSIGNED'
    )
    mortar_thickness = FloatProperty(
        name="Thickness",
        description="Mortar thickness",
        default=0.015,
        min=0.0, max=1.0,
        precision=4,
        step=0.01
    )
    mortar_color = FloatVectorProperty(
        name="Color",
        description="Mortar color",
        size=3,
        default=(0.509, 0.490, 0.480),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    mortar_texture = StringProperty(
        name="Texture",
        description="Mortar texture"
    )
    ui_brick = BoolProperty(
        default=True
    )
    ui_brick1 = BoolProperty()
    ui_brick2 = BoolProperty()
    ui_brick3 = BoolProperty()
    ui_mortar = BoolProperty()


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_checker(PropertyGroup):
    __update__ = (
        'blend',
        'checks_u',
        'checks_v',
        'color0',
        'color1',
        'sharpness',
        'fall_off'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    checks_u = IntProperty(
        name="Checks U",
        default=4,
        min=1, max=1000,
        subtype='UNSIGNED'
    )
    checks_v = IntProperty(
        name="Checks V",
        default=4,
        min=1, max=1000,
        subtype='UNSIGNED'
    )
    color0 = FloatVectorProperty(
        name="Background Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color1 = FloatVectorProperty(
        name="Checker Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    sharpness = FloatProperty(
        name="Sharpness",
        default=1.0,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    fall_off = EnumProperty(
        name="Fall-off",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_circle(PropertyGroup):
    __update__ = (
        'blend',
        'background',
        'circle',
        'radius_u',
        'radius_v',
        'sharpness',
        'fall_off'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    background = FloatVectorProperty(
        name="Background Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    circle = FloatVectorProperty(
        name="Circle Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    radius_u = FloatProperty(
        name="Radius U",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    radius_v = FloatProperty(
        name="Radius V",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    sharpness = FloatProperty(
        name="Sharpness",
        default=1.0,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    fall_off = EnumProperty(
        name="Fall-off",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_gradient3(PropertyGroup):
    __update__ = (
        'blend',
        'use_u',
        'start_u',
        'middle_u',
        'end_u',
        'position_u',
        'type_u',
        'use_v',
        'start_v',
        'middle_v',
        'end_v',
        'position_v',
        'type_v'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    use_u = BoolProperty(
        name="Active",
        description="U Direction Active",
        default=True
    )
    start_u = FloatVectorProperty(
        name="Start Color",
        size=3,
        default=(1.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    middle_u = FloatVectorProperty(
        name="Middle Color",
        size=3,
        default=(0.0, 1.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    end_u = FloatVectorProperty(
        name="End Color",
        size=3,
        default=(0.0, 0.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    type_u = EnumProperty(
        name="Transition Type",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )
    position_u = FloatProperty(
        name="Mid Color Position",
        default=0.5,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    use_v = BoolProperty(
        name="Active",
        description="V Direction Active"
    )
    start_v = FloatVectorProperty(
        name="Start Color",
        size=3,
        default=(1.0, 0.0, .0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    middle_v = FloatVectorProperty(
        name="Middle Color",
        size=3,
        default=(0.0, 1.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    end_v = FloatVectorProperty(
        name="End Color",
        size=3,
        default=(0.0, 0.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    type_v = EnumProperty(
        name="Transition Type",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )
    position_v = FloatProperty(
        name="Mid Color Position",
        default=0.5,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    ui_u = BoolProperty(
        default=True
    )
    ui_v = BoolProperty()


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_gradient(PropertyGroup):
    __update__ = (
        'blend',
        'use_u',
        'start_u',
        'end_u',
        'position_u',
        'type_u',
        'use_v',
        'start_v',
        'end_v',
        'position_v',
        'type_v'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    use_u = BoolProperty(
        name="Active",
        description="U Direction Active",
        default=True
    )
    start_u = FloatVectorProperty(
        name="Start Color",
        size=3,
        default=(1.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    end_u = FloatVectorProperty(
        name="End Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    type_u = EnumProperty(
        name="Transition Type",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )
    position_u = FloatProperty(
        name="Transition Position",
        default=1.0,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    use_v = BoolProperty(
        name="Active",
        description="V Direction Active",
    )
    start_v = FloatVectorProperty(
        name="Start Color",
        size=3,
        default=(0.0, 0.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    end_v = FloatVectorProperty(
        name="End Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    type_v = EnumProperty(
        name="Transition Type",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )
    position_v = FloatProperty(
        name="Transition Position",
        default=1.0,
        min=0.0, max=1.0,
        precision=3,
        step=0.1
    )
    ui_u = BoolProperty(
        default=True
    )
    ui_v = BoolProperty()


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_grid(PropertyGroup):
    __update__ = (
        'blend',
        'cell',
        'background',
        'width',
        'height',
        'thickness_u',
        'thickness_v',
        'sharpness',
        'fall_off'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    background = FloatVectorProperty(
        name="Background Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    cell = FloatVectorProperty(
        name="Cell Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    width = FloatProperty(
        name="Cell Width",
        default=0.25,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    height = FloatProperty(
        name="Cell Height",
        default=0.125,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    thickness_u = FloatProperty(
        name="Background Thickness U",
        default=0.065,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    thickness_v = FloatProperty(
        name="Background Thickness U",
        default=0.065,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    sharpness = FloatProperty(
        name="Sharpness",
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    fall_off = EnumProperty(
        name="Fall-off",
        items=_TRANSITION_TYPES,
        default='LINEAR'
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_marble(PropertyGroup):
    __update__ = (
        'blend',
        'coordinates',
        'seed',
        'frequency',
        'detail',
        'octaves',
        'color0',
        'color1',
        'color2'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    coordinates = EnumProperty(
        name="Coordinates Type",
        items=_COORDINATES_TYPES,
        default='WORLD'
    )
    seed = IntProperty(
        name="Seed",
        default=4357,
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    frequency = FloatProperty(
        name="Frequency",
        default=2.5,
        min=0.0, max=1000.0,
        precision=3
    )
    detail = FloatProperty(
        name="Detail",
        default=4.0,
        min=0.0, max=100.0,
        precision=3
    )
    octaves = IntProperty(
        name="Octaves",
        default=9,
        min=1, max=100
    )
    color0 = FloatVectorProperty(
        name="Vein Color 1",
        size=3,
        default=(0.7803, 0.7921, 0.8235),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color1 = FloatVectorProperty(
        name="Vein Color 2",
        size=3,
        default=(0.5960, 0.6117, 0.6588),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color2 = FloatVectorProperty(
        name="Vein Color 3",
        size=3,
        default=(0.3411, 0.3568, 0.3843),
        min=0.0, max=1.0,
        subtype='COLOR'
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_noise(PropertyGroup):
    __update__ = (
        'blend',
        'coordinates',
        'seed',
        'low_clip',
        'hight_clip',
        'octaves',
        'persistance',
        'detail',
        'noise',
        'background'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    coordinates = EnumProperty(
        name="Coordinates Type",
        items=_COORDINATES_TYPES,
        default='WORLD'
    )
    seed = IntProperty(
        name="Seed",
        default=4357,
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    low_clip = FloatProperty(
        name="Low Clip",
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    hight_clip = FloatProperty(
        name="Hight Clip",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    octaves = IntProperty(
        name="Octaves",
        default=4,
        min=1, max=50
    )
    persistance = FloatProperty(
        name="Persistance",
        default=0.55,
        min=0.0, max=1.0,
        precision=4,
        step=0.1
    )
    detail = FloatProperty(
        name="Detail",
        default=6.2,
        min=1.0, max=1000.0,
        precision=4
    )
    noise = FloatVectorProperty(
        name="Noise Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    background = FloatVectorProperty(
        name="Background Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_voronoi(PropertyGroup):
    __update__ = (
        'blend',
        'coordinates',
        'low_clip',
        'hight_clip',
        'seed',
        'detail',
        'distance',
        'combination',
        'cell',
        'background'
    )
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    coordinates = EnumProperty(
        name="Coordinates Type",
        items=_COORDINATES_TYPES,
        default='WORLD'
    )
    low_clip = FloatProperty(
        name="Low Clip",
        min=0.0, max=1.0,
        precision=4,
        step=0.01
    )
    hight_clip = FloatProperty(
        name="Hight Clip",
        default=1.0,
        min=0.0, max=1.0,
        precision=4,
        step=0.01
    )
    seed = IntProperty(
        name="Seed",
        default=4357,
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    detail = IntProperty(
        name="Detail",
        default=8,
        min=1, max=10000
    )
    distance = EnumProperty(
        name="Distance",
        items=[
            ('EUCLIDIAN', "Euclidian", "Euclidian", 0),
            ('MANHATTAN', "Manhattan", "Manhattan", 1),
            ('MINKOWSKI4', "Minkowski4", "Minkowski4", 2),
            ('CHEBYSHEV', "Chebyshev", "Chebyshev", 3)
        ],
        default='EUCLIDIAN'
    )
    combination = EnumProperty(
        name="Combination",
        items=[
            ('D1', "D1", "D1", 0),
            ('D2', "D2", "D2", 1),
            ('D3', "D3", "D3", 2),
            ('D1+D2', "D1 + D2", "D1 + D2", 3),
            ('D2-D1', "D2 - D1", "D2 - D1", 4),
            ('D3-D2', "D3 - D2", "D3 - D2", 5),
            ('D1*D2', "D1 * D2", "D1 * D2", 6),
            ('D1*D3', "D1 * D3", "D1 * D3", 7),
            ('D2*D3', "D2 * D3", "D2 * D3", 8),
            ('1-D1', "1 - D1", "1 - D1", 9),
            ('1-D2', "1 - D2", "1 - D2", 10),
            ('1-(D1+D2)', "1 - (D1 + D2)", "1 - (D1 + D2)", 11),
            ('1-(D1*D2)', "1 - (D1 * D2)", "1 - (D1 * D2)", 12),
        ],
        default='D1'
    )
    cell = FloatVectorProperty(
        name="Cell Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    background = FloatVectorProperty(
        name="Background Color",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_tiled(PropertyGroup):
    blend = FloatProperty(
        name="Blending Factor",
        min=0.0, max=100.0,
        precision=3,
        step=10
    )
    filename = StringProperty(
        name="File Name",
        subtype='FILE_PATH'
    )
    mask = StringProperty(
        name="Token Mask",
        default="texture.<UDIM>.png"
    )
    base = FloatVectorProperty(
        name="Base Color",
        size=3,
        default=(0.8, 0.8, 0.8),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    use_base = BoolProperty(
        name="Use base color",
        default=True
    )


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_wireframe(PropertyGroup):
    fill_color = FloatVectorProperty(
        name="Fill Color",
        size=3,
        default=(0.8, 0.8, 0.8),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    edge_color = FloatVectorProperty(
        name="Edge Color",
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    coplanar_edge_color = FloatVectorProperty(
        name="Coplanar Edge Color",
        size=3,
        default=(0.3, 0.3, 0.3),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    edge_width = FloatProperty(
        name="Edge Width (cm)",
        default=2.0,
        min=0.0, max=1000000.0,
        precision=2
    )
    coplanar_edge_width = FloatProperty(
        name="Coplanar Edge Width (cm)",
        default=1.0,
        min=0.0, max=1000000.0,
        precision=2
    )
    coplanar_threshold = FloatProperty(
        name="Coplanar Threshold",
        default=20.0,
        min=0.0, max=100.0,
        precision=2
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_procedural(PropertyGroup):
    __update__ = (
        'enabled',
        'type'
    )
    enabled = BoolProperty(
        name="Enabled",
        default = True,
    )
    type = EnumProperty(
        name="Procedural Type",
        items=PROCEDURAL_TYPES,
        default='Checker'
    )
    brick = PointerProperty(
        type=MAXWELL_TEXTURE_brick
    )
    checker = PointerProperty(
        type=MAXWELL_TEXTURE_checker
    )
    circle = PointerProperty(
        type=MAXWELL_TEXTURE_circle
    )
    gradient3 = PointerProperty(
        type=MAXWELL_TEXTURE_gradient3
    )
    gradient = PointerProperty(
        type=MAXWELL_TEXTURE_gradient
    )
    grid = PointerProperty(
        type=MAXWELL_TEXTURE_grid
    )
    marble = PointerProperty(
        type=MAXWELL_TEXTURE_marble
    )
    noise = PointerProperty(
        type=MAXWELL_TEXTURE_noise
    )
    voronoi = PointerProperty(
        type=MAXWELL_TEXTURE_voronoi
    )
    tiled = PointerProperty(
        type=MAXWELL_TEXTURE_tiled
    )
    wireframe = PointerProperty(
        type=MAXWELL_TEXTURE_wireframe
    )


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_projection(PropertyGroup):
    channel = IntProperty(
        name="Channel",
        description="Specify the UV set to be used for this texture",
        default=0,
        min=0, max=254
    )
    tile_x = BoolProperty(
        name="Tile X",
        description="Tile your texture in X axis, Y axis, both the X and Y axis, "
                    "or do not use any tiling at all (no repeat)",
        default=True
    )
    tile_y = BoolProperty(
        name="Tile Y",
        description="Tile your texture in X axis, Y axis, both the X and Y axis, "
                    "or do not use any tiling at all (no repeat)",
        default=True
    )
    units = EnumProperty(
        name="Relative/Meters",
        description="The amount of tiling for a texture can be set in the texture "
                    "coordinates (Relative), or in real scale in meters (Meters)",
        items=[
            ('0', "Relative", "Relative", 0),
            ('1', "Meters", "Meters", 1)
        ],
        default='0'
    )
    mirror_x = BoolProperty(
        name="Mirror X"
    )
    mirror_y = BoolProperty(
        name="Mirror Y"
    )
    repeat = FloatVectorProperty(
        name="Repeat",
        description="Specify the tiling amount (number of repetitions of the texture) in the desired axis",
        default=(1.0, 1.0),
        min=-1000.0, max=1000.0,
        precision=3,
        size=2,
        step=100.0,
        subtype = 'XYZ'
    )
    offset = FloatVectorProperty(
        name="Offset",
        description="Select the amount of offset for the X, Y axis",
        default=(0.0, 0.0),
        min=-1000.0, max=1000.0,
        precision=3,
        size=2,
        step=10.0,
        subtype='XYZ'
    )
    rotation = FloatProperty(
        name="Rotation",
        default=0,
        min=0.0, max=360.0,
        precision=3,
        step=100.0
    )


@_texture_preview
@MaxwellRenderEngine.register_class
class MAXWELL_texture(PropertyGroup):
    __update__ = (
        'invert',
        'alpha_only',
        'interpolation',
        'brightness',
        'contrast',
        'saturation',
        'hue',
        'clamp'
    )
    # Projection Properties
    override = BoolProperty(
        name="Use Override Map"
    )
    projection = PointerProperty(
        name="Projection",
        type=MAXWELL_TEXTURE_projection
    )
    # Image Properties
    invert = BoolProperty(
        name="Invert",
        description="Invert the loaded texture. This is useful for"
                    " black & white textures used as a weightmap or mask"
    )
    alpha_only = BoolProperty(
        name="Alpha Only",
        description="On RGBA images (images that contain its Alpha channel"
                    " embedded), this option considers only the Alpha channel,"
                    " mainly for masking purposes"
    )
    interpolation = BoolProperty(
        name="Interpolation",
        description="Turning this option on applies filtering to a texture,"
                    " which may be useful to avoid pixelization when"
                    " rendering close-ups of smaller textures"
    )
    brightness = FloatProperty(
        name="Brightness",
        default=0,
        min=-100.0, max=100.0,
        precision=3
    )
    contrast = FloatProperty(
        name="Contrast",
        default=0,
        min=-100.0, max=100.0,
        precision=3
    )
    saturation = FloatProperty(
        name="Saturation",
        default=0,
        min=-100.0, max=100.0,
        precision=3
    )
    hue = FloatProperty(
        name="Hue",
        default=0,
        min=-180.0, max=180.0,
        precision=3
    )
    clamp = IntVectorProperty(
        name="RGB Clamp",
        description="Adjust the levels of your image. This function enables"
                    " you to specify the maximum darkest or brightest values"
                    " in the texture",
        default=(0, 255),
        min=0, max=255,
        size=2
    )
    # Normal maps
    flip_x = BoolProperty(
        name="Flip X"
    )
    flip_y = BoolProperty(
        name="Flip Y",
        default=True
    )
    wide = BoolProperty(
        name="Wide"
    )
    # Procedurals
    procedurals = CollectionProperty(
        type=MAXWELL_TEXTURE_procedural
    )
    active_procedural_index = IntProperty(
        default=-1,
        options=set()
    )

    @classmethod
    def register(cls):
        ImageTexture.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del ImageTexture.maxwell

#endregion


#############################
#region Material

EMITTER_TYPES = [
    ('COLOR', "Color", "Color", 0),
    ('TEMP', "Temperature", "Temperature", 1),
    ('HDRI', "HDR Image", "HDR Image", 2)
]
EMITTER_LOBE_TYPES = [
    ('AREA', "Area", "Area", 0),
    ('IES', "IES", "IES", 1),
    ('SPOT', "Spot", "Spot", 2)
]
EMITTER_LUMINANCES = [
    ('POWER', "Power & Efficacy", "Power & Efficacy", 0),
    ('LUMEN', "Lumen", "Lumen", 1),
    ('LUX', "Lux", "Lux", 2),
    ('CANDELA', "Candela", "Candela", 3),
    ('LUMINANCE', "Luminance", "Luminance", 4)
]
SPOT_FALLOFF_TYPES = [
    ('LINEAR', "Linear", "Linear", 0),
    ('SQUARE_ROOT', "Square root", "Square root", 1),
    ('SINUSOIDAL', "Sinusoidal", "Sinusoidal", 2),
    ('SQUARED_SINUSOIDAL', "Squared sinusoidal", "Squared sinusoidal", 3),
    ('CUADRATIC', "Cuadratic", "Cuadratic", 4),
    ('CUBIC', "Cubic", "Cubic", 5),
]


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_ags(PropertyGroup):
    color = FloatVectorProperty(
        name="Color",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    reflection = FloatProperty(
        name="Reflection",
        default=12.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1,
    )
    type = EnumProperty(
        name="Type",
        items=[
            ('0', "Normal", "Normal", 0),
            ('1', "Clear", "Clear", 1)
        ],
        default='0'
    )


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_opaque(PropertyGroup):
    color = FloatVectorProperty(
        name="Color",
        default=(0.713726, 0.713726, 0.713726),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Color Map",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    shininess = FloatProperty(
        name="Shininess",
        default=35.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    shininess_map = StringProperty(
        name="Shininess Map",
        update=_EnableOnUpdate('shininess_map', 'shininess_map_enabled')
    )
    shininess_map_enabled = BoolProperty()
    roughness = FloatProperty(
        name="Roughness",
        default=5.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    roughness_map = StringProperty(
        name="Roughness Map",
        update=_EnableOnUpdate('roughness_map', 'roughness_map_enabled')
    )
    roughness_map_enabled = BoolProperty()
    clearcoat = BoolProperty(
        name="Clearcoat"
    )
    # UI
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_shininess_map_enabled = _UiEnabledProperty('shininess_map', 'shininess_map_enabled')
    ui_roughness_map_enabled = _UiEnabledProperty('roughness_map', 'roughness_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_transparent(PropertyGroup):
    color = FloatVectorProperty(
        name="Color",
        default=(0.713726, 0.713726, 0.713726),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Color Map",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    ior = FloatProperty(
        name="Ref. Index",
        default=1.51,
        min=1.001, max=2.5,
        precision=3
    )
    transparency = FloatProperty(
        name="Transparency",
        default=30.0,
        min=0.1, max=999.0,
        precision=1
    )
    roughness = FloatProperty(
        name="Roughness",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1,
    )
    roughness_map = StringProperty(
        name="Roughness Map",
        update=_EnableOnUpdate('roughness_map', 'roughness_map_enabled')
    )
    roughness_map_enabled = BoolProperty(
        name="Roughness Map Enabled"
    )
    specular_tint = FloatProperty(
        name="Specular Tint",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    dispersion = FloatProperty(
        name="Dispersion",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    clearcoat = BoolProperty(
        name="Clearcoat"
    )
    # UI
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_roughness_map_enabled = _UiEnabledProperty('roughness_map', 'roughness_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_metal(PropertyGroup):
    ior = EnumProperty(
        name="Metal IOR",
        items=[
            ('0', "Aluminium", "Aluminium", 0),
            ('1', "Chromium", "Chromium", 1),
            ('2', "Cobalt", "Cobalt", 2),
            ('3', "Copper", "Copper", 3),
            ('4', "Germanium", "Germanium", 4),
            ('5', "Gold", "Gold", 5),
            ('6', "Iron", "Iron", 6),
            ('7', "Nickel", "Nickel", 7),
            ('8', "Silver", "Silver", 8),
            ('9', "Titanium", "Titanium", 9),
            ('10', "Vanadium", "Vanadium", 10)
        ],
        default='0'
    )
    tint = FloatProperty(
        name="Tint",
        min=0.0, max=100.0,
        precision=1
    )
    color = FloatVectorProperty(
        name="Color",
        default=(0.713726, 0.713726, 0.713726),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Color Map",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    roughness = FloatProperty(
        name="Roughness",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    roughness_map = StringProperty(
        name="Roughness Map",
        update=_EnableOnUpdate('roughness_map', 'roughness_map_enabled')
    )
    roughness_map_enabled = BoolProperty()
    anisotropy = FloatProperty(
        name="Anisotropy",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    anisotropy_map = StringProperty(
        name="Anisotropy Map",
        update=_EnableOnUpdate('anisotropy_map', 'anisotropy_map_enabled')
    )
    anisotropy_map_enabled = BoolProperty()
    angle = FloatProperty(
        name="Angle",
        min=0.0, max=360.0,
        precision=1
    )
    angle_map = StringProperty(
        name="Angle Map",
        update=_EnableOnUpdate('angle_map', 'angle_map_enabled')
    )
    angle_map_enabled = BoolProperty()
    dust = FloatProperty(
        name="Dust & Dirt",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    dust_map = StringProperty(
        name="Dust & Dirt Map",
        update=_EnableOnUpdate('dust_map', 'dust_map_enabled')
    )
    dust_map_enabled = BoolProperty()
    perforation_map = StringProperty(
        name="Perforation",
        update=_EnableOnUpdate('perforation_map', 'perforation_map_enabled')
    )
    perforation_map_enabled = BoolProperty()
    # UI
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_roughness_map_enabled = _UiEnabledProperty('roughness_map', 'roughness_map_enabled')
    ui_anisotropy_map_enabled = _UiEnabledProperty('anisotropy_map', 'anisotropy_map_enabled')
    ui_angle_map_enabled = _UiEnabledProperty('angle_map', 'angle_map_enabled')
    ui_dust_map_enabled = _UiEnabledProperty('dust_map', 'dust_map_enabled')
    ui_perforation_map_enabled = _UiEnabledProperty('perforation_map', 'perforation_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_translucent(PropertyGroup):
    scale = FloatProperty(
        name="Scale",
        default=1.0,
        min=0.0001, max=100000.0,
        precision=2
    )
    ior = FloatProperty(
        name="Ref. Index",
        default=1.3,
        min=1.001, max=2.5,
        precision=3
    )
    color = FloatVectorProperty(
        name="Color",
        default=(0.713726, 0.713726, 0.713726),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Color Map",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    hue_shift = FloatProperty(
        name="Hue Shift",
        min=-120.0, max=120.0,
        precision=1
    )
    invert_hue = BoolProperty(
        name="Invert Hue"
    )
    vibrance = FloatProperty(
        name="Vibrance",
        default=100.0,
        min=0.0, max=100.0,
        precision=1
    )
    density = FloatProperty(
        name="Density",
        default=50.0,
        min=0.0, max=100.0,
        precision=1
    )
    opacity = FloatProperty(
        name="Opacity",
        default=50.0,
        min=0.0, max=100.0,
        precision=1
    )
    roughness = FloatProperty(
        name="Roughness",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    roughness_map = StringProperty(
        name="Roughness Map",
        update=_EnableOnUpdate('roughness_map', 'roughness_map_enabled')
    )
    roughness_map_enabled = BoolProperty()
    specular_tint = FloatProperty(
        name="Specular Tint",
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    clearcoat = BoolProperty(
        name="Clearcoat"
    )
    clearcoat_ior = FloatProperty(
        name="Clearcoat IOR",
        default=1.3,
        min=1.001, max=2.5,
        precision=3
    )
    # UI
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_roughness_map_enabled = _UiEnabledProperty('roughness_map', 'roughness_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_carpaint(PropertyGroup):
    color = FloatVectorProperty(
        name="Color",
        default=(0.392157, 0.0, 0.062745),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    metallic = FloatProperty(
        name="Reflection",
        default=100.0,
        min=0.0, max=100.0,
        precision=1
    )
    topcoat = FloatProperty(
        name="Topcoat",
        default=50.0,
        min=1.001, max=100.0,
        precision=3
    )


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_hair(PropertyGroup):
    color = FloatVectorProperty(
        name="Color",
        default=(0.215686, 0.117647, 0.058824),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Color Map",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    root_tip_map = StringProperty(
        name="Root-Tip Map"
    )
    root_tip_weight = FloatProperty(
        name="Root-Tip Weight",
        default=50.0,
        min=1.0, max=100.0,
        precision=1,
    )
    root_tip_weight_map = StringProperty(
        name="Root-Tip Weight Map",
        update=_EnableOnUpdate('root_tip_weight_map', 'root_tip_weight_map_enabled')
    )
    root_tip_weight_map_enabled = BoolProperty()
    primary_strength = FloatProperty(
        name="Strength",
        default=40.0,
        min=1.0, max=100.0,
        precision=1,
    )
    primary_spread = FloatProperty(
        name="Spread",
        default=36.0,
        min=1.0, max=100.0,
        precision=1,
    )
    primary_tint = FloatVectorProperty(
        name="Tint",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    secondary_strength = FloatProperty(
        name="Strength",
        default=40.0,
        min=1.0, max=100.0,
        precision=1,
    )
    secondary_spread = FloatProperty(
        name="Spread",
        default=45.0,
        min=1.0, max=100.0,
        precision=1,
    )
    secondary_tint = FloatVectorProperty(
        name="Tint",
        default=(0.501961, 0.376471, 0.305882),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    # UI
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_root_tip_weight_map_enabled = _UiEnabledProperty('root_tip_weight_map', 'root_tip_weight_map_enabled')
    ui_primary = BoolProperty(
        default=True
    )
    ui_secondary = BoolProperty(
        default=True
    )


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_displacement(PropertyGroup):
    enabled = BoolProperty(
        name="Enabled",
        description="Enable Displacement"
    )
    # Global
    map = StringProperty(
        name="Map"
    )
    type = EnumProperty(
        name="Type",
        items=[
            ('0', "On-The-Fly", "On-The-Fly", 0),
            ('1', "Pretessellated", "Pretessellated", 1),
            ('2', "Vector", "Vector", 2)
        ],
        default='1'
    )
    level = IntProperty(
        name="Subdivision",
        description="Subdivision Level",
        default=6
    )
    adaptive = BoolProperty(
        name="Adaptive subdivision",
        description="Enable auto adaptive subdivision"
    )
    smooth = BoolProperty(
        name="Smoothing",
        default=True
    )
    offset = FloatProperty(
        name="Offset",
        min=-1000.0, max=1000.0,
        default=0.5,
        precision=1
    )
    method = EnumProperty(
        name="Method",
        description="Subdivision Method",
        items=[
            ('0', "Flat", "Flat", 0),
            ('1', "Catmull/Loop", "Catmull/Loop", 1)
        ],
        default='0'
    )
    uvi = EnumProperty(
        name="UV Interpolation",
        items=[
            ('0', "None", "None", 0),
            ('1', "Edges", "Edges", 1),
            ('2', "Edges and Corners", "Edges and Corners", 2),
            ('3', "Sharp", "Sharp", 3)
        ],
        default='2'
    )
    # HeightMap Properties
    height = FloatProperty(
        name="Height",
        min=-1000.0, max=1000.0,
        default=2.0,
        precision=1,
        step=100
    )
    absolute = BoolProperty(
        name="Use real units",
        description="Use real units for height"
    )
    # Vector 3D Properties
    preset = EnumProperty(
        name="Preset",
        items=[
            ('0', "Custom", "Custom", 0),
            ('1', "Zbrush Tangent", "Zbrush Tangent", 1),
            ('2', "Zbrush World", "Zbrush World", 2),
            ('3', "Mudbox Absolute Tangent", "Mudbox Absolute Tangent", 3),
            ('4', "Mudbox Object", "Mudbox Object", 4),
            ('5', "Mudbox World", "Mudbox World", 5),
            ('6', "Realflow", "Realflow", 6),
            ('7', "Modo", "Modo", 7)
        ],
        default='0'
    )
    transform = EnumProperty(
        name="Transform",
        items=[
            ('0', "Tangent", "Tangent", 0),
            ('1', "Object", "Object", 1),
            ('2', "World", "World", 2),
            ('3', "Realflow", "Realflow", 3)
        ],
        default='0'
    )
    mapping = EnumProperty(
        name="RGB Mapping",
        items=[
            ('0', "XYZ", "XYZ", 0),
            ('1', "XZY", "XZY", 1),
            ('2', "YZX", "YZX", 2),
            ('3', "YXZ", "YXZ", 3),
            ('4', "ZXY", "ZXY", 4),
            ('5', "ZYX", "ZYX", 5)
        ],
        default='0'
    )
    scale = FloatVectorProperty(
        name="Scale",
        description="Scale multiplier in each axis",
        default=(1.0, 1.0, 1.0),
        min=-100000.0, max=100000.0,
        subtype='XYZ'
    )
    # UI
    ui_height_map = BoolProperty(
        default=True
    )
    ui_vector = BoolProperty()


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_spot(PropertyGroup):
    def _update_map(self, context):
        if self.map:
            self.map_enabled = True

    map = StringProperty(
        name="Map",
        update=_update_map
    )
    map_enabled = BoolProperty(
        name="Map enabled"
    )
    cone_angle = FloatProperty(
        name="Cone Angle",
        min=0.01, max=179.99,
        default=45.0
    )
    falloff_angle = FloatProperty(
        name="FallOff Angle",
        min=0.0, max=89.99,
        default=10.0
    )
    falloff_type = EnumProperty(
        name="FallOff Type",
        items=SPOT_FALLOFF_TYPES,
        default='LINEAR'
    )
    blur = FloatProperty(
        name="Blur",
        default=1.0,
        min=0.01, max=1000.0
    )
    # UI
    def _get_map_enabled(self):
        if self.map and self.map_enabled:
            return True
        return False

    def _set_map_enabled(self, value):
        if self.map:
            self.map_enabled = value

    ui_map_enabled = BoolProperty(
        name="Enabled",
        description="Enable / disable map",
        get=_get_map_enabled,
        set=_set_map_enabled
    )


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_emitter(PropertyGroup):
    enabled = BoolProperty(
        description="Enable Emitter"
    )
    type = EnumProperty(
        name="Emission",
        description="Emission type",
        items=EMITTER_TYPES,
        default='COLOR'
    )
    color = FloatVectorProperty(
        name="Color",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_temp = FloatProperty(
        name="Temperature",
        description="Correlated temperature color",
        default=6500.0,
        min=273.0, max=100000.0,
        precision=1,
        step=1000
    )
    use_temperature = BoolProperty(
        name="K"
    )
    # Lobe
    lobe = EnumProperty(
        name="Type",
		description="Lobe type",
        items=EMITTER_LOBE_TYPES,
        default='AREA'
    )
    # Lobe.Luminance
    luminance = EnumProperty(
        name="Luminance",
        items=EMITTER_LUMINANCES,
        default='POWER'
    )
    # Power & Efficacy
    power = FloatProperty(
        name="Power",
        description="Power, W",
        default=40.0,
        min=0.0, max=1000000000.0,
        soft_min=0.0, soft_max=1000.0,
        precision=1,
        step=100
    )
    efficacy = FloatProperty(
        name="Efficacy",
        description="Efficacy, lm/W",
        default=17.6,
        min=0.0, max=683.0,
        precision=1,
        step=100
    )
    # Lumen, Lux, Candela, Luminance
    output = FloatProperty(
        name="Output",
        default=100.0
    )
    # Lobe.IES
    ies = StringProperty(
        name="IES/EULUMDAT",
        subtype='FILE_PATH'
    )
    # Lobe.Intensity
    intensity = FloatProperty(
        name="Intensity",
        default=1.0,
        min=0.0, max=100000.0,
        precision=1,
        step=100
    )
    spot = PointerProperty(
        type=MAXWELL_MATERIAL_spot
    )
    # Temperature
    temperature = FloatProperty(
        name="Temperature",
        default=6500.0,
        min=273.0, max=10000.0,
        precision=3,
        step=1000
    )
    # HDR Image
    hdri_map = StringProperty(
        name="Image"
    )
    hdri_intensity = FloatProperty(
        name="Intensity",
        description="Intensity",
        default=1.0,
        min=0.0, max=1000000.0,
        precision=1,
        step=100
    )
    # UI
    ui_temperature_color = FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        options=set(),
        get=lambda s: (0.1, 0.2, 0.3) #k2c(s.color_temp)
    )


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_coating(PropertyGroup):
    enabled = BoolProperty(
        name="Enable Coating"
    )
    thickness = FloatProperty(
        name="Thickness",
        description="Thickness (nanometers)",
        default=500.0,
        min=1.0, max=1000000.0,
        precision=3,
        step=1000
    )
    thickness_map = StringProperty(
        name="Thickness Texture",
        update=_EnableOnUpdate('thickness_map', 'thickness_map_enabled')
    )
    thickness_map_enabled = BoolProperty()
    thickness_min = FloatProperty(
        name="Min",
        description="Define the minimum virtual thickness (nanometers)",
        default=100.0,
        min=1.0, max=1000000.0,
        precision=3,
        step=1000
    )
    thickness_max = FloatProperty(
        name="Max",
        description="Define the maximum virtual thickness (nanometers)",
        default=1000.0,
        min=1.0, max=1000000.0,
        precision=3,
        step=1000
    )
    ior_type = EnumProperty(
        name="IOR",
        items=[
            ('0', "Custom", "Custom", 0),
            ('1', "Measured", "Measured Data", 1)
        ],
        default='0'
    )
    ior_file = StringProperty(
        name="File",
        subtype='FILE_PATH'
    )
    color = FloatVectorProperty(
        name="Reflectance 0",
        default=(0.6, 0.6, 0.6),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Reflectance 0",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    tangential = FloatVectorProperty(
        name="Reflectance 90",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    tangential_map = StringProperty(
        name="Reflectance 90",
        update=_EnableOnUpdate('tangential_map', 'tangential_map_enabled')
    )
    tangential_map_enabled = BoolProperty()
    nd = FloatProperty(
        name="Nd",
        description="The ND determines the index of refraction of the transparent material",
        default=3.0,
        min=0.01, max=1000.0,
        precision=3,
        step=100
    )
    force_fresnel = BoolProperty(
        name="Force Fresnel"
    )
    k = FloatProperty(
        name="K",
        default=0.0,
        min=0.0, max=1000.0,
        precision=3,
        step=100
    )
    fresnel_custom_enabled = BoolProperty(
        name="Custom Fresnel"
    )
    fresnel_custom_angle = FloatProperty(
        name="Angle",
        default=45.0,
        min=0.0, max=90.0
    )
    # UI
    ui_thickness_map_enabled = _UiEnabledProperty('thickness_map', 'thickness_map_enabled')
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_tangential_map_enabled = _UiEnabledProperty('tangential_map', 'tangential_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_bsdf(PropertyGroup):
    enabled = BoolProperty(
        name="Enabled",
        default=True
    )
    weight = FloatProperty(
        name="Weight",
        default=100.0,
        min=0.0, max=100.0,
        precision=1
    )
    weight_map = StringProperty(
        name="Weight",
        update=_EnableOnUpdate('weight_map', 'weight_map_enabled')
    )
    weight_map_enabled = BoolProperty()
    # BSDF Properties
    ior_type = EnumProperty(
        name="IOR",
        items=[
            ('0', "Custom", "Custom", 0),
            ('1', "Measured", "Measured Data", 1)
        ],
        default='0'
    )
    ior_file = StringProperty(
        name="File",
        subtype='FILE_PATH'
    )
    color = FloatVectorProperty(
        name="Reflectance 0",
        default=(0.6, 0.6, 0.6),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    color_map = StringProperty(
        name="Reflectance 0",
        update=_EnableOnUpdate('color_map', 'color_map_enabled')
    )
    color_map_enabled = BoolProperty()
    tangential = FloatVectorProperty(
        name="Reflectance 90",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    tangential_map = StringProperty(
        name="Reflectance 90",
        update=_EnableOnUpdate('tangential_map', 'tangential_map_enabled')
    )
    tangential_map_enabled = BoolProperty()
    transmittance = FloatVectorProperty(
        name="Transmittance",
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    transmittance_map = StringProperty(
        name="Transmittance",
        update=_EnableOnUpdate('transmittance_map', 'transmittance_map_enabled')
    )
    transmittance_map_enabled = BoolProperty()
    attenuation = FloatProperty(
        name="Attenuation",
        default=1.0,
        min=0.0, max=999.0
    )
    attenuation_units = EnumProperty(
        name="Units",
        items=[
            ('0', "nm", "Nanometers", 0),
            ('1', "um", "Microns", 1),
            ('2', "mm", "Millimeters", 2),
            ('3', "m", "Meters", 3),
            ('4', "cm", "Centimeters", 4),
            ('5', "dm", "Decimeters", 5)
        ],
        default='0'
    )
    nd = FloatProperty(
        name="Nd",
        description="The ND determines the index of refraction of the transparent material",
        default=3.0,
        min=0.01, max=1000.0,
        precision=3,
        step=100
    )
    force_fresnel = BoolProperty(
        name="Force Fresnel"
    )
    k = FloatProperty(
        name="K",
        default=0.0,
        min=0.0, max=1000.0,
        precision=3,
        step=100
    )
    abbe = FloatProperty(
        name="Abbe",
        description="Abbe (dispersion). Dispersion must be enabled in the Globals panel",
        default=50.0
    )
    fresnel_custom_enabled = BoolProperty(
        name="Custom Fresnel"
    )
    fresnel_custom_angle = FloatProperty(
        name="Angle",
        default=75.0,
        min=0.0, max=90.0
    )
    fresnel_custom_roughness = FloatProperty(
        name="Roughness",
        default=0.0,
        min=0.0, max=100.0
    )
    # Surface Properties
    roughness = FloatProperty(
        name="Roughness",
        default=100.0,
        min=0.0, max=100.0
    )
    roughness_map = StringProperty(
        name="Roughness",
        update=_EnableOnUpdate('roughness_map', 'roughness_map_enabled')
    )
    roughness_map_enabled = BoolProperty()
    bump = FloatProperty(
        name="Bump",
        default=30.0,
        min=0.0, max=100.0
    )
    bump_map = StringProperty(
        name="Bump",
        update=_EnableOnUpdate('bump_map', 'bump_map_enabled')
    )
    bump_map_enabled = BoolProperty()
    bump_normal = BoolProperty(
        name="Bump"
    )
    anisotropy = FloatProperty(
        name="Anisotropy",
        default=0.0,
        min=0.0, max=100.0
    )
    anisotropy_map = StringProperty(
        name="Anisotropy",
        update=_EnableOnUpdate('anisotropy_map', 'anisotropy_map_enabled')
    )
    anisotropy_map_enabled = BoolProperty()
    angle = FloatProperty(
        name="Angle",
        default=0.0,
        min=0.0, max=360.0
    )
    angle_map = StringProperty(
        name="Angle",
        update=_EnableOnUpdate('angle_map', 'angle_map_enabled')
    )
    angle_map_enabled = BoolProperty()
    # Subsurface Properties
    scattering = FloatVectorProperty(
        name="Scattering",
        default=(0.5, 0.5, 0.5),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    scattering_map = StringProperty(
        name="Scattering Texture",
        update=_EnableOnUpdate('scattering_map', 'scattering_map_enabled')
    )
    scattering_map_enabled = BoolProperty()
    scattering_coefficient = FloatProperty(
        name="Coef",
        default=0.0,
        min=0.0, max=99999.0
    )
    scattering_asymmetry = FloatProperty(
        name="Asymmetry",
        default=0.0,
        min=-1.0, max=1.0,
        precision=3
    )
    use_thickness = BoolProperty(
        name="Single Sided"
    )
    thickness = FloatProperty(
        name="Thickness",
        description="Thickness (mm)",
        default=1.0,
        min=0.001, max=10.0,
        precision=3
    )
    thickness_map = StringProperty(
        name="Thickness Texture",
        update=_EnableOnUpdate('thickness_map', 'thickness_map_enabled')
    )
    thickness_map_enabled = BoolProperty()
    thickness_min = FloatProperty(
        name="Min",
        description="Define the minimum virtual thickness (mm)",
        default=0.001,
        min=0.001, max=10.0,
        precision=3
    )
    thickness_max = FloatProperty(
        name="Max",
        description="Define the maximum virtual thickness (mm)",
        default=10.0,
        min=0.001, max=10.0,
        precision=3
    )
    coating = PointerProperty(
        type=MAXWELL_MATERIAL_coating
    )
    # UI
    ui_weight_map_enabled = _UiEnabledProperty('weight_map', 'weight_map_enabled')
    ui_color_map_enabled = _UiEnabledProperty('color_map', 'color_map_enabled')
    ui_tangential_map_enabled = _UiEnabledProperty('tangential_map', 'tangential_map_enabled')
    ui_transmittance_map_enabled = _UiEnabledProperty('transmittance_map', 'transmittance_map_enabled')
    ui_roughness_map_enabled = _UiEnabledProperty('roughness_map', 'roughness_map_enabled')
    ui_bump_map_enabled = _UiEnabledProperty('bump_map', 'bump_map_enabled')
    ui_bump_normal = BoolProperty(
        set=lambda s, v: setattr(s, 'bump_normal', not s.bump_normal)
    )
    ui_anisotropy_map_enabled = _UiEnabledProperty('anisotropy_map', 'anisotropy_map_enabled')
    ui_angle_map_enabled = _UiEnabledProperty('angle_map', 'angle_map_enabled')
    ui_scattering_map_enabled = _UiEnabledProperty('scattering_map', 'scattering_map_enabled')
    ui_thickness_map_enabled = _UiEnabledProperty('thickness_map', 'thickness_map_enabled')
    ui_bsdf = BoolProperty(
        default=True
    )
    ui_surface = BoolProperty()
    ui_subsurface = BoolProperty()


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_layer(PropertyGroup):
    def _update_name(self, context):
        layers = self.id_data.maxwell.layers
        if layers.keys().count(self.name) > 1:
            n = 1
            name = "Layer"
            while layers.find(name) >= 0:
                name = "Layer.%03d" % n
                n += 1
            self['name'] = name

    enabled = BoolProperty(
        name="Enabled",
        default=True
    )
    name = StringProperty(
        name="Name",
        default="Layer",
        update=_update_name
    )
    opacity = FloatProperty(
        name="Opacity",
        description="Like in Photoshop, you can set the Opacity value of a layer to define its visibility, "
                    "and thus, the visibility of the layers underneath",
        default=100.0,
        min=0.0, max=100.0,
        precision=1,
        step=100
    )
    opacity_map = StringProperty(
        name="Mask",
        description="In addition to Opacity values, you can also map the opacity of a layer using a mask map, "
                    "a greyscale image that indicates where the layer is visible",
        update=_EnableOnUpdate('opacity_map', 'opacity_map_enabled')
    )
    opacity_map_enabled = BoolProperty()
    blend = EnumProperty(
        name="Layer Blending",
        items=[
            ('0', "Normal", "Normal", 0),
            ('1', "Additive", "Additive", 1)
        ],
        default='0'
    )
    emitter = PointerProperty(
        type=MAXWELL_MATERIAL_emitter
    )
    bsdfs = CollectionProperty(
        type=MAXWELL_MATERIAL_bsdf
    )
    active_bsdf_index = IntProperty(
        options=set()
    )
    # UI
    ui_opacity_map_enabled = _UiEnabledProperty('opacity_map', 'opacity_map_enabled')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_preview(PropertyGroup):
    scene = StringProperty(
        name="Scene",
        default="defaultpreview"
    )
    sampling_level = FloatProperty(
        name="SL",
        description="Sample level",
        default=10.0,
        min=1.0, max=25.0
    )
    time_limit = IntProperty(
        name="Time",
        description="Time in seconds",
        default=10,
        min=1, max=999
    )

    _STATE = {}

    @property
    def state(self):
        return self._STATE.get(self.id_data)

    def started(self):
        self._STATE[self.id_data] = MaxwellRenderEngine.PREVIEW_STARTED

    def stop(self):
        try:
            del self._STATE[self.id_data]
        except KeyError:
            pass

    def _update(self, value):
        id_data = self.id_data
        _state = self._STATE.get(id_data)
        ps = MaxwellRenderEngine.PREVIEW_START
        if _state != ps and _state != MaxwellRenderEngine.PREVIEW_STARTED:
            self._STATE[id_data] = ps
        id_data.active_texture_index = id_data.active_texture_index

    update = BoolProperty(
        set=_update
    )


@MaxwellRenderEngine.register_class
class MAXWELL_material(PropertyGroup):
    type = EnumProperty(
        name="Type",
        description="Material Type",
        items=[
            ('FILE', "Referenced", "Referenced"),
            ('CUSTOM', "Custom", "Custom"),
            ('AGS', "AGS", "AGS"),
            ('OPAQUE', "Opaque", "Opaque"),
            ('TRANSPARENT', "Transparent", "Transparent"),
            ('METAL', "Metal", "Metal"),
            ('TRANSLUCENT', "Translucent", "Translucent"),
            ('CARPAINT', "Car Paint", "Car Paint"),
            ('HAIR', "Hair", "Hair")
        ],
        default='FILE'
    )
    # Referenced
    def _update_mxm(self, context):
        # update preview
        ob = context.object
        if ob:
            ob.active_material_index = ob.active_material_index

    mxm = StringProperty(
        name="MXM File",
        subtype='FILE_PATH',
        update=_update_mxm
    )
    embed = BoolProperty(
        name="Embed to Scene",
        description="Embed the material to the maxwell scene while exporting"
    )
    # Custom
    displacement = PointerProperty(
        type=MAXWELL_MATERIAL_displacement
    )
    layers = CollectionProperty(
        type=MAXWELL_MATERIAL_layer
    )
    active_layer_index = IntProperty(
        name="Active Layer",
        options=set()
    )
    # Globals
    override_map = PointerProperty(
        name="Override Map",
        type=MAXWELL_TEXTURE_projection
    )
    bump = FloatProperty(
        name="Bump/Normal",
        default=30.0,
        min=0.0, max=100.0,
        precision=1,
        step=100
    )
    bump_map = StringProperty(
        name="Global Bump"
    )
    bump_normal = BoolProperty(
        name="Normal"
    )
    dispersion = BoolProperty(
        name="Dispersion"
    )
    shadow = BoolProperty(
        name="Shadow"
    )
    matte = BoolProperty(
        name="Matte"
    )
    nested_priority = IntProperty(
        name="Nested Priority",
        subtype='UNSIGNED',
        min=0
    )
    color_id = FloatVectorProperty(
        name="Material ID",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    # Extensions
    ags = PointerProperty(
        type=MAXWELL_MATERIAL_ags
    )
    opaque = PointerProperty(
        type=MAXWELL_MATERIAL_opaque
    )
    transparent = PointerProperty(
        type=MAXWELL_MATERIAL_transparent
    )
    metal = PointerProperty(
        type=MAXWELL_MATERIAL_metal
    )
    translucent = PointerProperty(
        type=MAXWELL_MATERIAL_translucent
    )
    carpaint = PointerProperty(
        type=MAXWELL_MATERIAL_carpaint
    )
    hair = PointerProperty(
        type=MAXWELL_MATERIAL_hair
    )
    # custom alphas
    custom_alphas = property(fget=lambda s: s.get('_custom_alphas', []))
    active_custom_alpha_index = IntProperty(
        options=set()
    )

    preview = PointerProperty(
        type=MAXWELL_MATERIAL_preview
    )

    ui_bump_normal = BoolProperty(
        set=lambda s, v: setattr(s, 'bump_normal', not s.bump_normal)
    )

    @classmethod
    def register(cls):
        Material.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Material.maxwell

#endregion


#############################
#region Scene

@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_custom_alpha(PropertyGroup):
    id = IntProperty(
        options=set()
    )
    name = StringProperty(
        name="Name",
        description="Custom alpha channel name"
    )
    opaque = BoolProperty(
        name="Opaque",
        description="Opaque"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_channels(PropertyGroup):
    output_mode = EnumProperty(
        name="Output Mode",
        items=[
            ('0', "Separate", "Separate"),
            ('1', "Embedded", "Embedded")
        ],
        default='0'
    )
    render_enabled = BoolProperty(
        name="Render",
        default=True,
        description="To access in compositor enable Combined Pass"
    )
    render_type = EnumProperty(
        name="Render Type",
        items=[
            ('0', "All", "All", 0),
            ('1', "Diffuse", "Diffuse", 1),
            ('2', "Reflections", "Reflections", 2),
            ('2', "Refractions", "Refractions", 3),
            ('3', "Diffuse + Reflections", "Diffuse + Reflections", 4),
            ('4', "Reflections + Refractions", "Reflections + Refractions", 5)
        ],
        default='0'
    )
    # Alpha
    alpha_enabled = BoolProperty(
        name="Alpha",
        description="Enable Alpha channel"
    )
    alpha_format = EnumProperty(
        name="Alpha Format",
        items=_OUTPUT_ALPHA_FORMATS,
        default='exr_32'
    )
    alpha_opaque = BoolProperty(
        name="Opaque"
    )
    # Z-Buffer
    z_buffer_enabled = BoolProperty(
        name="Z-Buffer",
        description="Enable Z-Buffer channel"
    )
    z_buffer_format = EnumProperty(
        name="Z-buffer Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    z_buffer_range = FloatVectorProperty(
        name="Z-Buffer Range",
        default=(0.0, 1.0),
        min=-100000.0, max=100000.0,
        step=100,
        size=2
    )
    # Shadow
    shadow_enabled = BoolProperty(
        name="Shadow",
        description="Enable Shadow channel"
    )
    shadow_format = EnumProperty(
        name="Shadow Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Material ID
    material_id_enabled = BoolProperty(
        name="Material ID",
        description="Enable Material ID channel"
    )
    material_id_format = EnumProperty(
        name="Material ID Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Object ID
    object_id_enabled = BoolProperty(
        name="Object ID",
        description="Enable Object ID channel"
    )
    object_id_format = EnumProperty(
        name="Object ID Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Motion Vector
    motion_vector_enabled = BoolProperty(
        name="Motion Vector",
        description="Enable Motion Vector channel"
    )
    motion_vector_format = EnumProperty(
        name="Motion Vector Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Roughness
    roughness_enabled = BoolProperty(
        name="Roughness",
        description="Enable Roughness channel"
    )
    roughness_format = EnumProperty(
        name="Roughness Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Fresnel
    fresnel_enabled = BoolProperty(
        name="Fresnel",
        description="Enable Fresnel channel"
    )
    fresnel_format = EnumProperty(
        name="Fresnel Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Normals
    normals_enabled = BoolProperty(
        name="Normals",
        description="Enable Normals channel"
    )
    normals_format = EnumProperty(
        name="Normals Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    normals_space = EnumProperty(
        name="Normals Space",
        items=[
            ('0', "World", "World"),
            ('1', "Camera", "Camera")
        ],
        default='0'
    )
    # Position
    position_enabled = BoolProperty(
        name="Position",
        description="Enable Position channel"
    )
    position_format = EnumProperty(
        name="Position Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    position_space = EnumProperty(
        name="Position Space",
        items=[
            ('0', "World", "World"),
            ('1', "Camera", "Camera")
        ],
        default='0'
    )
    # Deep
    deep_enabled = BoolProperty(
        name="Deep Enabled",
        description="Enable Deep channel"
    )
    deep_format = EnumProperty(
        name="Deep Format",
        items=[
            ('EXR', "EXR DEEP", "EXR DEEP"),
            ('DTEX', "DTEX", "DTEX")
        ],
        default='EXR'
    )
    deep_channels = EnumProperty(
        name="Deep Channels",
        items=[
            ('ALPHA', "Alpha", "Alpha"),
            ('RGBA', "RGBA", "RGBA")
        ],
        default='ALPHA'
    )
    deep_distance = FloatProperty(
        name="Min dist (m)",
        default=0.2,
        precision=3,
        min=0.0, max=1000.0,
        step=100
    )
    deep_samples = IntProperty(
        name="Max samples",
        default=20,
        min=1, max=100000
    )
    # UV
    uv_enabled = BoolProperty(
        name="UV",
        description="Enable UV channel"
    )
    uv_format = EnumProperty(
        name="UV Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Custom Alpha
    custom_alpha_enabled = BoolProperty(
        name="Custom Alpha",
        description="Enable Custom Alpha channel"
    )
    custom_alpha_format = EnumProperty(
        name="Custom Alpha Format",
        items=_OUTPUT_ALPHA_FORMATS,
        default='exr_32'
    )
    # Reflectance
    reflectance_enabled = BoolProperty(
        name="UV",
        description="Enable Reflectance channel"
    )
    reflectance_format = EnumProperty(
        name="Reflectance Format",
        items=_OUTPUT_FORMATS,
        default='exr_32'
    )
    # Custom Alpha Channels
    custom_alphas = CollectionProperty(
        type=MAXWELL_SCENE_custom_alpha
    )
    active_custom_alpha_index = IntProperty(
        options=set()
    )
    active_custom_alpha_object_index = IntProperty(
        options=set()
    )
    active_custom_alpha_material_index = IntProperty(
        options=set()
    )
    ui_custom_alpha_objects = BoolProperty()
    ui_custom_alpha_materials = BoolProperty()


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_extra_sampling(PropertyGroup):
    enabled = BoolProperty(
        name="Enabled"
    )
    mask = EnumProperty(
        name="Mask",
        items=[
            ('CUSTOM_ALPHA', "Custom Alpha", "Custom Alpha", 0),
            ('ALPHA', "Alpha", "Alpha", 1),
            ('BITMAP', "Bitmap", "Bitmap", 2)
        ],
        default='CUSTOM_ALPHA'
    )
    sampling_level = FloatProperty(
        name="Sampling Level",
        default=14.0,
        min=0.0, max=50.0,
        precision=2,
        step=100
    )
    channel_id = IntProperty(
        name="Custom Alpha"
    )
    bitmap = StringProperty(
        name="Bitmap",
        subtype='FILE_PATH'
    )
    invert_mask = BoolProperty(
        name="Invert Mask"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_searching_path(PropertyGroup):
    name = StringProperty(
        name="Search path",
        subtype='DIR_PATH',
        options=set()
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_overlay_text(PropertyGroup):
    enabled = BoolProperty(
        name="Text"
    )
    text = StringProperty(
        name="Text"
    )
    position = EnumProperty(
        name="Position",
        items=[
            ('0', "Bottom", "Bottom"),
            ('1', "Top", "Top")
        ]
    )
    color = FloatVectorProperty(
        name="Color",
        description="Text color",
        default=(26/255, 26/255, 26/255),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    background = FloatVectorProperty(
        name="Background Color",
        default=(178/255, 178/255, 178/255),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    background_enabled = BoolProperty(
        name="Background",
        description="Enable background",
        default=True
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_render(PropertyGroup):
    # Scene
    time_limit = IntProperty(
        name="Time Limit (min)",
        default=10
    )
    sampling_level = FloatProperty(
        name="Sampling Level",
        default=12.0
    )
    multilight = EnumProperty(
        name="Multilight",
        items=[
            ('0', "Disabled", "No multilight"),
            ('1', "Intensity", "Intensity multilight"),
            ('2', "Color", "Intensity + Color multilight")
        ],
        default='0'
    )
    multilight_save_lights = EnumProperty(
        name="Save Lights",
        items=[
            ('0', "Composite", "Composite"),
            ('1', "Separate", "Separate")
        ],
        default='0'
    )
    threads = IntProperty(
        name="Threads",
        default=0,
        min=0,
    )
    quality = EnumProperty(
        name="Quality",
        items=[
            ('RS0', "Draft", "Draft"),
            ('RS1', "Production", "Production"),
            # TODO: inspect
            #('RS2', "RS2", "RS2"),
            #('RSMXI', "RSMXI", "RSMXI")
        ],
        default='RS1'
    )
    # Output
    def _output_depth_items(self, context):
        # .png .jpg .tga .tif .jp2 .exr .psd .bmp .ppm .pbm .pgm .hdr
        ext = os.path.splitext(self.output_image)[1].lower()
        if ext == ".png":
            items = [
                ('8', "RGB 8 bpc", "RGB 8 bits per color", 8),
                ('16', "RGB 16 bpc", "RGB 16 bits per color", 16)
            ]
        elif ext == ".exr":
            items = [
                ('16', "RGB 16 bpc", "RGB 16 bits per color", 16),
                ('32', "RGB 32 bpc", "RGB 32 bits per color", 32)
            ]
        elif ext == ".hdr":
            items = [
                ('32', "RGB 32 bpc", "RGB 32 bits per color", 32)
            ]
        elif ext in {".tif", ".tiff", ".psd"}:
            items = [
                ('8', "RGB 8 bpc", "RGB 8 bits per color", 8),
                ('16', "RGB 16 bpc", "RGB 16 bits per color", 16),
                ('32', "RGB 32 bpc", "RGB 32 bits per color", 32)
            ]
        elif ext in {".tga", ".jpg", ".jp2", ".bmp", ".ppm", ".pbm", ".pgm"}:
            items = [
                ('8', "RGB 8 bpc", "RGB 8 bits per color", 8)
            ]
        else:
            # need for presets
            items = [
                ('8', "RGB 8 bpc", "RGB 8 bits per color", 8),
                ('16', "RGB 16 bpc", "RGB 16 bits per color", 16)
            ]
        return items

    def _output_image_update(self, context):
        img = self.output_image
        ext = os.path.splitext(img)[1].lower()
        depth = self.get('output_depth')
        if ext == ".png":
            if depth not in {8, 16}:
                self['output_depth'] = 8
        elif ext == ".exr":
            if depth not in {16, 32}:
                self['output_depth'] = 16
        elif ext == ".hdr":
            if depth != 32:
                self['output_depth'] = 32
        elif ext in {".tif", ".tiff", ".psd"}:
            if depth not in {8, 16, 32}:
                self['output_depth'] = 8
        elif ext in {".tga", ".jpg", ".jp2", ".bmp", ".ppm", ".pbm", ".pgm"}:
            if depth != 8:
                self['output_depth'] = 8
        else:
            if not img.endswith("/"):
                self['output_image'] = img + ".png"
            if depth not in {8, 16}:
                self['output_depth'] = 8

    output_depth = EnumProperty(
        name="Depth",
        items=_output_depth_items,
        get=lambda s: s.get('output_depth', 8),
        set=lambda s, v: setitem(s, 'output_depth', v),
        options=set()
    )
    output_image = StringProperty(
        name="Image",
        description="Directory / file name to save output image",
        subtype='FILE_PATH',
        default="//",
        update=_output_image_update
    )
    output_image_enabled = BoolProperty(
        name="Save image"
    )
    output_mxi = StringProperty(
        name="MXI",
        description="Directory / file name to save output MXI file",
        subtype='FILE_PATH',
        default="//"
    )
    output_mxi_enabled = BoolProperty(
        name="Save MXI"
    )
    output_mxs = StringProperty(
        name="MXS",
        description="Directory / file name to save temporary MXS file",
        subtype='FILE_PATH'
    )
    output_mxs_enabled = BoolProperty(
        name="Keep MXS",
        description="Don't delete temporary MXS file on rendering"
    )
    # Globals
    motion_blur = BoolProperty(
        name="Motion Blur",
        description="Enable motion blur"
    )
    motion_blur_steps = IntProperty(
        name="Steps",
        description="Motion blur steps",
        default=1,
        min=1, max=10000,
    )
    displacement = BoolProperty(
        name="Displacement",
        description="Enable displacement",
        default=True
    )
    dispersion = BoolProperty(
        name="Dispersion",
        description="Enable dispersion",
        default=True
    )
    # Illumination & Caustics
    illumination = EnumProperty(
        name="Illumination",
        items=[
            ('0', "None", "No Illumination Layer"),
            ('1', "Direct", "Direct Illumination Layer"),
            ('2', "Indirect", "Indirect Illumination Layer"),
            ('3', "Both", "Direct + Indirect Illumination Layer")
        ],
        default='3'
    )
    reflection_caustics = EnumProperty(
        name="Refl.Caustics",
        items=[
            ('0', "None", "No Reflection Caustics Layer"),
            ('1', "Direct", "Direct Reflection Caustics Layer"),
            ('2', "Indirect", "Indirect Reflection Caustics Layer"),
            ('3', "Both", "Direct + Indirect Reflection Caustics Layer")
        ],
        default='3'
    )
    refraction_caustics = EnumProperty(
        name="Refr.Caustics",
        items=[
            ('0', "None", "No Refraction Caustics Layer"),
            ('1', "Direct", "Direct Refraction Caustics Layer"),
            ('2', "Indirect", "Indirect Refraction Caustics Layer"),
            ('3', "Both", "Direct + Indirect Refraction Caustics Layer")
        ],
        default='3'
    )
    # Materials
    override_material_enabled = BoolProperty(
        name="Override",
        description="Enable override material",
    )
    override_material = StringProperty(
        name="Override Material",
        default=_DEFAULT_MATERIAL,
        description="Sets the path of the material that overrides all "
                    "the materials of the scene (except emitter materials)",
        subtype='FILE_PATH'
    )
    default_material = StringProperty(
        name="Default",
        default=_DEFAULT_MATERIAL,
        description="Sets the path of the material that will be used for all "
                    "the objects/triangles without material",
        subtype='FILE_PATH'
    )
    searching_paths = CollectionProperty(
        type=MAXWELL_SCENE_searching_path
    )
    active_searching_path_index = IntProperty(
        options=set()
    )
    # Tone Mapping
    color_space = EnumProperty(
        name="Color Space",
        items=[
            ('0', "sRGB IEC61966-2.1", "sRGB IEC61966-2.1"),
            ('1', "Adobe RGB 98", "Adobe RGB 98"),
            ('2', "Apple RGB / SGI", "Apple RGB / SGI"),
            ('3', "PAL / SECAM (EBU3213)", "PAL / SECAM (EBU3213)"),
            ('4', "NTSC 1953", "NTSC 1953"),
            ('5', "NTSC 1979 (SMPTE-C)", "NTSC 1979 (SMPTE-C)"),
            ('6', "Wide Gamut RGB", "Wide Gamut RGB"),
            ('7', "ProPhoto RGB (ROMM)", "ProPhoto RGB (ROMM)"),
            ('8', "ECI RGB", "ECI RGB"),
            ('9', "CIE 1931", "CIE 1931"),
            ('10', "Bruce RGB", "Bruce RGB"),
            ('11', "ColorMatch RGB", "ColorMatch RGB"),
            ('12', "Best RGB", "Best RGB"),
            ('13', "Don RGB 4", "Don RGB 4"),
            ('14', "HDTV (Rec.709)", "HDTV (Rec.709)"),
            ('15', "ACES", "ACES")
        ],
        default='0'
    )
    gamma = FloatProperty(
        name="Monitor Gamma",
        default=2.2,
        min=0.1, max=3.5,
        soft_min=0.1, soft_max=3.5,
        precision=1,
        step=0.1
    )
    burn = FloatProperty(
        name="Burn",
        default=0.8,
        min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0,
        precision=1,
        step=0.1
    )
    white_point = FloatProperty(
        name="White Point",
        default=6500.0,
        min=2000.0, max=20000.0,
        precision=1,
        step=10
    )
    tint = FloatProperty(
        name="Tint",
        default=0.0,
        min=-100.0, max=100.0,
        precision=1,
        step=10
    )
    sharpness_enabled = BoolProperty(
        name="Enable Sharpness"
    )
    sharpness = FloatProperty(
        name="Sharpness",
        default=60.0,
        min=0.0, max=100.0,
        precision=2,
        step=1,
        subtype='PERCENTAGE'
    )
    # Simulens
    diffraction_enabled = BoolProperty(
        name="Enable Diffraction"
    )
    diffraction = FloatProperty(
        name="Diffraction",
        default=1250.0,
        min=0.0, max=2500.0,
        precision=2,
        step=100
    )
    frequency = FloatProperty(
        name="Frequency",
        default=1250.0,
        min=0.0, max=2500.0,
        precision=2,
        step=100
    )
    aperture_map = StringProperty(
        name="Aperture Map",
        subtype='FILE_PATH'
    )
    obstacle_map = StringProperty(
        name="Obstacle Map",
        subtype='FILE_PATH'
    )
    scattering_enabled = BoolProperty(
        name="Enable Scattering"
    )
    scattering = FloatProperty(
        name="Scattering",
        default=0.0,
        min=0.0, max=2500.0,
        precision=2,
        step=100
    )
    devignetting_enabled = BoolProperty(
        name="Enable Devignetting"
    )
    devignetting = FloatProperty(
        name="Devignetting",
        default=100.0,
        min=-100.0, max=100.0,
        precision=2,
        step=100,
        subtype='PERCENTAGE'
    )
    # Channels
    channels = PointerProperty(
        type=MAXWELL_SCENE_channels
    )
    # Extra Sampling
    extra_sampling = PointerProperty(
        type=MAXWELL_SCENE_extra_sampling
    )
    # Overlay Text
    overlay_text = PointerProperty(
        type=MAXWELL_SCENE_overlay_text
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_fire(PropertyGroup):
    sampling_level = FloatProperty(
        name="Sampling Level",
        default=7.0,
        options=set()
    )
    time_limit = IntProperty(
        name="Time Limit (s)",
        default=20,
        options=set()
    )
    quality = IntProperty(
        name="Quality",
        min=1, max=10,
        default=4,
        options=set()
    )
    floating_shadows = BoolProperty(
        name="Floating Shadows",
        options=set()
    )
    floating_reflections = BoolProperty(
        name="Floating Reflections",
        options=set()
    )


@MaxwellRenderEngine.register_class
class MAXWELL_SCENE_visualization(PropertyGroup):
    # referenced objects
    ref_percent = IntProperty(
        name="Percent",
        description="Display percent of points",
        default=100,
        min=1, max=100,
        subtype='PERCENTAGE',
        options=set()
    )
    ref_points = IntProperty(
        name="Max Points",
        default=10000,
        min=-1,
        options=set()
    )
    ref_point_size = IntProperty(
        name="Point Size",
        default=3,
        min=1, max=5,
        options=set()
    )
    ref_color = FloatVectorProperty(
        name="Color",
        size=4,
        default=(0.6, 0.6, 0.6, 0.6),
        min=0.0, max=1.0,
        subtype='COLOR',
        options=set()
    )
    # ies
    ies_point_size = IntProperty(
        name="Point Size",
        default=3,
        min=1, max=5,
        options=set()
    )
    ies_alpha = FloatProperty(
        name="Alpha",
        description="Transparency",
        default=0.6,
        min=0.0, max=1.0,
        subtype='PERCENTAGE',
        options=set()
    )
    # vdb
    vdb_color = FloatVectorProperty(
        name="VDB Color",
        size=4,
        default=(0.6, 0.6, 0.6, 0.6),
        min=0.0, max=1.0,
        subtype='COLOR',
        options=set()
    )
    # asset
    asset_color = FloatVectorProperty(
        name="Assets Color",
        size=4,
        default=(0.6, 0.6, 0.6, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR',
        options=set()
    )


@MaxwellRenderEngine.register_class
class MAXWELL_scene(PropertyGroup):
    render = PointerProperty(
        type=MAXWELL_SCENE_render
    )
    fire = PointerProperty(
        type=MAXWELL_SCENE_fire
    )
    visualization = PointerProperty(
        type=MAXWELL_SCENE_visualization
    )

    @classmethod
    def register(cls):
        Scene.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Scene.maxwell

#endregion


#############################
#region Environment

@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_sun(PropertyGroup):
    type = EnumProperty(
        name="Type",
        description="Sun type",
        items=[
            ('0', "Disabled", "Sun disabled"),
            ('1', "Physical", "Physical"),
            ('2', "Custom", "Custom")
        ],
        default='1'
    )
    power = FloatProperty(
        name="Power",
        description="A multiplier that controls the amount of light emitted from the sun",
        default=1.0,
        min=sys.float_info.min,
        soft_min=0.01, soft_max=100.0,
        precision=3,
        step=10
    )
    radius = FloatProperty(
        name="Radius Factor",
        description="Radius factor",
        default=1.0,
        min=0.01, max=1000.0
    )
    temperature = FloatProperty(
        name="Temperature",
        description="Temperature of the sun's spectral radiation",
        default=5777.0,
        min=1.0, max=1000000.0,
        soft_min=100.0, soft_max=10000.0, # 1-10000 studio limits
        precision=3,
        step=1000
    )
    color = FloatVectorProperty(
        name="Color",
        description="Color of the sun",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    position = EnumProperty(
        name="Position",
        description="Way to set the sun position",
        items=[
            ('0', "Lat/Lon", "Set the earth position to calculate the sky/sun light direction"),
            ('1', "Angles", "Set the sun position based on a spherical angles"),
            ('2', "Direction", "Set the sun position based on a direction")
        ],
        default='0'
    )
    latitude = FloatProperty(
        name="Latitude",
        description="Latitude",
        min=-90.0, max=90.0,
        precision=6,
        step=100,
    )
    longitude = FloatProperty(
        name="Longitude",
        description="Longitude",
        min=-180.0, max=180.0,
        precision=6,
        step=100,
    )
    day = IntProperty(
        default=100
    )
    time = FloatProperty(
        default=17.0
    )
    gmt = IntProperty(
        name="GMT",
        description="GMT offset",
        default=0,  # -int((_tm.timezone / (60 * 60)))
        min=-12, max=12,
    )
    rotation = FloatProperty(
        name="Ground Rotation",
        description="Allow you rotate the north direction (radians)",
        min=0.0, max=_PI * 2,
        precision=3,
        step=100,
        subtype='ANGLE'
    )
    zenith = FloatProperty(
        name="Zenith",
        default=_PI / 4,
        min=0.0, max=_PI / 2,
        precision=4,
        step=1,
        subtype='ANGLE'
    )
    azimuth = FloatProperty(
        name="Azimuth",
        default=_PI / 4,
        min=0.0, max=_PI * 2,
        precision=4,
        step=1,
        subtype='ANGLE'
    )
    direction = FloatVectorProperty(
        name="Direction",
        size=3,
        default=(0.0, 0.0, 1.0),
        min=-1000.0, max=1000.0,
        soft_min=-1000.0, soft_max=1000.0,
        precision=4,
        step=1000,
        subtype='XYZ'
    )
    direction_object = StringProperty(
        name="Direction object",
        description="Set the sun position based on a object"
    )

    def _get_time(self):
        return _tm.strftime("%H:%M:%S", _tm.gmtime(round(self.time * 3600)))

    def _set_time(self, value):
        t = _tm.strptime(value, "%H:%M:%S")
        self.time = (t.tm_hour*3600 + t.tm_min*60 + t.tm_sec) / 3600

    def _get_date(self):
        t = (_tm.localtime().tm_year, 1, self.day, 0, 0, 0, 0, 0, -1)
        return _tm.strftime("%Y-%m-%d", _tm.localtime(_tm.mktime(t)))

    def _set_date(self, value):
        self.day = _tm.strptime(value, "%Y-%m-%d").tm_yday

    ui_date = StringProperty(
        name="Date",
        description="Set the date",
        default="2012-04-09",
        get=_get_date,
        set=_set_date,
        maxlen=10
    )
    ui_time = StringProperty(
        name="Time",
        description="Set the time",
        default="17:00:00",
        get=_get_time,
        set=_set_time,
        maxlen=8
    )


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_constant_sky(PropertyGroup):
    luminance = FloatProperty(
        name="Intensity",
        description="Intensity of the Sky Dome in cd/m2",
        default=10000.0,
        subtype='UNSIGNED',
        min=0.1, max=1000000.0,
        precision=3,
        step=1000
    )
    zenith = FloatVectorProperty(
        name="Zenith",
        description="Color of the dome at the zenith (the highest point above our head)",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    horizon = FloatVectorProperty(
        name="Horizon",
        description="Color of the dome at the horizon",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    control_point = FloatProperty(
        name="Mid Point",
        description="Transition between the Zenith and Horizon colors (in degrees)",
        default=45.0,
        min=0.0, max=90.0,
        precision=1,
        step=10
    )


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_physical_sky(PropertyGroup):
    intensity = FloatProperty(
        name="Intensity",
        default=1.0,
        min=0.0, max=10000.0,
        precision=2,
        step=100
    )
    ozone = FloatProperty(
        name="Ozone (cm)",
        description="The amount of ozone gas in the atmosphere",
        default=0.4,
        min=0.0, max = 50.0,
        precision=3,
        step=10
    )
    water = FloatProperty(
        name="Water (cm)",
        description="The amount of water vapor in the atmosphere",
        default=2.0,
        min=0.0, max=500.0,
        precision=3,
        step=100
    )
    angstrom = FloatProperty(
        name="Turbidity Coefficient",
        description="Defines the concentration and amount of particles in the atmosphere",
        default=0.04,
        min=0.0, max=10.0,
        precision=3,
        step=1
    )
    wavelength = FloatProperty(
        name="Wavelength Exponent",
        description="Defines the average size of the particles in the atmosphere",
        default=1.2,
        min=0.0, max=300.0,
        precision=3,
        step=10
    )
    albedo = FloatProperty(
        name="Reflectance",
        description="Refers to the albedo of the aerosols, "
                    "or the rate of energy scattered and absorbed by the aerosols",
        default=80.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=2,
        step=10
    )
    asymmetry = FloatProperty(
        name="Asymmetry",
        description="This factor control the anisotropy of the particles, "
                    "that is, in which direction most of light will be scattered",
        default=0.7,
        min=-0.99999, max=0.99999,
        precision=5,
        step=0.1
    )
    planet_reflectance = FloatProperty(
        name="Planet Reflectance",
        description="Controls the percentage of light reflected from the planet surface back into the atmosphere",
        default=25.0,
        min=1.0, max=100.0,
        subtype='PERCENTAGE',
        precision=2,
        step=10
    )


class _EnvironmentLayer:
    map = StringProperty(
        name="Map",
        description="Select the MXI/HDR/EXR map",
        subtype='FILE_PATH'
    )
    intensity = FloatProperty(
        name="Intensity",
        description="Adjust the intensity of the map",
        default=1.0,
        min=0.0, max=1000.0,
        precision=3,
        step=1000,
        subtype='UNSIGNED'
    )
    scale = FloatVectorProperty(
        name="Scale",
        description="Scale the map",
        size=2,
        default=(1.0, 1.0),
        min=-1000.0, max=1000.0,
        precision=4,
        step=1000
    )
    offset = FloatVectorProperty(
        name="Offset",
        description="Rotate the spherical environment in the X and Y axis",
        size=2,
        default=(0.0, 0.0),
        min=-360.0, max=360.0,
        precision=3,
        step=1000,
    )


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_layer(_EnvironmentLayer, PropertyGroup):
    type = EnumProperty(
        name="Type",
        items=[
            ('0', "Disabled", ""),
            ('1', "HDR Image", ""),
            ('2', "Active Sky", ""),
            ('3', "Same as Background", "The same map and settings will be used as for the Background channel"),
        ],
        default='3'
    )


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_background_layer(_EnvironmentLayer, PropertyGroup):
    type = EnumProperty(
        name="Type",
        items=[
            ('0', "Disabled", ""),
            ('1', "HDR Image", ""),
            ('2', "Active Sky", "")
        ],
        default='1'
    )


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_ibl(PropertyGroup):
    intensity = FloatProperty(
        name="Intensity",
        default=1.0,
        min=0.0, max=1000000.0,
        precision=1,
        step=1
    )
    interpolation = BoolProperty(
        name="Interpolation",
        description="This option can be useful when you have a low resolution HDR map "
                    "and see pixelisation in the HDR map when it is seen in the background"
    )
    screen_mapping = BoolProperty(
        name="Screen Mapping",
        description="Screen mapping can be used to map the MXI/HDR/EXR image to screen coordinates"
    )
    background = PointerProperty(
        type=MAXWELL_ENVIRONMENT_background_layer
    )
    reflection = PointerProperty(
        type=MAXWELL_ENVIRONMENT_layer
    )
    refraction = PointerProperty(
        type=MAXWELL_ENVIRONMENT_layer
    )
    illumination = PointerProperty(
        type=MAXWELL_ENVIRONMENT_layer
    )


@MaxwellRenderEngine.register_class
class MAXWELL_environment(PropertyGroup):
    type = EnumProperty(
        name="Environment",
        items=[
            #('NONE', "None", "No Environment lighting will be used"),
            ('SKY', "Sun & Sky", "An sky model will be created"),
            ('IBL', "Image Based Lighting", "Image Based Lighting allows you to light your scene by applying an HDR image to a virtual sphere that encompasses your scene")
        ],
        default='SKY'
    )
    sky_type = EnumProperty(
        name="Sky Type",
        items=[
            ('PHYSICAL', "Physical Sky", "Atmosphere model that reproduce the skylight at different locations/times/dates"),
            ('CONSTANT', "Constant Dome", "Create a consistent color or gradient dome for lighting your scene")
        ],
        default='PHYSICAL'
    )
    constant = PointerProperty(
        type=MAXWELL_ENVIRONMENT_constant_sky
    )
    physical = PointerProperty(
        type=MAXWELL_ENVIRONMENT_physical_sky
    )
    sun = PointerProperty(
        type=MAXWELL_ENVIRONMENT_sun
    )
    ibl = PointerProperty(
        type=MAXWELL_ENVIRONMENT_ibl
    )

    @classmethod
    def register(cls):
        World.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregister(cls):
        del World.maxwell

#endregion


#############################
#region Camera

@MaxwellRenderEngine.register_class
class MAXWELL_camera_latlong_stereo(PropertyGroup):
    type = EnumProperty(
        name="Type",
        items=[
            ('CENTER', "Center", "Center"),
            ('LEFT', "Left", "Left"),
            ('RIGHT', "Right", "Right")
        ],
        default='CENTER'
    )
    fov_vertical = FloatProperty(
        name="FOV Vertical",
        min=0.0, max=180.0,
        precision=1,
        default=180.0
    )
    fov_horizontal = FloatProperty(
        name="FOV Horizontal",
        min=0.0, max=360.0,
        precision=1,
        default=360.0
    )
    flip_ray_x = BoolProperty(
        name="Flip Ray X"
    )
    flip_ray_y = BoolProperty(
        name="Flip Ray Y"
    )
    parallax = FloatProperty(
        name="Parallax Distance",
        min=0.0, max=100000.0,
        precision=3,
        default=360.0
    )
    zenith = BoolProperty(
        name="Zenith Mode"
    )
    separation = FloatProperty(
        name="Separation",
        min=0.0, max=1000000.0,
        precision=3,
        default=6.5
    )
    separation_map = StringProperty(
        name="Separation Map"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_camera_fish_stereo(PropertyGroup):
    type = EnumProperty(
        name="Type",
        items=[
            ('CENTER', "Center", "Center"),
            ('LEFT', "Left", "Left"),
            ('RIGHT', "Right", "Right")
        ],
        default='CENTER'
    )
    fov = FloatProperty(
        name="FOV",
        min=0.0, max=360.0,
        precision=1,
        default=180.0
    )
    separation = FloatProperty(
        name="Separation",
        min=0.0, max=1000000.0,
        precision=3,
        default=6.5
    )
    separation_map = StringProperty(
        name="Separation Map",
        description="Separation Map"
    )
    dome_tilt_compensation = BoolProperty(
        name="Dome Tilt Compensation"
    )
    dome_tilt = FloatProperty(
        name="Dome Tilt",
        min=0.0, max=90.0,
        precision=1
    )
    vertical = BoolProperty(
        name="Vertical Mode"
    )
    dom_radius = FloatProperty(
        name="Dome Radius",
        min=1.0, max=1000000.0,
        precision=3,
        default=3600.0
    )
    turn_map = StringProperty(
        name="Head Turn Map"
    )
    tilt_map = StringProperty(
        name="Head Tilt Map"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_camera(PropertyGroup):
    exposure = IntProperty(
        name="Exposure Preset"
    )
    persp_lens = EnumProperty(
        name="Lens Type",
        description="Perspective Lens",
        items=[
            ('THIN', "Thin", "Thin Lens"),
            ('PIN_HOLE', "Pin Hole", "Pin Hole Lens"),
        ],
        default='THIN'
    )
    pano_lens = EnumProperty(
        name="Lens Type",
        description="Panoramic Lens Type",
        items=[
            ('FISH_EYE', "Fish Eye", "Fish Eye lens"),
            ('SPHERICAL', "Spherical", "Spherical lens"),
            ('CYLINDRICAL', "Cylindrical", "Cylindrical lens"),
            ('LATLONG_STEREO', "Lat-Long Stereo", "Lat-Long Stereo lens"),
            ('FISH_STEREO', "Fish Stereo", "Fish Stereo lens")
        ]
    )
    shutter_type = EnumProperty(
        name="Shutter Units",
        items=[
            ('SPEED', "Speed (1/s)", ""),
            ('ANGLE', "Angle (°)", "")],
        default='SPEED',
        update=lambda s, c: setattr(s, 'exposure', 0) if s.shutter_type == 'ANGLE' else None
    )
    shutter = FloatProperty(
        name="Shutter Speed",
        default=500.0,
        min=0.01, max=16000.0,
        precision=3,
        step=100.0,
        update=lambda s, c: setattr(s, "exposure", 0)
    )
    rotary = FloatProperty(
        name="Shutter Angle",
        default=180.0,
        min=0.01, max=5000.0,
        precision=3,
        step=100.0
    )
    iso = FloatProperty(
        name="ISO",
        default=100.0,
        precision=0,
        min=1.0, max=16000.0,
        step=100,
        update=lambda s, c: setattr(s, 'exposure', 0)
    )
    fstop = FloatProperty(
        name="f-Stop",
        default=8.0,
        min=1.0, max=100000.0,
        precision=3,
        step=100.0,
        update=lambda s, c: setattr(s, "exposure", 0)
    )
    # Diaphragm
    diaphragm = EnumProperty(
        name="Aperture",
        description="Controls the shape of the 'bokeh' effect",
        items=[
            ('CIRCULAR', "Circular", ""),
            ('POLYGONAL', "Polygonal", "")],
        default='CIRCULAR'
    )
    blades = IntProperty(
        name="Blades",
        description="Numbers of blades in the Polygonal diaphragm",
        default=6,
        min=3, max=96
    )
    angle = IntProperty(
        name="Angle",
        description="Rotation angle of aperture opening",
        default=60,
        min=0, max=720,
        subtype='UNSIGNED'
    )
    custom_bokeh = BoolProperty(
        name="Custom Bokeh"
    )
    bokeh_ratio = FloatProperty(
        name="Ratio",
        default=1.0,
        min=0.0, max=10000.0,
        precision=2,
        step=10.0
    )
    bokeh_angle = FloatProperty(
        name="Angle (°)",
        default=0.0,
        min=0.0, max=20520.0,
        precision=1,
        step=10.0
    )
    # TODO: it's needed???
    correction = BoolProperty(
        name="Focal Length Correction",
        description="Focal Length Need Correction",
        default=True
    )
    response = StringProperty(
        name="Response Preset",
        default="Maxwell"
    )
    aperture = FloatProperty(
        name="Aperture",
        unit='ROTATION',
        min=0.0, max=_PI * 2,
        default=_PI,
        precision=2
    )
    # Extensions
    latlong_stereo = PointerProperty(
        type=MAXWELL_camera_latlong_stereo
    )
    fish_stereo = PointerProperty(
        type=MAXWELL_camera_fish_stereo
    )
    # UI
    ui_diaphragm = BoolProperty(
        default=True
    )

    @classmethod
    def register(cls):
        Camera.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Camera.maxwell

#endregion


#############################
#region Extensions


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_vdb_uv_grid(PropertyGroup):
    grid = StringProperty(
        name="UV Grid",
        default="density"
    )
    type = EnumProperty(
        name="Data Type",
        items=[
            #('PLANAR', "Planar", "Planar"),
            #('SPHERICAL', "Spherical", "Spherical"),
            #('CYLINDRICAL', "Cylindrical", "Cylindrical"),
            #('CUBIC', "Cubic", "Cubic"),
            ('VDB_FLOAT', "Float", "Float", 40),
            ('VDB_VEC_MOD', "Vector", "Vector", 50),
            ('VDB_VEC_VX_VY', "Vector XY", "Vector XY", 60),
            ('VDB_VEC_VX_VZ', "Vector XZ", "Vector XZ", 70),
            ('VDB_VEC_VY_VZ', "Vector YZ", "Vector YZ", 80),
        ],
        default='VDB_FLOAT'
    )
    range = FloatVectorProperty(
        name="Range",
        default=(0.0, 1.0),
        min=-1000000.0, max=1000000.0,
        precision=6,
        size=2
    )


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_vdb_grid(PropertyGroup):
    base_grid = StringProperty(
        name="Base Grid",
        default="density"
    )
    multiplier = FloatProperty(
        name="Base grid Multiplier",
        min=0.0, max=10000000000.0,
        default=1.0
    )
    material = StringProperty(
        name="Material"
    )
    uv_grids = CollectionProperty(
        type=MAXWELL_EXTENSION_vdb_uv_grid
    )
    active_uv_grid_index = IntProperty()
    # UI
    ui_uv_grids = BoolProperty(
        default=True
    )

    def to_maxwell(self):
        uvgen = []
        params = {
            'Create Constant Density': 3,  # Volume file based
            'PrimaryField': self.base_grid,
            'VDBMultiplier': self.multiplier,
            'VDBAxis': 2
        }
        uv_grids = self.uv_grids
        if uv_grids:
            counts = {
                'VDB_FLOAT': 0,
                'VDB_VEC_MOD': 0,
                'VDB_VEC_VX_VY': 0,
                'VDB_VEC_VX_VZ': 0,
                'VDB_VEC_VY_VZ': 0,
            }
            f = 0
            v = 0
            uvgrids = []
            for g in uv_grids:
                t = g.type
                i = counts[t]
                counts[t] = i + 1
                uvgen.append(g.get('type', 40) + i)
                if g.type == 'VDB_FLOAT':
                    params["Min_vdbFloat_%d" % f] = g.range[0]
                    params["Max_vdbFloat_%d" % f] = g.range[1]
                    f += 1
                else:
                    params["Min_vdbVector_%d" % v] = g.range[0]
                    params["Max_vdbVector_%d" % v] = g.range[1]
                    v += 1
                uvgrids.append(g.name)
            params['SecondaryUVFields'] = ",".join(uvgrids)
        return uvgen, params


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_volumetric(PropertyGroup):
    enabled = BoolProperty(
        name="Enabled",
        description="Apply Maxwell Volumetric extension"
    )
    hide_emitter = BoolProperty(
        name="Hide emitter"
    )
    material = StringProperty(
        name = "Material"
    )
    field_type = EnumProperty(
        name="Field Type",
        items=[
            #('PARTICLE', "Particle based", "Particle based", 0),
            ('CONSTANT', "Constant", "Constant", 1),
            ('NOISE', "Noise 3D", "Noise 3D", 2),
            ('OPENVDB', "Open VDB", "Open VDB", 3)
        ],
        default='CONSTANT'
    )
    field_density = FloatProperty(
        name="Field Density",
        default=1.0,
        min=0.000001, max=10000.0,
        precision=6
    )
    # Noise 3D Field
    seed = IntProperty(
        name="Seed",
        default=4357,
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    low_value = FloatProperty(
        name="Low Value",
        min=0.0, max=1.0,
        precision=6
    )
    high_value = FloatProperty(
        name="High Value",
        default=1.0,
        min=0.0, max=1.0,
        precision=6
    )
    detail = FloatProperty(
        name="Detail",
        default=2.2,
        min=1.0, max=100.0,
        precision=4
    )
    octaves = IntProperty(
        name="Octaves",
        default=4,
        min=1, max=50,
        subtype='UNSIGNED'
    )
    persistence = FloatProperty(
        name="Persistence",
        default=0.55,
        min=0.0, max=1.0,
        precision=4
    )
    # Particles Field
    load_particles = FloatProperty(
        name="Load particles",
        default=100.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE'
    )
    radius_factor = FloatProperty(
        name="Radius Multiplier",
        default=1.0,
        min=0.000001, max=1000000.0,
        precision=6
    )
    density_scale = FloatProperty(
        name="Density Multiplier",
        default=1.0,
        min=0.000001, max=1000000.0,
        precision=6
    )
    min_density = FloatProperty(
        name="Min Density",
        description="Min Final Density",
        min=0.1, max=1.0,
        precision=6
    )
    max_density = FloatProperty(
        name="Max Density",
        description="Max Final Density",
        default=1.0,
        min=0.000001, max=10000.0,
        precision=6
    )
    cell_size = FloatProperty(
        name="Simulation Cell Size",
        default=0.1,
        min=0.000001, max=10000.0,
        precision=6
    )
    extra_particles = IntProperty(
        name="Extra Particles",
        description="Extra Particles Per Particle",
        min=0, max=1000000,
        subtype='UNSIGNED'
    )
    extra_dispersion = FloatProperty(
        name="Dispersion",
        description="Extra Particles Dispersion",
        default=1.0,
        min=0.0, max=1000000.0
    )
    extra_deformation = FloatProperty(
        name="Deformation",
        description="Extra Particles Deformation",
        min=0.0, max=1000000.0
    )
    motion_blur_factor = FloatProperty(
        name="Motion Blur Multiplier",
        default=1.0,
        min=0.0, max=1000000.0,
        precision=6
    )
    shutter_speed = FloatProperty(
        name="Shutter Speed",
        default=125.0,
        min=0.000001, max=1000000.0
    )
    # VDB (Empty)
    vdb_file = StringProperty(
        name="File (.vdb)",
        subtype='FILE_PATH'
    )
    vdb_grid = PointerProperty(
        type=MAXWELL_EXTENSION_vdb_grid
    )
    vdb_axis = EnumProperty(
        name="Source Axis",
        items=_AXIS,
        default='YZX'
    )
    # VDB (Smoke Domain)
    vdb_grids = CollectionProperty(
        type=MAXWELL_EXTENSION_vdb_grid
    )
    active_vdb_grid_index = IntProperty(
        name="Active Grid"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_sea(PropertyGroup):
    _quality_items=[
        ('0', "4x4", "4x4", 0),
        ('1', "8x8", "8x8", 1),
        ('2', "16x16", "16x16", 2),
        ('3', "32x32", "32x32", 3),
        ('4', "64x64", "64x64", 4),
        ('5', "128x128", "128x128", 5),
        ('6', "256x256", "256x256", 6),
        ('7', "512x512", "512x512", 7),
        ('8', "1024x1024", "1024x1024", 8),
        ('9', "2048x2048", "2048x2048", 9),
        ('10', "4096x4096", "4096x4096", 10),
        ('11', "8192x8192", "8192x8192", 11)
    ]

    enabled = BoolProperty(
        name="Enabled",
        description="Export mesh as Maxwell Sea"
    )
    # Geometry
    material = StringProperty(
        name = "Material"
    )
    quality = EnumProperty(
        name="Quality",
        items=_quality_items,
        default='6',
        options=set()
    )
    time = FloatProperty(
        name="Reference Time",
        min=0.0, max=100000.0,
        precision=4
    )
    vertical_scale = FloatProperty(
        name="Vertical Scale",
        min=0.0, max=100000.0,
        default=0.1,
        precision=5,
    )
    dimension = FloatProperty(
        name="Dimension",
        min=0.0, max=1000000.0,
        default=250.0,
        precision=2
    )
    depth = FloatProperty(
        name="Depth",
        min=0.0, max=100000.0,
        default=250.0,
        precision=2
    )
    seed = IntProperty(
        name="Seed",
        subtype='UNSIGNED',
        min=0, max=65535,
        default=4217
    )
    choppyness = BoolProperty(
        name="Choppyness"
    )
    choppy_factor = FloatProperty(
        name="Choppy Factor",
        min=0.0, max=100000.0,
        precision=2
    )
    repeat_u = IntProperty(
        name="Repeat U",
        min=1, max=1000000,
        default=1
    )
    repeat_v = IntProperty(
        name="Repeat V",
        min=1, max=1000000,
        default=1
    )
    # Wind
    wind_speed = FloatProperty(
        name="Wind Speed",
        min=0.0, max=100000.0,
        default=30.0,
        precision=3
    )
    wind_direction = FloatProperty(
        name="Wind Direction",
        min=0.0, max=360.0,
        default=45.0,
        precision=1
    )
    weight_against_wind = FloatProperty(
        name="Weight Against Wind",
        min=0.0, max=1.0,
        default=0.5,
        precision=4
    )
    wind_alignment = FloatProperty(
        name="Wind Alignment",
        min=0.0, max=100000.0,
        default=2.0,
        precision=4
    )
    min_wave_length = FloatProperty(
        name="Min Wave Length",
        min=0.0, max=100000,
        default=0.1,
        precision=4
    )
    # Bake to Mesh Cache file
    def _get_mc_file(self):
        f = self.get("_mc")
        if f is None:
            f = "//" + self.id_data.name + ".pc2"
        return f

    def _set_mc_file(self, value):
        self["_mc"] = value

    mc_modifier = StringProperty(
        name="Modifier",
        description="Mesh Cache modifier name",
        default="Maxwell Sea"
    )
    mc_file = StringProperty(
        name="Cache File (.pc2)",
        description="Mesh Cache File (*.pc2)",
        subtype='FILE_PATH',
        get=_get_mc_file,
        set=_set_mc_file
    )
    mc_quality = EnumProperty(
        name="Quality",
        items=_quality_items,
        default='4',
        options=set()
    )
    mc_frames = IntVectorProperty(
        name="Frames",
        size=2,
        default=(1, 2),
        options=set()
    )
    # UI
    ui_geometry = BoolProperty(
        default=True
    )
    ui_wind = BoolProperty()
    ui_mesh_cache = BoolProperty()


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_hair(PropertyGroup):
    root = FloatProperty(
        name="Root Radius",
        default=0.005,
        min=0.0,
        precision=3,
        step=0.1
    )
    tip = FloatProperty(
        name="Tip Radius",
        default=0.001,
        min=0.0,
        precision=3,
        step=0.1
    )
    uv_map = StringProperty(
        name="UV Channel 1",
        description="UV Map for 'Channel 1'"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_grass(PropertyGroup):
    # Primitive
    type = EnumProperty(
        name="Type",
        description="Primitive Type",
        items=[
            ('0', "Curve", "The Curve primitive renders a smooth curved blade of grass"),
            ('1', "Flat", "The Flat primitive renders a segmented flat strip"),
            ('2', "Cylinder", "The Cylinder primitive renders each guide as a rounded cylinder")],
        default='0'
    )
    backface = StringProperty(
        name="Backface Material"
    )
    blade_points = IntProperty(
        name="Points Per Blade",
        description="Sets the number of points to use for the primitive you have chosen",
        default=4,
        min=2, max=20,
        soft_min=2, soft_max=20,
        subtype='UNSIGNED'
    )
    # Grass Density
    density = IntProperty(
        name="Density",
        description="Controls the number of blades per square meter",
        default=100,
        min=0, max=100000000,
        soft_min=0, soft_max=100000,
        subtype='UNSIGNED'
    )
    density_map = StringProperty(
        name="Density Map",
        description="Specify a greyscale map to control where the grass will grow"
    )
    seed = IntProperty(
        name="Seed",
        description="This number is used to generate the random distribution of the grass blades",
        min=0, max=16300,
        soft_min=0, soft_max=16300,
        subtype='UNSIGNED'
    )
    # Blade Length
    length = FloatProperty(
        name="Length",
        description="The length of the blades in centimeters",
        default=10.0,
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0,
        precision=3
    )
    length_map = StringProperty(
        name="Length Map",
        description="Load a greyscale map to control the height of the grass over its growth area"
    )
    length_var = FloatProperty(
        name="Length Variation",
        description="Randomize the length of each blade, specifying the range of possible length values "
                    "as a percentage of the nominal Length parameter",
        default=20.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    # Width
    root_width = FloatProperty(
        name="Root Width",
        description="Specify the width (or radius, in the cylindrical grass) in millimeters of each blade at its root",
        default=5.0,
        min=0.1, max=100000.0,
        soft_min=0.1, soft_max=100000.0,
        precision=3
    )
    tip_width = FloatProperty(
        name="Tip Width",
        description="Specify the width (or radius, in the cylindrical grass) in millimeters of each blade at its tip",
        default=1.0,
        min=0.1, max=100000.0,
        soft_min=0.1, soft_max=100000.0,
        precision=3
    )
    # Angle
    direction = EnumProperty(
        name="Direction",
        items=[
            ('0', "Polygon Normal", "", 0),
            ('1', "World-Y", "", 1)
        ],
        default='0'
    )
    angle = FloatProperty(
        name="Initial Angle",
        description="The initial angle at which the blades will grow",
        default=80.0,
        min=0.0, max=90.0,
        soft_min=0.0, soft_max=90.0,
        precision=1
    )
    angle_map = StringProperty(
        name="Initial Angle Map",
        description="You can use an RGB map which will define the initial angle"
    )
    angle_var = FloatProperty(
        name="Initial Angle Variation",
        description="Randomize the growth angle by a percentage of the initial angle variation",
        default=25.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    # Bend
    start_bend = FloatProperty(
        name="Start Bend",
        description="The length of the blade (in percentage) at which the blade starts bending",
        default=40.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    start_bend_map = StringProperty(
        name="Start Bend Map",
        description="Load a greyscale map to control the Start Bend values"
    )
    start_bend_var = FloatProperty(
        name="Start Bend Variation",
        description="Randomize the Start Bend parameter of each blade",
        default=25.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    bend_radius = FloatProperty(
        name="Bend Radius",
        description="The radius in centimeters of the bending",
        default=10.0,
        min=0.0, max=10000.0,
        soft_min=0.0, soft_max=10000.0,
        precision=1
    )
    bend_radius_map = StringProperty(
        name="Bend Radius Map",
        description="Load a greyscale map to control the Bend Radius of the grass across its growth area"
    )
    bend_radius_var = FloatProperty(
        name="Bend Radius Variation",
        description="Randomize the bending radius of each blade",
        default=25.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    bend_angle = FloatProperty(
        name="Bend Angle",
        description="The bending angle in degrees",
        default=80.0,
        min=0.0, max=360.0,
        soft_min=0.0, soft_max=360.0,
        precision=1
    )
    bend_angle_map = StringProperty(
        name="Bend Angle Map",
        description="Load a greyscale map to control the Bend Angle at different areas of its growth surface"
    )
    bend_angle_var = FloatProperty(
        name="Bend Angle Variation",
        description="Randomize the Bend Angle parameter",
        default=25.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    # Cut off
    cut_off = FloatProperty(
        name="Cut Off",
        description="The length of the blade (in percentage) at which the blade will be cut",
        default=100.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    cut_off_map = StringProperty(
        name="Cut Off Map",
        description="Load a greyscale map to control different Cut Off values "
                    "at different areas of the growing surface"
    )
    cut_off_var = FloatProperty(
        name="Cut Off Variation",
        description="Randomize the cut length parameter of each blade",
        default=0.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    # Level of Detail
    lod_enabled = BoolProperty(
        name="Enable LOD",
        description="This option allows you to optimize your scene by rendering more blades near the camera "
                    "and gradually less blades as the distance from the camera increases"
    )
    lod_min = FloatProperty(
        name="Min Distance",
        description="The distance from the camera where the LOD won't have any effect",
        default=10.0,
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0
    )
    lod_max = FloatProperty(
        name="Max Distance",
        description="The distance at which the blade density will have reached the density "
                    "specified in the Max Distance Density parameter",
        default=50.0,
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0
    )
    lod_max_density = FloatProperty(
        name="Max Distance Density",
        description="The number of blades per meter you wish to have when the Max Distance is reached",
        default=10.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        subtype='PERCENTAGE'
    )
    # Display
    display_percent = IntProperty(
        name="Display Percent",
        description="The percentage of blades to show in the Maxwell Studio viewport",
        default=10,
        min=0, max=100,
        soft_min=0, soft_max=100,
        subtype='PERCENTAGE'
    )
    display_blades = IntProperty(
        name="Display Max. Blades",
        description="The maximum number of blades to display in the Maxwell Studio viewport",
        default=1000,
        min=0, max=100000,
        soft_min=0, soft_max=100000
    )


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_mesher(PropertyGroup):
    # Globals
    mesher = EnumProperty(
        name="Mesh Generator",
        items=[
            ('0', 'RFRKMesh', "", 0),
            ('1', 'HybridoMesh', "", 1)
        ],
        default='0'
    )
    # Sequence
    radius = FloatProperty(
        name="Particle Radius",
        default=0.08,
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0,
        precision=2,
        step=1.0
    )
    core = FloatProperty(
        name="Core filter",
        default=0.0,
        min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0,
        precision=2,
        step=1.0
    )
    splash = FloatProperty(
        name="Splash filter",
        default=0.0,
        min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0,
        precision=2,
        step=1.0
    )
    velocity = FloatProperty(
        name="Max. Velocity",
        default=1000.0,
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0,
        precision=2,
        step=1000.0
    )
    # Mesh parameters
    poly = FloatProperty(
        name="Polygon Size",
        default=0.05,
        min=0.0, max=1000.0,
        soft_min=0.0, soft_max=1000.0,
        precision=2,
        step=1.0
    )
    wn = BoolProperty(
        name="Weight Normalization"
    )
    smooth = FloatProperty(
        name="Smooth",
        default=50.0,
        min=0.0, max=100.0,
        soft_min=0.0, soft_max=100.0,
        precision=2,
        step=100.0
    )
    iso_level = FloatProperty(
        name="Iso Level",
        default=0.0,
        min=-10.0, max=10.0,
        soft_min=-10.0, soft_max=10.0,
        precision=2,
        step=100.0
    )
    fix_bbox = BoolProperty(
        name="Fix Bounding Box",
        default=True
    )
    field_type = EnumProperty(
        name="Field Type",
        items=[
            ('0', "Metaball", "Metaball", 0),
            ('1', "Sphere", "Sphere", 1),
            # TODO: error raised when set it 2, and docs says that 1 is Sphere
            # http://support.nextlimit.com/display/mxdocsv3/Maxwell+Mesher#MaxwellMesher-FieldType
            #('1', "Weighted_Isotropic", "Weighted_Isotropic", 1),
            #('2', "Weighted_Anisotropic", "Weighted_Anisotropic", 2)
        ],
        default='1'
    )
    # Mesh filtering
    filter = BoolProperty(
        name="Enable Mesh Filter"
    )
    relax = FloatProperty(
        name="Relax",
        default=0.0,
        min=0.0, max=1000.0,
        soft_min=0.0, soft_max=1000.0,
        precision=2,
        step=10.0
    )
    tension = FloatProperty(
        name="Tension",
        default=0.0,
        min=0.0, max=1000.0,
        soft_min=0.0, soft_max=1000.0,
        precision=2,
        step=10.0
    )
    thinning = FloatProperty(
        name="Thinning",
        default=0.0,
        min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0,
        precision=2,
        step=1
    )
    steps = IntProperty(
        name="Steps",
        default=1,
        min=0, max=1000,
        soft_min=0, soft_max=1000,
        subtype='UNSIGNED'
    )
    splash_thinning = BoolProperty(
        name="Splash Thinning",
        default=True,
    )
    splash_threshold = FloatProperty(
        name="Splash Threshold",
        default=0.8,
        min=0.0, max=0.1,
        soft_min=0.0, soft_max=0.1
    )
    thinning_size = FloatProperty(
        name="Thinning Size",
        default=0.5,
        min=0.0, max=1.0,
        soft_min=0.0, soft_max=1.0
    )
    core_smooth = BoolProperty(
        name="Core Smoothing",
        default=True
    )
    core_threshold = FloatProperty(
        name="Core Threshold",
        default=0.4,
        min=0.0, max=1.0
    )
    smooth_steps = IntProperty(
        name="Smoothing Steps",
        default=128,
        min=0, max=1000,
        subtype='UNSIGNED'
    )
    # Mesh Optimization
    optimize = EnumProperty(
        name="Optimization",
        items=[
            ('0', "Disabled", "Disables the optimization process", 0),
            ('1', "Camera", "Camera", 1),
            ('2', "Curvature", "Curvature", 2),
        ],
        default='0'
    )
    distance = FloatProperty(
        name="Camera Distance",
        default=5.0,
        min=0.0, max=1000.0,
        soft_min=0.0, soft_max=1000000.0,
        precision=2,
        step=1000.0
    )
    # System parameters
    threads = IntProperty(
        name="Threads",
        default=0,
        min=0, max=1000,
        soft_min=0, soft_max=1000,
        subtype='UNSIGNED'
    )
    # Export and lazy compute
    action = EnumProperty(
        name="Action",
        items=[
            ('0', "Do Meshing", "Do Meshing", 0),
            ('1', "Do Meshing and Export", "Do Meshing and Export", 1),
            ('2', "Import Mesh", "Import Mesh", 2)
        ],
        default='0'
    )
    md_file = StringProperty(
        name="MD File",
        subtype='FILE_PATH'
    )
    md_offset = IntProperty(
        name="Frame Offset",
        default=0,
        min=-10000, max=10000,
        soft_min=-10000, soft_max=10000
    )
    md_compression = IntProperty(
        name="File Compression",
        min=0, max=9
    )
    md_normals = BoolProperty(
        name="Invert Normals"
    )
    # UI
    ui_sequence = BoolProperty(
        default=True
    )
    ui_optimization = BoolProperty()
    ui_params = BoolProperty()
    ui_filter = BoolProperty()
    ui_export = BoolProperty()


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_particles(PropertyGroup):
    radius = FloatProperty(
        name="Radius Multiplier",
        default=1.0,
        min=0.000001, max=1000000.0,
        soft_min=0.000001, soft_max=100.0,
        precision=6,
        step=0.001
    )
    motion_blur = FloatProperty(
        name="Motion Blur Multiplier",
        default=1.0,
        min=0.0, max=1000000.0,
        soft_min=0.0, soft_max=100.0,
        precision=6,
        step=0.001
    )
    shutter_speed = FloatProperty(
        name="Shutter Speed",
        default=125.0,
        min=0.000001, max=1000000.0,
        soft_min=0.000001, soft_max=100.0,
        precision=2,
        step=100.0
    )
    extra_particles = IntProperty(
        name="Extra Particles",
        description="Extra particles per particle",
        default=0,
        min=0, max=100000000,
        soft_min=0, soft_max=10000,
        step=1
    )
    extra_dispersion = FloatProperty(
        name="Dispersion",
        description="Extra particles dispersion",
        default=0.0,
        min=0.0, max=1000000.0,
        soft_min=0.0, soft_max=100.0,
        precision=2,
        step=10.0,
    )
    extra_deformation = FloatProperty(
        name="Deformation",
        description="Extra particles deformation",
        default=0.0,
        min=0.0, max=1000000.0,
        soft_min=0.0, soft_max=100.0,
        precision=2,
        step=10.0
    )


@MaxwellRenderEngine.register_class
class MAXWELL_EXTENSION_scatter(PropertyGroup):
    enabled = BoolProperty(
        name="Enabled",
        description="Use Maxwell Scatter Extension"
    )
    inherit_oid = BoolProperty(
        name="Inherit Object Id"
    )
    # Scatter Density
    density = FloatProperty(
        name="Density",
        description="Density",
        default=100.0,
        min=0.0, max=100000000.0,
        soft_min=0.0, soft_max=100000.0,
        subtype='UNSIGNED'
    )
    density_map = StringProperty(
        name="Density Map",
        description="Density Map"
    )
    remove_overlaps = BoolProperty(
        name="Remove Overlaps"
    )
    seed = IntProperty(
        name="Seed",
        description="This number is used to generate the random distribution of the grass blades",
        min=0, max=16300,
        subtype='UNSIGNED'
    )
    # Scale
    scale = FloatVectorProperty(
        name="Scale",
        description="Scale",
        default=(1.0, 1.0, 1.0),
        min=0.0, max=100000.0,
        step=10, precision=4,
        subtype='XYZ', unit='LENGTH'
    )
    scale_map = StringProperty(
        name="Scale Map"
    )
    scale_var = FloatVectorProperty(
        name="Scale Variation",
        description="Scale variation",
        default=(20.0, 20.0, 20.0),
        min=0.0, max=100.0,
        step=10, precision=4,
        subtype='XYZ'
    )
    uniform_scale = BoolProperty(
        name="Uniform Scale"
    )
    # Rotation
    rotation = FloatVectorProperty(
        name="Rotation",
        description="Rotation",
        default=(0.0, 0.0, 0.0),
        min=0.0, max=360.0,
        step=100, precision=4,
        subtype='XYZ'
    )
    rotation_map = StringProperty(
        name="Rotation Map"
    )
    rotation_var = FloatVectorProperty(
        name="Rotation Variation",
        description="Rotation variation",
        default=(10.0, 10.0, 10.0),
        min=0.0, max=100.0,
        step=10, precision=4,
        subtype='XYZ'
    )
    direction = FloatProperty(
        name="Grow Towards World-Y",
        min=0.0, max=100.0,
        precision=1,
        subtype='PERCENTAGE'
    )
    # not used
    angle = FloatProperty(
        name="Initial Angle",
        description="The initial angle at which the blades will grow",
        default=80.0,
        min=0.0, max=90.0,
        precision=1
    )
    angle_var = FloatProperty(
        name="Initial Angle Variation",
        description="Randomize the growth angle by a percentage of the initial angle variation",
        default=25.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE',
        precision=1
    )
    angle_map = StringProperty(
        name="Initial Angle Map",
        description="You can use an RGB map which will define the initial angle"
    )


@MaxwellRenderEngine.register_class
class MAXWELL_particle_settings(PropertyGroup):
    h_type = EnumProperty(
        name="Type",
        items=[
            ('HAIR', "Hair", "Use Maxwell Hair Extension"),
            ('GRASS', "Grass", "Use Maxwell Grass Extension")
        ],
        default='HAIR'
    )
    p_type = EnumProperty(
        name="Type",
        items=[
            ('MESHER', "Mesher", "Use Maxwell Mesher Extension"),
            ('PARTICLES', "Particles", "Use Maxwell Particles Extension"),
            ('VOLUMETRIC', "Volumetric", "Use Maxwell Volumetric Extension")
        ],
        default='PARTICLES'
    )
    hair = PointerProperty(
        type=MAXWELL_EXTENSION_hair
    )
    grass = PointerProperty(
        type=MAXWELL_EXTENSION_grass
    )
    mesher = PointerProperty(
        type=MAXWELL_EXTENSION_mesher
    )
    particles = PointerProperty(
        type=MAXWELL_EXTENSION_particles
    )
    volumetric = PointerProperty(
        type=MAXWELL_EXTENSION_volumetric
    )
    scatter = PointerProperty(
        type=MAXWELL_EXTENSION_scatter
    )
    binfile = StringProperty(
        name="Path",
        subtype='FILE_PATH',
        default="//"
    )
    use_binfile = BoolProperty(
        name="Export to File (.bin)",
        description="Export the particle system data to Maxwell Render particles file (.bin)",
        default=True
    )
    overwrite_binfile = BoolProperty(
        name="Overwrite",
        default=True
    )
    # UI
    ui_binfile = BoolProperty(
        default=True,
        options=set()
    )

    @classmethod
    def register(cls):
        ParticleSettings.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del ParticleSettings.maxwell

#endregion


#############################
#region Object

@MaxwellRenderEngine.register_class
class MAXWELL_OBJECT_reference(PropertyGroup):
    material = StringProperty(
        name="Material"
    )
    path = StringProperty(
        name="File",
        description="Reference file path",
        subtype='FILE_PATH'
    )
    flags = EnumProperty(
        name="Override Flags",
        items=[
            ('HIDE', "Hidden", "Hide", 1),
            ('CAMERA', "Hidden from Camera", "Hidden from camera", 2),
            ('REFL_REFR', "Hidden from Refl & Refr", "Hidden from reflection & refraction", 4),
            ('HIDE_TO_GI', "Hidden from Global illumination", "Hidden from global illumination", 8)
        ],
        options={
            'ANIMATABLE',
            'ENUM_FLAG'
        }
    )
    flag_hidden = BoolProperty(
        name="Hidden",
        get=lambda s: 'HIDE' in s.flags,
        set=lambda s, v: setattr(s, 'flags', s.flags | {'HIDE'} if v else s.flags - {'HIDE'})
    )
    flag_camera = BoolProperty(
        name="Camera",
        description="Hidden from Camera",
        get=lambda s: 'CAMERA' in s.flags,
        set=lambda s, v: setattr(s, 'flags', s.flags | {'CAMERA'} if v else s.flags - {'CAMERA'})
    )
    flag_rr = BoolProperty(
        name="Reflection & Refraction",
        description="Hidden from Reflection & Refraction",
        get=lambda s: 'REFL_REFR' in s.flags,
        set=lambda s, v: setattr(s, 'flags', s.flags | {'REFL_REFR'} if v else s.flags - {'REFL_REFR'})
    )
    flag_gi = BoolProperty(
        name="Global illumination",
        description="Hidden from Global illumination",
        get=lambda s: 'HIDE_TO_GI' in s.flags,
        set=lambda s, v: setattr(s, 'flags', s.flags | {'HIDE_TO_GI'} if v else s.flags - {'HIDE_TO_GI'})
    )
    # asset reference
    axis = EnumProperty(
        name="Source Axis",
        items=_AXIS,
        default='YZX'
    )
    # UI
    ui_flags = BoolProperty(
        default=True
    )


@MaxwellRenderEngine.register_class
class MAXWELL_object(PropertyGroup):
    type = EnumProperty(
        name="Export As",
        items=[
            ('NONE', "None", "Doesn't export", 0),
            ('REFERENCE', "Reference", "Reference", 1),
            ('ASSET', "Asset Reference", "Asset Reference Extension", 3),
            ('VOLUMETRIC', "Volumetric", "Volumetric Extension", 2)
        ],
        default='NONE'
    )
    opacity = FloatProperty(
        name="Opacity",
        default=100.0,
        min=0.0, max=100.0,
        subtype='PERCENTAGE'
    )
    hide_to_camera = BoolProperty(
        name="Camera",
        description="Hide to Camera"
    )
    hide_to_camera_shadow = BoolProperty(
        name="Camera In Shadow Channel"
    )
    hide_to_refl_refr = BoolProperty(
        name="Reflections & Refractions",
        description="Hide to Reflections & Refractions"
    )
    hide_to_gi = BoolProperty(
        name="Global Illumination",
        description="Hide to Global Illumination"
    )
    ecp = BoolProperty(
        name="Excluded Of CutPlanes",
        description="Excluded Of CutPlanes"
    )
    color_id = FloatVectorProperty(
        name="Object ID",
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    backface_material = StringProperty(
        name="Backface Material"
    )
    custom_alphas = property(fget=lambda s: s.get('_custom_alphas', []))
    active_custom_alpha_index = IntProperty(
        options=set()
    )
    blocked_emitters = CollectionProperty(
        type=PropertyGroup
    )
    active_blocked_emitter_index = IntProperty(
        options=set()
    )

    reference = PointerProperty(
        type=MAXWELL_OBJECT_reference
    )
    volumetric = PointerProperty(
        type=MAXWELL_EXTENSION_volumetric
    )

    @classmethod
    def register(cls):
        Object.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Object.maxwell


@MaxwellRenderEngine.register_class
class MAXWELL_projection(PropertyGroup):
    _types = [
        ('PLANAR', "Planar", "Planar"),
        ('SPHERICAL', "Spherical", "Spherical"),
        ('CYLINDRICAL', "Cylindrical", "Cylindrical"),
        ('CUBIC', "Cubic", "Cubic"),
        ('LOCKED', "Locked", "Locked"),
    ]

    def _type_items(self, context):
        if hasattr(self.id_data, 'uv_layers'):
            return self._types
        return self._types[:-1]

    @property
    def type_label(self):
        return self._types[self.get('type', 0)][1]

    name = StringProperty(
        name="UV Map"
    )
    type = EnumProperty(
        name="Type",
        description="Projection type",
        items=_type_items
    )
    channel = IntProperty(
        name="Channel",
        min=0, max=254,
        options=set(),
        subtype='UNSIGNED'
    )
    object = StringProperty(
        name="Object",
        description="Object"
    )
    position = FloatVectorProperty(
        name="Position",
        description="Position",
        default=(0.0, 0.0, 0.0),
        precision=4,
        step=100,
        subtype='TRANSLATION'
    )
    rotation = FloatVectorProperty(
        name="Rotation",
        description="Rotation",
        default=(0.0, 0.0, 0.0),
        precision=4,
        step=100,
        subtype='EULER',
        unit='ROTATION'
    )
    scale = FloatVectorProperty(
        name="Scale",
        description="Scale",
        default=(1.0, 1.0, 1.0),
        precision=4,
        step=0.1,
        subtype='XYZ'
    )
    latitude = FloatVectorProperty(
        name="Latitude",
        size=2,
        default=(-90.0, 90.0),
        min=-90.0, max=90.0
    )
    longitude = FloatVectorProperty(
        name="Longitude",
        size=2,
        default=(-180.0, 180.0),
        min=-180.0, max=180.0,
    )
    angle = FloatVectorProperty(
        name="Perimeter",
        size=2,
        default=(-180.0, 180.0),
        min=-1000, max=1000
    )


@MaxwellRenderEngine.register_class
class MAXWELL_obdata(PropertyGroup):
    use_projections = BoolProperty(
        description="Use Maxwell Render UV Sets"
    )
    projections = CollectionProperty(
        type=MAXWELL_projection
    )
    active_projection_index = IntProperty(
        default=0,
        options=set()
    )
    # extensions
    sea = PointerProperty(
        type=MAXWELL_EXTENSION_sea
    )

    @classmethod
    def register(cls):
        Mesh.maxwell = PointerProperty(type=cls)
        Curve.maxwell = PointerProperty(type=cls)
        TextCurve.maxwell = PointerProperty(type=cls)
        MetaBall.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Mesh.maxwell
        del Curve.maxwell
        del TextCurve.maxwell
        del MetaBall.maxwell


@MaxwellRenderEngine.register_class
class MAXWELL_lamp(PropertyGroup):
    emitter = PointerProperty(
        type=MAXWELL_MATERIAL_emitter
    )

    @classmethod
    def register(cls):
        Lamp.maxwell = PointerProperty(type=cls)

    @classmethod
    def unregiser(cls):
        del Lamp.maxwell

#endregion
