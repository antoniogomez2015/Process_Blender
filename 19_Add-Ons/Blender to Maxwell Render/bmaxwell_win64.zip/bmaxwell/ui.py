# -*- coding: utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Ildar Nikolaev"
__email__ = "nildar@users.sourceforge.net"

import os
from fnmatch import fnmatchcase

import bpy
from bpy.types import Panel, Menu, UIList

from . import MaxwellRenderEngine
from . import BMaxwellPreferences
from .ops import MAXWELL_OT_visualizer

_ICONS = None
_ICON_MAXWELL_RENDER = 0

def register_icons():
    import bpy.utils.previews

    global _ICONS
    global _ICON_MAXWELL_RENDER

    icons = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    icons.load('MAXWELL_NORMAL_DISABLED', os.path.join(icons_dir, "normaldisabled.png"), 'IMAGE')
    icons.load('MAXWELL_NORMAL_ENABLED', os.path.join(icons_dir, "normalenabled.png"), 'IMAGE')
    _ICON_MAXWELL_RENDER = icons.load('MAXWELL_RENDER', os.path.join(icons_dir, "maxwell.png"), 'IMAGE').icon_id

    _ICONS = icons

def unregister_icons():
    global _ICONS

    bpy.utils.previews.remove(_ICONS)
    _ICONS = None

def _UiBox(layout, data, prop, text):
    value = getattr(data, prop)
    icon = 'TRIA_DOWN' if value else 'TRIA_RIGHT'
    col = layout.column(align=True)
    col.context_pointer_set('maxwell_ui', data)
    col.operator('maxwell.ui_toggle', text=text, icon=icon).attr = prop
    if value:
        return col.box()
    return None

def _UiSub(layout, data, prop, text):
    value = getattr(data, prop)
    icon = 'TRIA_DOWN' if value else 'TRIA_RIGHT'
    col = layout.column(align=True)
    col.context_pointer_set('maxwell_ui', data)
    col.operator('maxwell.ui_toggle', text=text, icon=icon).attr = prop
    if value:
        return col
    return None

def _draw_uvgrids(layout, grid):
    box = _UiBox(layout, grid, 'ui_uv_grids', "Additional grids for UV")
    if box is not None:
        col = box.column()
        row = col.row()
        row.template_list('UI_UL_list', 'MAXWELL_uv_grids', grid, 'uv_grids',
                            grid, 'active_uv_grid_index', rows=2)
        subcol = row.column(align=True)
        subcol.context_pointer_set('maxwell_vdb_grid', grid)
        subcol.operator('maxwell.vdb_uv_grids_add', icon='ZOOMIN', text="")
        subcol.operator('maxwell.vdb_uv_grids_remove', icon='ZOOMOUT', text="")

        uv_grids = grid.uv_grids
        i = grid.active_uv_grid_index
        if 0 <= i < len(uv_grids):
            uv_grid = uv_grids[i]
            row = col.row(align=True)
            row.prop(uv_grid, 'type', text="")
            row.prop(uv_grid, 'range', index=0, text="Min")
            row.prop(uv_grid, 'range', index=1, text="Max")

def _draw_emitter(layout, id_data, emitter):
    layout.prop(emitter, 'type', expand=True)

    if emitter.type == 'COLOR':
        split = layout.split(0.33)
        split.label("Color:")
        row = split.row(align=True)
        if emitter.use_temperature:
            row.prop(emitter, 'ui_temperature_color', text="")
            row.prop(emitter, 'use_temperature', text="")
        else:
            row.prop(emitter, 'color', text="")
            row.prop(emitter, 'use_temperature', text="")
            row = row.row(align=True)
            row.enabled = False
        row.prop(emitter, 'color_temp', text="K")

        col = layout.column()
        split = col.split(0.33)
        split.label("Lobe:")
        split.row().prop(emitter, 'lobe', expand=True)

        if emitter.lobe == 'IES':
            col.prop(emitter, 'ies')
            col.prop(emitter, 'intensity')
        else:
            if emitter.lobe == 'SPOT':
                spot = emitter.spot
                split = col.split(0.33)
                split.label("Map:")
                row = split.row(align=True)
                row.prop(spot, 'ui_map_enabled', text="")
                row.prop_search(spot, 'map', id_data, 'texture_slots', text="")
                col.prop(spot, 'cone_angle')
                col.prop(spot, 'falloff_angle')
                col.prop(spot, 'falloff_type')
                col.prop(spot, 'blur')
            col.prop(emitter, 'luminance')
            if emitter.luminance == 'POWER':
                col.prop(emitter, 'power')
                col.prop(emitter, 'efficacy')
            else:
                col.prop(emitter, 'output')
    elif emitter.type == 'TEMP':
        layout.prop(emitter, 'temperature')
    elif emitter.type == 'HDRI':
        col = layout.column()
        col.prop_search(emitter, 'hdri_map', id_data, 'texture_slots')
        col.prop(emitter, 'hdri_intensity')


class _MaxwellPanel:
    def draw_header(self, context):
        self.layout.label("", icon_value=_ICON_MAXWELL_RENDER)


@MaxwellRenderEngine.register_class
class MAXWELL_UL_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.prop(item, 'name', text="", emboss=False, icon_value=icon)
        layout.prop(item, 'enabled', text="")


@MaxwellRenderEngine.register_class
class MAXWELL_PT_visualization(_MaxwellPanel, Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_label = "Visualization"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return (
            MaxwellRenderEngine.is_active(context) and
            context.space_data is not None
        )

    def draw(self, context):
        layout = self.layout

        enabled = MAXWELL_OT_visualizer.is_enabled()
        text = "Disable Visualization" if enabled else "Enable Visualization"
        layout.operator('maxwell.visualization_enable', text=text)

        mx = context.scene.maxwell.visualization

        col = layout.column(align=True)
        col.label("Referenced objects:")
        col.prop(mx, 'ref_point_size')
        col.prop(mx, 'ref_color', text='')
        col = col.column(align=True)
        col.enabled = not enabled
        col.prop(mx, 'ref_percent')
        col.prop(mx, 'ref_points')

        col = layout.column(align=True)
        col.label("IES Emitters:")
        col.prop(mx, 'ies_point_size')
        col.prop(mx, 'ies_alpha')

        col = layout.column(align=True)
        col.label("OpenVDB:")
        col.prop(mx, 'vdb_color', text="")

        col = layout.column(align=True)
        col.label("Assets:")
        col.prop(mx, 'asset_color', text="")


#############################
#region Texture

from bl_ui.properties_texture import TextureButtonsPanel


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_PT_image(TextureButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Image"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            hasattr(context.texture, 'maxwell')
        )

    def draw(self, context):
        layout = self.layout
        mx = context.texture.maxwell

        row = layout.row()

        col = row.column(align=True)
        col.prop(mx, 'invert')
        col.prop(mx, 'alpha_only')
        col.prop(mx, 'interpolation')
        col.separator()
        col.label("Normal Mapping:")
        col.prop(mx, 'flip_x', toggle=True)
        col.prop(mx, 'flip_y', toggle=True)
        col.prop(mx, 'wide', toggle=True)

        col = row.column(align=True)
        col.prop(mx, 'brightness', slider=True)
        col.prop(mx, 'contrast', slider=True)
        col.prop(mx, 'saturation', slider=True)
        col.prop(mx, 'hue', slider=True)
        col.separator()
        col.prop(mx, 'clamp')


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_PT_projection(TextureButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Projection"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            hasattr(context.texture, 'maxwell') and
            (context.material or context.particle_system)
        )

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = context.texture.maxwell
        if not mx.override or context.particle_system:
            props = mx.projection
        else:
            props = mat.maxwell.override_map

        if mat:
            layout.prop(mx, 'override')
        layout.prop(props, 'channel')

        row = layout.row(align=True)
        row.label("Method:")
        col = row.column(align=True)
        row = col.row(align=True)
        row.prop(props, 'tile_x', toggle=True)
        row.prop(props, 'tile_y', toggle=True)
        col.prop(props, 'units', text="")

        row = layout.row(align=True)
        row.label("Mirror:")
        row.prop(props, 'mirror_x', text="X", toggle=True)
        row.prop(props, 'mirror_y', text="Y", toggle=True)

        row = layout.row()
        row.column().prop(props, 'repeat')
        row.column().prop(props, 'offset')

        layout.prop(props, 'rotation')


@MaxwellRenderEngine.register_class
class MAXWELL_TEXTURE_PT_procedurals(TextureButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Procedurals"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            hasattr(context.texture, 'maxwell')
        )

    def draw(self, context):
        layout = self.layout
        tex = context.texture
        mx = tex.maxwell

        row = layout.row()
        row.template_list('MAXWELL_UL_list', '', mx, 'procedurals', mx, 'active_procedural_index', rows=2)
        col = row.column(align=True)
        col.operator_menu_enum('maxwell.texture_procedural_add', 'type', text="", icon='ZOOMIN')
        col.operator('maxwell.texture_procedural_remove', text="", icon='ZOOMOUT')

        procedurals = mx.procedurals
        i = mx.active_procedural_index
        if 0 <= i < len(procedurals):
            procedural = procedurals[i]

            row = layout.row(align=True)
            row.operator('maxwell.texture_procedural_up', icon='TRIA_UP', text="")
            row.operator('maxwell.texture_procedural_down', icon='TRIA_DOWN', text="")
            row.prop(procedural, 'name', text="")
            row.prop(procedural, 'type', text="")

            pt = procedural.type
            if pt == 'Brick':
                brick = procedural.brick

                layout.prop(brick, 'blend')

                box = _UiBox(layout, brick, 'ui_brick', "Brick")
                if box is not None:
                    col = box.column()

                    subcol = col.column(align=True)
                    subcol.prop(brick, 'width')
                    subcol.prop(brick, 'height')

                    subcol = col.column(align=True)
                    subcol.prop(brick, 'brick_offset')
                    subcol.prop(brick, 'random_offset')

                    col.prop(brick, 'double')
                    col.prop(brick, 'small_width')
                    col.prop(brick, 'round_corners')

                    subcol = col.column(align=True)
                    subcol.prop(brick, 'sharpness_u')
                    subcol.prop(brick, 'sharpness_v')

                    subcol = col.column(align=True)
                    subcol.prop(brick, 'noise_detail')
                    subcol.prop(brick, 'noise_region_u')
                    subcol.prop(brick, 'noise_region_v')

                    col.prop(brick, 'seed')
                    col.prop(brick, 'random_rotation')
                    col.prop(brick, 'color_variation')

                id_data = context.texture_slot.id_data

                box = _UiBox(layout, brick, 'ui_brick1', "Brick 1")
                if box is not None:
                    col = box.column()
                    row = col.row(align=True)
                    row.prop(brick, 'color0')
                    row.prop_search(brick, 'texture0', id_data, 'texture_slots', text="")
                    col.prop(brick, 'factor0')
                    col.prop(brick, 'weight0')

                box = _UiBox(layout, brick, 'ui_brick2', "Brick 2")
                if box is not None:
                    col = box.column()
                    row = col.row(align=True)
                    row.prop(brick, 'color1')
                    row.prop_search(brick, 'texture1', id_data, 'texture_slots', text="")
                    col.prop(brick, 'factor1')
                    col.prop(brick, 'weight1')

                box = _UiBox(layout, brick, 'ui_brick3', "Brick 3")
                if box is not None:
                    col = box.column()
                    row = col.row(align=True)
                    row.prop(brick, 'color2')
                    row.prop_search(brick, 'texture2', id_data, 'texture_slots', text="")
                    col.prop(brick, 'factor2')
                    col.prop(brick, 'weight2')

                box = _UiBox(layout, brick, 'ui_mortar', "Mortar")
                if box is not None:
                    col = box.column()
                    col.prop(brick, 'mortar_thickness')
                    row = col.row(align=True)
                    row.prop(brick, 'mortar_color')
                    row.prop_search(brick, 'mortar_texture', id_data, 'texture_slots', text="")
            elif pt == 'Checker':
                checker = procedural.checker
                layout.prop(checker, 'blend')
                layout.prop(checker, 'color0')
                layout.prop(checker, 'color1')
                col = layout.column(align=True)
                col.prop(checker, 'checks_u')
                col.prop(checker, 'checks_v')
                layout.prop(checker, 'sharpness')
                layout.prop(checker, 'fall_off')
            elif pt == 'Circle':
                circle = procedural.circle
                layout.prop(circle, 'blend')
                layout.prop(circle, 'background')
                layout.prop(circle, 'circle')
                col = layout.column(align=True)
                col.prop(circle, 'radius_u')
                col.prop(circle, 'radius_v')
                layout.prop(circle, 'sharpness')
                layout.prop(circle, 'fall_off')
            elif pt == 'Gradient3':
                gradient3 = procedural.gradient3

                layout.prop(gradient3, "blend")

                box = _UiBox(layout, gradient3, 'ui_u', "U Direction")
                if box is not None:
                    col = box.column()

                    col.prop(gradient3, 'use_u')
                    subcol = col.column()
                    subcol.enabled = gradient3.use_u
                    subcol.row().prop(gradient3, 'start_u')
                    subcol.row().prop(gradient3, 'middle_u')
                    subcol.row().prop(gradient3, 'end_u')
                    subcol.prop(gradient3, 'type_u')
                    subcol.prop(gradient3, 'position_u')

                box = _UiBox(layout, gradient3, 'ui_v', "V Direction")
                if box is not None:
                    col = box.column()

                    col.prop(gradient3, 'use_v')
                    subcol = col.column()
                    subcol.enabled = gradient3.use_v
                    subcol.row().prop(gradient3, 'start_v')
                    subcol.row().prop(gradient3, 'middle_v')
                    subcol.row().prop(gradient3, 'end_v')
                    subcol.prop(gradient3, 'type_v')
                    subcol.prop(gradient3, 'position_v')
            elif pt == 'Gradient':
                gradient = procedural.gradient

                layout.prop(gradient, 'blend')

                box = _UiBox(layout, gradient, 'ui_u', "U Direction")
                if box is not None:
                    col = box.column()

                    col.prop(gradient, 'use_u')
                    subcol = col.column()
                    subcol.enabled = gradient.use_u
                    subcol.row().prop(gradient, 'start_u')
                    subcol.row().prop(gradient, 'end_u')
                    subcol.prop(gradient, 'type_u')
                    subcol.prop(gradient, 'position_u')

                box = _UiBox(layout, gradient, 'ui_v', "V Direction")
                if box is not None:
                    col = box.column()

                    col.prop(gradient, 'use_v')
                    subcol = col.column()
                    subcol.enabled = gradient.use_v
                    subcol.row().prop(gradient, 'start_v')
                    subcol.row().prop(gradient, 'end_v')
                    subcol.prop(gradient, 'type_v')
                    subcol.prop(gradient, 'position_v')
            elif pt == 'Grid':
                grid = procedural.grid

                layout.prop(grid, 'blend')
                layout.prop(grid, 'background')
                layout.prop(grid, 'cell')

                col = layout.column(align=True)
                col.prop(grid, 'width')
                col.prop(grid, 'height')

                col = layout.column(align=True)
                col.prop(grid, 'thickness_u')
                col.prop(grid, 'thickness_v')

                layout.prop(grid, 'sharpness')
                layout.prop(grid, 'fall_off')
            elif pt == 'Marble':
                marble = procedural.marble

                layout.prop(marble, 'blend')

                row = layout.row()
                row.label("Coordinates Type:")
                row.prop(marble, 'coordinates', expand=True)

                layout.prop(marble, 'color0')
                layout.prop(marble, 'color1')
                layout.prop(marble, 'color2')
                layout.prop(marble, 'frequency')
                layout.prop(marble, 'detail')
                layout.prop(marble, 'octaves')
                layout.prop(marble, 'seed')
            elif pt == 'Noise':
                noise = procedural.noise

                layout.prop(noise, 'blend')

                row = layout.row()
                row.label("Coordinates Type:")
                row.prop(noise, 'coordinates', expand=True)

                layout.prop(noise, 'background')
                layout.prop(noise, 'noise')
                layout.prop(noise, 'detail')
                layout.prop(noise, 'persistance')
                layout.prop(noise, 'octaves')

                col = layout.column(align=True)
                col.prop(noise, 'low_clip')
                col.prop(noise, 'hight_clip')

                layout.prop(noise, 'seed')
            elif pt == 'Voronoi':
                voronoi = procedural.voronoi

                layout.prop(voronoi, 'blend')

                row = layout.row()
                row.label("Coordinates Type:")
                row.prop(voronoi, "coordinates", expand=True)

                layout.prop(voronoi, 'background')
                layout.prop(voronoi, 'cell')
                layout.prop(voronoi, 'detail')
                layout.prop(voronoi, 'distance')
                layout.prop(voronoi, 'combination')

                col = layout.column(align=True)
                col.prop(voronoi, 'low_clip')
                col.prop(voronoi, 'hight_clip')

                layout.prop(voronoi, 'seed')
            elif pt == 'TiledTexture':
                tiled = procedural.tiled

                layout.prop(tiled, 'blend')
                layout.prop(tiled, 'filename')
                layout.prop(tiled, 'mask')
                layout.prop(tiled, 'base')
                layout.prop(tiled, 'use_base')
            elif pt == 'WireframeTexture':
                wire = procedural.wireframe

                layout.prop(wire, 'fill_color')
                layout.prop(wire, 'edge_color')
                layout.prop(wire, 'coplanar_edge_color')
                layout.prop(wire, 'edge_width')
                layout.prop(wire, 'coplanar_edge_width')
                layout.prop(wire, 'coplanar_threshold')

#endregion


#############################
#region Material

from bl_ui.properties_material import MaterialButtonsPanel


@MaxwellRenderEngine.register_class
class MAXWELL_UL_material_custom_alphas(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.prop(item, 'name', text="", emboss=False)

        channel_id = item.id
        if channel_id in context.material.maxwell.custom_alphas:
            remove = True
            icon = 'CHECKBOX_HLT'
        else:
            remove = False
            icon = 'CHECKBOX_DEHLT'
        row = layout.row()
        row.alignment = 'RIGHT'
        op = row.operator('maxwell.custom_alpha_material_add', text="", icon=icon, emboss=False)
        op.channel_id = channel_id
        op.remove = remove


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_opaque_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/opaque"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_transparent_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/transparent"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_metal_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/metal"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_translucent_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/translucent"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_carpaint_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/carpaint"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_hair_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/material/hair"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_MT_preview_scene(Menu):
    bl_label = "Preview Scene"

    def draw(self, context):
        layout = self.layout
        for fn in os.listdir(BMaxwellPreferences.prefs(context).mxpath("preview")):
            name, ext = os.path.splitext(fn)
            if ext == ".mxs":
                layout.operator('maxwell.material_preview_scene_set', text=name).name = name


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_preview(MaterialButtonsPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Preview"

    def draw(self, context):
        layout = self.layout
        mat = context.material

        layout.template_preview(mat, show_buttons=False, preview_id='maxwell_material')

        mx = mat.maxwell
        if mx.type != 'FILE':
            mxp = mx.preview
            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_preview_scene', text=mxp.scene)
            row.prop(mxp, 'sampling_level')
            row.prop(mxp, 'time_limit')
            icon = 'CANCEL' if mxp.state in {
                MaxwellRenderEngine.PREVIEW_START,
                MaxwellRenderEngine.PREVIEW_STARTED
            } else 'FILE_REFRESH'
            row.prop(mxp, 'update', text="", icon=icon)


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_context(MaterialButtonsPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'HIDE_HEADER'}
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return (
            MaxwellRenderEngine.is_active(context) and
            context.object is not None
        )

    def draw(self, context):
        layout = self.layout
        ob = context.object
        slot = context.material_slot

        row = layout.row()
        row.template_list('MATERIAL_UL_matslots', '', ob, 'material_slots', ob, 'active_material_index', rows=2)
        col = row.column(align=True)
        col.operator('object.material_slot_add', icon='ZOOMIN', text="")
        col.operator('object.material_slot_remove', icon='ZOOMOUT', text="")
        col.menu('MATERIAL_MT_specials', icon='DOWNARROW_HLT', text="")
        if ob.mode == 'EDIT':
            row = layout.row(align=True)
            row.operator('object.material_slot_assign', text="Assign")
            row.operator('object.material_slot_select', text="Select")
            row.operator('object.material_slot_deselect', text="Deselect")
        split = layout.split(percentage=0.7)
        split.template_ID(ob, 'active_material', new='material.new')
        row = split.row()
        if slot:
            row.prop(slot, 'link', text="")
        else:
            row.label()

        mat = context.material
        if mat:
            row = layout.row(align=True)
            row.menu("MAXWELL_MATERIAL_MT_presets", text=MAXWELL_MATERIAL_MT_presets.bl_label)
            row.operator("maxwell.material_preset_add", text="", icon='ZOOMIN')
            row.operator("maxwell.material_preset_add", text="", icon='ZOOMOUT').remove_active = True
            layout.prop(mat.maxwell, 'type')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_globals(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Globals"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.material.maxwell.type != 'FILE'
        )

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell

        split = layout.split(0.5, align=True)
        row = split.row(align=True)
        row.prop(mx, 'bump', text="Normal" if mx.bump_normal else "Bump")
        row.enabled = bool(mx.bump_map)
        row = split.row(align=True)
        row.prop_search(mx, 'bump_map', mat, 'texture_slots', text="", icon='TEXTURE')
        icon = 'MAXWELL_NORMAL_ENABLED' if mx.bump_normal else 'MAXWELL_NORMAL_DISABLED'
        row.prop(mx, 'ui_bump_normal', text="", icon_value=_ICONS[icon].icon_id)

        row = layout.row()
        col = row.column()
        col.prop(mx, 'dispersion')
        col.prop(mx, 'shadow')
        col.prop(mx, 'matte')
        col = row.column()
        col.prop(mx, 'color_id')
        col.prop(mx, 'nested_priority')

        layout.operator('maxwell.material_save_mxm')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_material(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = ""

    _icons = None

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.material.maxwell.type != 'CUSTOM'
        )

    def draw_header(self, context):
        super().draw_header(context)
        mat = context.material
        mx = mat.maxwell
        self.text = mx.bl_rna.properties['type'].enum_items[mx.type].name

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell

        mx_type = mx.type
        if mx_type == 'FILE':
            layout.prop(mx, 'mxm')
            row = layout.row(align=True)
            row.operator('maxwell.material_browse_mxm')
            if mx.mxm.strip():
                row.operator('maxwell.material_edit_mxm')
                row.separator()
                row.operator('maxwell.material_read_mxm')
            layout.prop(mx, 'embed')
        elif mx_type == 'AGS':
            ags = mx.ags

            layout.prop(ags, 'color')
            layout.prop(ags, 'reflection')
            layout.prop(ags, 'type')
        elif mx_type == 'OPAQUE':
            opaque = mx.opaque

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_opaque_presets')
            row.operator('maxwell.material_opaque_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.material_opaque_preset_add', text="", icon='ZOOMOUT').remove_active = True

            row = layout.row(align=True)
            row.prop(opaque, 'color')
            row.prop(opaque, 'ui_color_map_enabled', text="")
            row.prop_search(opaque, 'color_map', mat, 'texture_slots', text="")

            row = layout.row(align=True)
            row.label("Shininess:")
            row.prop(opaque, 'shininess', text="")
            row.prop(opaque, 'ui_shininess_map_enabled', text="")
            row.prop_search(opaque, 'shininess_map', mat, 'texture_slots', text="")

            row = layout.row(align=True)
            row.label("Roughness:")
            row.prop(opaque, 'roughness', text="")
            row.prop(opaque, 'ui_roughness_map_enabled', text="")
            row.prop_search(opaque, 'roughness_map', mat, 'texture_slots', text="")

            layout.prop(opaque, 'clearcoat')
        elif mx_type == 'TRANSPARENT':
            transparent = mx.transparent

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_transparent_presets')
            row.operator('maxwell.material_transparent_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.material_transparent_preset_add', text="", icon='ZOOMOUT').remove_active = True

            row = layout.row(align=True)
            row.prop(transparent, 'color')
            row.prop(transparent, 'ui_color_map_enabled', text="")
            row.prop_search(transparent, 'color_map', mat, 'texture_slots', text="")

            layout.prop(transparent, 'ior')
            layout.prop(transparent, 'transparency')

            row = layout.row(align=True)
            row.label('Roughness:')
            row.prop(transparent, 'roughness', text='')
            row.prop(transparent, 'ui_roughness_map_enabled', text="")
            row.prop_search(transparent, 'roughness_map', mat, 'texture_slots', text="")

            layout.prop(transparent, 'specular_tint')
            layout.prop(transparent, 'dispersion')
            layout.prop(transparent, 'clearcoat')
        elif mx_type == 'METAL':
            metal = mx.metal

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_metal_presets')
            row.operator('maxwell.material_metal_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.material_metal_preset_add', text="", icon='ZOOMOUT').remove_active = True

            layout.prop(metal, 'ior')
            layout.prop(metal, 'tint')

            split = layout.split(0.33)
            split.label("Color:")
            row = split.row(align=True)
            row.prop(metal, 'color', text="")
            row.prop(metal, 'ui_color_map_enabled', text="")
            row.prop_search(metal, 'color_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Roughness:")
            row = split.row(align=True)
            row.prop(metal, 'roughness', text="")
            row.prop(metal, 'ui_roughness_map_enabled', text="")
            row.prop_search(metal, 'roughness_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Anisotropy:")
            row = split.row(align=True)
            row.prop(metal, 'anisotropy', text="")
            row.prop(metal, 'ui_anisotropy_map_enabled', text="")
            row.prop_search(metal, 'anisotropy_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Angle:")
            row = split.row(align=True)
            row.prop(metal, 'angle', text="")
            row.prop(metal, 'ui_angle_map_enabled', text="")
            row.prop_search(metal, 'angle_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Dust & Dirt:")
            row = split.row(align=True)
            row.prop(metal, 'dust', text='')
            row.prop(metal, 'ui_dust_map_enabled', text="")
            row.prop_search(metal, 'dust_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Perforation:")
            row = split.row(align=True)
            row.prop(metal, 'ui_perforation_map_enabled', text="")
            row.prop_search(metal, 'perforation_map', mat, 'texture_slots', text="")
        elif mx_type == 'TRANSLUCENT':
            translucent = mx.translucent

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_translucent_presets')
            row.operator('maxwell.material_translucent_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.material_translucent_preset_add', text="", icon='ZOOMOUT').remove_active = True

            layout.prop(translucent, 'scale')
            layout.prop(translucent, 'ior')

            row = layout.row(align=True)
            row.label("Color:")
            row.prop(translucent, 'color', text="")
            row.prop(translucent, 'ui_color_map_enabled', text="")
            row.prop_search(translucent, 'color_map', mat, 'texture_slots', text="")

            layout.prop(translucent, 'hue_shift')
            layout.prop(translucent, 'invert_hue')
            layout.prop(translucent, 'vibrance')
            layout.prop(translucent, 'density')
            layout.prop(translucent, 'opacity')

            row = layout.row(align=True)
            row.label("Roughness:")
            row.prop(translucent, 'roughness', text="")
            row.prop(translucent, 'ui_roughness_map_enabled', text="")
            row.prop_search(translucent, 'roughness_map', mat, 'texture_slots', text="")

            layout.prop(translucent, 'specular_tint')
            layout.prop(translucent, 'clearcoat')
            layout.prop(translucent, 'clearcoat_ior')
        elif mx_type == 'CARPAINT':
            carpaint = mx.carpaint

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_carpaint_presets')
            row.operator('maxwell.material_carpaint_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.material_carpaint_preset_add', text="", icon='ZOOMOUT').remove_active = True

            layout.prop(carpaint, 'color')
            layout.prop(carpaint, 'metallic')
            layout.prop(carpaint, 'topcoat')
        elif mx_type == 'HAIR':
            hair = mx.hair

            row = layout.row(align=True)
            row.menu('MAXWELL_MATERIAL_MT_hair_presets')
            row.operator("maxwell.material_hair_preset_add", text="", icon='ZOOMIN')
            row.operator("maxwell.material_hair_preset_add", text="", icon='ZOOMOUT').remove_active = True

            split = layout.split(0.33)
            split.label("Color:")
            row = split.row(align=True)
            row.prop(hair, 'color', text="")
            row.prop(hair, 'ui_color_map_enabled', text="")
            row.prop_search(hair, 'color_map', mat, 'texture_slots', text="")

            layout.prop_search(hair, 'root_tip_map', mat, 'texture_slots')

            split = layout.split(0.33)
            split.label("Root-Tip Weight:")
            row = split.row(align=True)
            row.prop(hair, 'root_tip_weight', text="")
            row.prop(hair, 'ui_root_tip_weight_map_enabled', text="")
            row.prop_search(hair, 'root_tip_weight_map', mat, 'texture_slots', text="")

            box = _UiBox(layout, hair, 'ui_primary', "Primary Highlight")
            if box is not None:
                col = box.column()
                col.prop(hair, 'primary_strength')
                col.prop(hair, 'primary_spread')
                col.row().prop(hair, 'primary_tint')

            box = _UiBox(layout, hair, 'ui_secondary', "Secondary Highlight")
            if box is not None:
                col = box.column()
                col.prop(hair, 'secondary_strength')
                col.prop(hair, 'secondary_spread')
                col.row().prop(hair, 'secondary_tint')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_displacement(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Displacement"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.material.maxwell.type == 'CUSTOM'
        )

    def draw_header(self, context):
        super().draw_header(context)
        self.layout.prop(context.material.maxwell.displacement, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        mat = context.material
        displacement = mat.maxwell.displacement

        layout.enabled = displacement.enabled

        col = layout.column()
        col.prop_search(displacement, 'map', mat, 'texture_slots')
        col.prop(displacement, 'type')

        col.prop(displacement, 'level')
        col.prop(displacement, 'adaptive')
        col.prop(displacement, 'method')
        col.prop(displacement, 'offset')
        col.prop(displacement, 'smooth')
        col.prop(displacement, 'uvi')

        box = _UiBox(layout, displacement, 'ui_height_map', "Height Map")
        if box is not None:
            col = box.column()
            text = "Height, cm" if displacement.absolute else "Height, %"
            col.prop(displacement, 'height', text=text)
            col.prop(displacement, 'absolute')

        box = _UiBox(layout, displacement, 'ui_vector', "Vector 3D")
        if box is not None:
            col = box.column()
            enabled1 = (displacement.type == '2')
            row = col.row()
            row.enabled = enabled1
            row.prop(displacement, 'preset')

            enabled2 = (enabled1 and displacement.preset == '0')
            row = col.row()
            row.enabled = enabled2
            row.prop(displacement, 'transform')

            row = col.row()
            row.enabled = enabled2
            row.prop(displacement, 'mapping')

            row = col.row()
            row.enabled = enabled1
            row.prop(displacement, 'scale')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_layers(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Layers"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.material.maxwell.type == 'CUSTOM'
        )

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell

        row = layout.row()
        row.template_list('MAXWELL_UL_list', '', mx, 'layers', mx, 'active_layer_index', rows=2)
        col = row.column(align=True)
        col.operator('maxwell.material_layer_add', text="", icon='ZOOMIN')
        col.operator('maxwell.material_layer_remove', text="", icon='ZOOMOUT')
        col.operator_menu_enum('maxwell.material_layer', 'action', text="", icon='DOWNARROW_HLT')

        layers = mx.layers
        i = mx.active_layer_index
        if 0 <= i < len(layers):
            layer = layers[i]
            row = layout.row(align=True)
            row.operator('maxwell.material_layer_up', text="", icon='TRIA_UP')
            row.operator('maxwell.material_layer_down', text="", icon='TRIA_DOWN')
            row.prop(layer, 'name', text="")

            row = layout.row(align=True)
            row.prop(layer, 'opacity')
            row.prop(layer, 'ui_opacity_map_enabled', text="")
            row.prop_search(layer, 'opacity_map', mat, 'texture_slots', text="")

            row = layout.row()
            row.label("Blending:")
            row.prop(layer, 'blend', expand=True)


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_bsdfs(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "BSDFs - [%s]"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            mx = context.material.maxwell
            return (
                mx.type == 'CUSTOM' and
                0 <= mx.active_layer_index < len(mx.layers)
            )
        return False

    def draw_header(self, context):
        super().draw_header(context)
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        self.text = self.bl_label % layer.name

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell

        layer = mx.layers[mx.active_layer_index]

        row = layout.row()
        row.template_list('MAXWELL_UL_list', '', layer, 'bsdfs', layer, 'active_bsdf_index', rows=2)
        col = row.column(align=True)
        col.operator('maxwell.material_bsdf_add', icon='ZOOMIN', text="")
        col.operator('maxwell.material_bsdf_remove', icon='ZOOMOUT', text="")
        col.operator_menu_enum('maxwell.material_bsdf', 'action', icon='DOWNARROW_HLT', text="")

        if layer.bsdfs:
            bsdf = layer.bsdfs[layer.active_bsdf_index]

            row = layout.row(align=True)
            row.operator('maxwell.material_bsdf_up', icon='TRIA_UP', text="")
            row.operator('maxwell.material_bsdf_down', icon='TRIA_DOWN', text="")
            row.prop(bsdf, 'name', text="")

            row = layout.row(align=True)
            row.prop(bsdf, 'weight')
            row.prop(bsdf, 'ui_weight_map_enabled', text="")
            row.prop_search(bsdf, 'weight_map', mat, 'texture_slots', text="")

            box = _UiBox(layout, bsdf, 'ui_bsdf', "BSDF")
            if box is not None:
                col = box.column()
                split = col.split(0.33)
                split.label("IOR:")
                split.row().prop(bsdf, 'ior_type', expand=True)
                if bsdf.ior_type == '0':  # Custom
                    split = col.split(0.33)
                    split.label("Reflectance 0:")
                    row = split.row(align=True)
                    row.prop(bsdf, 'color', text="")
                    row.prop(bsdf, 'ui_color_map_enabled', text="")
                    row.prop_search(bsdf, 'color_map', mat, 'texture_slots', text="")

                    split = col.split(0.33)
                    split.label("Reflectance 90:")
                    row = split.row(align=True)
                    row.prop(bsdf, 'tangential', text="")
                    row.prop(bsdf, 'ui_tangential_map_enabled', text="")
                    row.prop_search(bsdf, 'tangential_map', mat, 'texture_slots', text="")

                    split = col.split(0.33)
                    split.label("Transmittance:")
                    row = split.row(align=True)
                    row.prop(bsdf, 'transmittance', text="")
                    row.prop(bsdf, 'ui_transmittance_map_enabled', text="")
                    row.prop_search(bsdf, 'transmittance_map', mat, 'texture_slots', text="")

                    roughness_enabled = (
                        bsdf.roughness < 100.0 or 
                        bool(bsdf.roughness_map and bsdf.roughness_map_enabled)
                    )

                    row = col.split(0.85, align=True)
                    row.prop(bsdf, 'attenuation')
                    row.prop(bsdf, 'attenuation_units', text="")

                    row = col.row()
                    row.prop(bsdf, 'nd')
                    subrow = row.row()
                    subrow.prop(bsdf, 'force_fresnel')
                    subrow.enabled = roughness_enabled

                    row = col.row()
                    row.prop(bsdf, 'k')
                    row.enabled = roughness_enabled

                    row = col.row()
                    row.prop(bsdf, 'abbe')
                    row.enabled = mx.dispersion

                    split = col.split(0.1, align=True)
                    split.prop(bsdf, 'fresnel_custom_enabled', text="R2", toggle=True)
                    row = split.row(align=True)
                    row.prop(bsdf, 'fresnel_custom_angle')
                    row.prop(bsdf, 'fresnel_custom_roughness')
                    row.enabled = bsdf.fresnel_custom_enabled
                elif bsdf.ior_type == '1':  # Measured
                    col.row().prop(bsdf, 'ior_file')

            box = _UiBox(layout, bsdf, 'ui_surface', "Surface")
            if box is not None:
                col = box.column()
                row = col.row(align=True)

                have_anisotropy = bool(bsdf.anisotropy > 0 or bsdf.anisotropy_map)

                col = row.column()
                col.prop(bsdf, 'roughness')

                subrow = col.row()
                subrow.prop(bsdf, 'bump')
                subrow.enabled = bool(bsdf.bump_map)

                col.prop(bsdf, 'anisotropy')

                subrow = col.row()
                subrow.prop(bsdf, 'angle')
                subrow.enabled = have_anisotropy

                col = row.column()
                row = col.row(align=True)
                row.prop(bsdf, 'ui_roughness_map_enabled', text="")
                row.prop_search(bsdf, 'roughness_map', mat, 'texture_slots', text="")

                row = col.row(align=True)
                row.prop(bsdf, 'ui_bump_map_enabled', text="")
                row.prop_search(bsdf, 'bump_map', mat, 'texture_slots', text="")
                icon = 'MAXWELL_NORMAL_ENABLED' if bsdf.bump_normal else 'MAXWELL_NORMAL_DISABLED'
                row.prop(bsdf, 'ui_bump_normal', text="", icon_value=_ICONS[icon].icon_id)

                row = col.row(align=True)
                row.prop(bsdf, 'ui_anisotropy_map_enabled', text="")
                row.prop_search(bsdf, 'anisotropy_map', mat, 'texture_slots', text="")

                row = col.row(align=True)
                row.prop(bsdf, 'ui_angle_map_enabled', text="")
                row.prop_search(bsdf, 'angle_map', mat, 'texture_slots', text="")
                row.enabled = have_anisotropy

            box = _UiBox(layout, bsdf, 'ui_subsurface', "Subsurface")
            if box is not None:
                col = box.column()

                use_thickness = bsdf.use_thickness

                row = col.row(align=True)
                row.prop(bsdf, 'scattering')
                subrow = row.row(align=True)
                subrow.enabled = use_thickness
                subrow.prop(bsdf, 'ui_scattering_map_enabled', text="")
                subrow.prop_search(bsdf, 'scattering_map', mat, 'texture_slots', text="")

                row = col.row(align=True)
                row.prop(bsdf, 'scattering_coefficient')
                row.prop(bsdf, 'scattering_asymmetry')

                col.prop(bsdf, 'use_thickness')

                row = col.row(align=True)
                row.enabled = use_thickness
                subrow = row.row(align=True)
                subrow.prop(bsdf, 'thickness')
                subrow.enabled = not (bsdf.thickness_map and bsdf.thickness_map_enabled)
                subrow = row.row(align=True)
                subrow.prop(bsdf, 'ui_thickness_map_enabled', text="")
                subrow.prop_search(bsdf, 'thickness_map', mat, 'texture_slots', text="")

                row = col.row(align=True)
                row.enabled = use_thickness
                row.prop(bsdf, 'thickness_min')
                row.prop(bsdf, 'thickness_max')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_emitter(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Emitter - [%s]"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            mx = context.material.maxwell
            return (
                mx.type == 'CUSTOM' and
                0 <= mx.active_layer_index < len(mx.layers)
            )
        return False

    def draw_header(self, context):
        super().draw_header(context)
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        self.text = self.bl_label % layer.name
        self.layout.prop(layer.emitter, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell
        layers = mx.layers
        i = mx.active_layer_index
        if 0 <= i < len(layers):
            emitter = layers[i].emitter
            layout.enabled = emitter.enabled
            _draw_emitter(layout, mat, emitter)


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_coating(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Coating - [%s] [%s]"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            mx = context.material.maxwell
            if mx.type == 'CUSTOM':
                layers = mx.layers
                i = mx.active_layer_index
                if 0 <= i < len(layers):
                    layer = layers[i]
                    return (0 <= layer.active_bsdf_index < len(layer.bsdfs))
        return False

    def draw_header(self, context):
        super().draw_header(context)
        mx = context.material.maxwell
        layer = mx.layers[mx.active_layer_index]
        bsdf = layer.bsdfs[layer.active_bsdf_index]
        self.text = self.bl_label % (layer.name, bsdf.name)
        self.layout.prop(bsdf.coating, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        mat = context.material
        mx = mat.maxwell
        layer = mx.layers[mx.active_layer_index]
        coating = layer.bsdfs[layer.active_bsdf_index].coating

        layout.enabled = coating.enabled

        row = layout.row(align=True)
        subrow = row.row(align=True)
        subrow.prop(coating, 'thickness')
        subrow.enabled = not (coating.thickness_map and coating.thickness_map_enabled)
        row.prop(coating, 'ui_thickness_map_enabled', text="")
        row.prop_search(coating, 'thickness_map', mat, 'texture_slots', text="")

        row = layout.row(align=True)
        row.prop(coating, 'thickness_min')
        row.prop(coating, 'thickness_max')
        row.enabled = bool(coating.thickness_map and coating.thickness_map_enabled)

        split = layout.split(0.33)
        split.label("IOR:")
        split.row().prop(coating, 'ior_type', expand=True)

        if coating.ior_type == '0':  # Custom
            split = layout.split(0.33)
            split.label("Reflectance 0:")
            row = split.row(align=True)
            row.prop(coating, 'color', text="")
            row.prop(coating, 'ui_color_map_enabled', text="")
            row.prop_search(coating, 'color_map', mat, 'texture_slots', text="")

            split = layout.split(0.33)
            split.label("Reflectance 90:")
            row = split.row(align=True)
            row.prop(coating, 'tangential', text="")
            row.prop(coating, 'ui_tangential_map_enabled', text="")
            row.prop_search(coating, 'tangential_map', mat, 'texture_slots', text="")

            row = layout.row()
            row.prop(coating, 'nd')
            row.prop(coating, 'force_fresnel')

            layout.prop(coating, 'k')

            split = layout.split(0.1, align=True)
            split.prop(coating, 'fresnel_custom_enabled', text="R2", toggle=True)
            row = split.row(align=True)
            row.prop(coating, 'fresnel_custom_angle')
            row.enabled = coating.fresnel_custom_enabled
        elif coating.ior_type == '1':  # Measured
            layout.prop(coating, 'ior_file')


@MaxwellRenderEngine.register_class
class MAXWELL_MATERIAL_PT_custom_alphas(MaterialButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Custom Alpha Channels"

    def draw(self, context):
        channels = context.scene.maxwell.render.channels
        self.layout.template_list('MAXWELL_UL_material_custom_alphas', '',
                                  channels, 'custom_alphas', context.material.maxwell,
                                  'active_custom_alpha_index', rows=2)

#endregion


#############################
#region Render

from bl_ui.properties_render import RenderButtonsPanel


@MaxwellRenderEngine.register_class
class MAXWELL_MT_render_presets(Menu):
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/render"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_UL_custom_alphas(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.prop(item, 'name', text="", icon_value=icon, emboss=False)
        layout.prop(item, 'opaque', text="")


class _UICustomAlphaList:
    def filter_items(self, context, data, prop):
        FILTER = self.bitflag_filter_item
        if self.use_filter_invert:
            SHOW = 0
            HIDE = FILTER
        else:
            SHOW = FILTER
            HIDE = 0

        items = getattr(data, prop)
        flags = [HIDE] * len(items)

        channels = context.scene.maxwell.render.channels
        custom_alphas = channels.custom_alphas
        i = channels.active_custom_alpha_index
        if 0 <= i < len(custom_alphas):
            channel_id = custom_alphas[i].id

            pattern = self.filter_name
            if pattern:
                pattern = "*" + pattern + "*"

            for i, item in enumerate(items):
                item_custom_alphas = item.maxwell.get('_custom_alphas')
                if item_custom_alphas and channel_id in item_custom_alphas:
                    if not pattern:
                        flags[i] = SHOW
                    elif fnmatchcase(item.name, pattern):
                        flags[i] = FILTER
                    else:
                        flags[i] = 0

        return flags, []


@MaxwellRenderEngine.register_class
class MAXWELL_UL_custom_alpha_objects(_UICustomAlphaList, UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.label(item.name)
        layout.context_pointer_set('object', item)
        layout.operator('maxwell.custom_alpha_object_remove', text="", icon='X', emboss=False)


@MaxwellRenderEngine.register_class
class MAXWELL_UL_custom_alpha_materials(_UICustomAlphaList, UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.label(item.name)
        layout.context_pointer_set('material', item)
        layout.operator('maxwell.custom_alpha_material_remove', text="", icon='X', emboss=False)


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_MT_extra_sampling_custom_alpha(Menu):
    bl_label = "Custom Alpha Channels"

    def draw(self, context):
        layout = self.layout
        layout.label("Custom Alpha")
        layout.separator()
        for a in context.scene.maxwell.render.channels.custom_alphas:
            layout.operator('maxwell.extra_sampling_custom_alpha_set', text=a.name).channel_id = a.id


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_scene(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Scene"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        row = layout.row(align=True)
        row.menu('MAXWELL_MT_render_presets', text=MAXWELL_MT_render_presets.bl_label)
        row.operator('maxwell.render_preset_add', text="", icon='ZOOMIN')
        row.operator('maxwell.render_preset_add', text="", icon='ZOOMOUT').remove_active = True

        layout.prop(render, 'time_limit')
        layout.prop(render, 'sampling_level')
        layout.prop(render, 'threads')

        split = layout.split(0.33)
        split.label("Multilight:")
        row = split.row(align=True)
        row.prop(render, 'multilight', text="")
        row.prop(render, 'multilight_save_lights', text="")

        layout.prop(render, 'quality')


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_output(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Output"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        row = layout.row()
        #row.enabled = bool(render.output_image)
        row.prop(render, 'output_depth')

        split = layout.split(0.33, align=True)
        split.label("Image:")
        row = split.row(align=True)
        subrow = row.row(align=True)
        subrow.prop(render, 'output_image_enabled', text="")
        row.prop(render, 'output_image', text="")

        split = layout.split(0.33, align=True)
        split.label("MXI:")
        row = split.row(align=True)
        subrow = row.row(align=True)
        subrow.prop(render, 'output_mxi_enabled', text="")
        row.prop(render, 'output_mxi', text="")

        split = layout.split(0.33, align=True)
        split.label("MXS:")
        row = split.row(align=True)
        row.prop(render, 'output_mxs_enabled', text="")
        row.prop(render, 'output_mxs', text="")


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_materials(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Materials"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        split = layout.split(0.33, align=True)
        split.label("Override:")
        row = split.row(align=True)
        row.prop(render, 'override_material_enabled', text="")
        row = row.row(align=True)
        row.enabled = render.override_material_enabled
        row.prop(render, 'override_material', text="")

        layout.prop(render, 'default_material')

        col = layout.column()
        col.label("Searching Paths:")
        row = col.row()
        row.template_list('UI_UL_list', 'maxwell.searching_paths',
                          render, 'searching_paths',
                          render, 'active_searching_path_index',
                          rows=2)
        col = row.column(align=True)
        col.operator('maxwell.scene_searching_path_add', text="", icon='ZOOMIN')
        col.operator('maxwell.scene_searching_path_remove', text="", icon='ZOOMOUT')


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_globals(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Globals"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        row = layout.row()
        row.prop(render, 'motion_blur')
        row = row.row()
        row.enabled = render.motion_blur
        row.prop(render, 'motion_blur_steps')
        layout.prop(render, 'displacement')
        layout.prop(render, 'dispersion')


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_extra_sampling(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Extra Sampling"

    def draw_header(self, context):
        super().draw_header(context)
        self.layout.prop(context.scene.maxwell.render.extra_sampling, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render
        extra_sampling = render.extra_sampling
        use_custom_alpha = (extra_sampling.mask == 'CUSTOM_ALPHA')

        layout.enabled = extra_sampling.enabled
        layout.prop(extra_sampling, 'mask')
        layout.prop(extra_sampling, 'sampling_level')

        split = layout.split(0.33)
        split.label("Custom Alpha:")
        row = split.row()
        row.enabled = use_custom_alpha
        channel_id = extra_sampling.channel_id
        for a in render.channels.custom_alphas:
            if a.id == channel_id:
                text = a.name
                break
        else:
            text = ""
        row.menu('MAXWELL_RENDER_MT_extra_sampling_custom_alpha', text=text)

        row = layout.row()
        row.enabled = not use_custom_alpha
        row.prop(extra_sampling, 'bitmap')

        layout.prop(extra_sampling, 'invert_mask')


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_channels(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Channels"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mx = scene.maxwell
        render = mx.render
        channels = render.channels

        split = layout.split(0.27)
        split.label("Output Mode:")
        split.row().prop(channels, 'output_mode', text="")

        split = layout.split(0.27)
        split.label("Render:")
        row = split.row(align=True)
        row.prop(channels, 'render_enabled', text="")
        row.prop(channels, 'render_type', text="")

        split = layout.split(0.27)
        split.label("Alpha:")
        row = split.row(align=True)
        row.prop(channels, 'alpha_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'alpha_format', text="")
        split.prop(channels, 'alpha_opaque')

        split = layout.split(0.27)
        split.label("Z-buffer:")
        row = split.row(align=True)
        row.prop(channels, 'z_buffer_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'z_buffer_format', text="")
        split.row().prop(channels, 'z_buffer_range', text="")

        split = layout.split(0.27)
        split.label("Shadow:")
        row = split.row(align=True)
        row.prop(channels, 'shadow_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'shadow_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Material ID:")
        row = split.row(align=True)
        row.prop(channels, 'material_id_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'material_id_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Object ID:")
        row = split.row(align=True)
        row.prop(channels, 'object_id_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'object_id_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Motion Vector:")
        row = split.row(align=True)
        row.prop(channels, 'motion_vector_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'motion_vector_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Roughness:")
        row = split.row(align=True)
        row.prop(channels, 'roughness_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'roughness_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Fresnel:")
        row = split.row(align=True)
        row.prop(channels, 'fresnel_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'fresnel_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Normals:")
        row = split.row(align=True)
        row.prop(channels, 'normals_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'normals_format', text="")
        split.row().prop(channels, 'normals_space', expand=True)

        split = layout.split(0.27)
        split.label("Position:")
        row = split.row(align=True)
        row.prop(channels, 'position_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'position_format', text="")
        split.row().prop(channels, 'position_space', expand=True)

        split = layout.split(0.27)
        split.label("Deep:")
        row = split.row(align=True)
        row.prop(channels, 'deep_enabled', text="")
        col = row.column()
        split = col.split(0.33)
        split.prop(channels, 'deep_format', text="")
        split.row().prop(channels, 'deep_channels', expand=True)
        col.prop(channels, 'deep_distance')
        col.prop(channels, 'deep_samples')

        split = layout.split(0.27)
        split.label("UV:")
        row = split.row(align=True)
        row.prop(channels, 'uv_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'uv_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Custom Alpha:")
        row = split.row(align=True)
        row.prop(channels, 'custom_alpha_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'custom_alpha_format', text="")
        split.label("")

        split = layout.split(0.27)
        split.label("Reflectance:")
        row = split.row(align=True)
        row.prop(channels, 'reflectance_enabled', text="")
        split = row.split(0.33)
        split.prop(channels, 'reflectance_format', text="")
        split.label("")


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_custom_alphas(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Custom Alpha Channels"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mx = scene.maxwell
        render = mx.render
        channels = render.channels

        row = layout.row()
        row.template_list('MAXWELL_UL_custom_alphas', '',
                          channels, 'custom_alphas',
                          channels, 'active_custom_alpha_index',
                          rows=2)
        col = row.column(align=True)
        col.operator('maxwell.custom_alphas_add', text="", icon='ZOOMIN')
        col.operator('maxwell.custom_alphas_remove', text="", icon='ZOOMOUT')

        sub = _UiSub(layout, channels, 'ui_custom_alpha_objects', "Objects")
        if sub is not None:
            sub.template_list('MAXWELL_UL_custom_alpha_objects', '',
                              scene, 'objects',
                              channels, 'active_custom_alpha_object_index',
                              rows=2)
            row = sub.row(align=True)
            row.operator('maxwell.custom_alpha_assign')
            row.operator('maxwell.custom_alpha_select')
            row.operator('maxwell.custom_alpha_deselect')

        sub = _UiSub(layout, channels, 'ui_custom_alpha_materials', "Materials")
        if sub is not None:
            sub.template_list('MAXWELL_UL_custom_alpha_materials', '',
                              context.blend_data, 'materials',
                              channels, 'active_custom_alpha_material_index',
                              rows=2)


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_tone_mapping(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Tone Mapping"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        layout.prop(render, 'color_space')
        layout.prop(render, 'white_point')
        layout.prop(render, 'tint')
        layout.prop(render, 'burn')
        layout.prop(render, 'gamma')

        split = layout.split(0.33)
        split.label("Sharpness:")
        row = split.row(align=True)
        row.prop(render, 'sharpness_enabled', text="")
        subrow = row.row()
        subrow.enabled = render.sharpness_enabled
        subrow.prop(render, "sharpness", text="")


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_simulens(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Simulens"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        layout.prop(render, 'aperture_map')
        layout.prop(render, 'obstacle_map')

        split = layout.split(0.33)
        split.label("Diffraction:")
        row = split.row(align=True)
        row.prop(render, 'diffraction_enabled', text="")
        row = row.row()
        row.enabled = render.diffraction_enabled
        row.prop(render, 'diffraction', text="")

        layout.prop(render, 'frequency')

        split = layout.split(0.33)
        split.label("Scattering:")
        row = split.row(align=True)
        row.prop(render, 'scattering_enabled', text="")
        subrow = row.row()
        subrow.prop(render, 'scattering', text="")
        subrow.enabled = render.scattering_enabled

        split = layout.split(0.33)
        split.label("Devignetting:")
        row = split.row(align=True)
        row.prop(render, 'devignetting_enabled', text="")
        subrow = row.row()
        subrow.prop(render, 'devignetting', text="")
        subrow.enabled = render.devignetting_enabled


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_illumination_caustics(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Illumination & Caustics"

    def draw(self, context):
        layout = self.layout
        render = context.scene.maxwell.render

        layout.prop(render, 'illumination')
        layout.prop(render, 'reflection_caustics')
        layout.prop(render, 'refraction_caustics')


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_overlay_text(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Overlay Text"

    def draw_header(self, context):
        super().draw_header(context)
        self.layout.prop(context.scene.maxwell.render.overlay_text, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        overlay_text = context.scene.maxwell.render.overlay_text

        layout.enabled = overlay_text.enabled

        layout.prop(overlay_text, 'text')
        layout.prop(overlay_text, 'position')
        layout.prop(overlay_text, 'color')
        
        row = layout.row(align=True)
        row.prop(overlay_text, 'background_enabled')
        row = row.row()
        row.enabled = overlay_text.background_enabled
        row.prop(overlay_text, 'background', text="")


@MaxwellRenderEngine.register_class
class MAXWELL_RENDER_PT_fire(RenderButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "FIRE"

    def draw(self, context):
        layout = self.layout
        fire = context.scene.maxwell.fire

        layout.prop(fire, 'sampling_level')
        layout.prop(fire, 'time_limit')
        #layout.prop(fire, 'quality')
        layout.prop(fire, 'floating_shadows')
        layout.prop(fire, 'floating_reflections')

#endregion


#############################
#region Environment

from bl_ui.properties_world import WorldButtonsPanel
from bl_ui.properties_world import WORLD_PT_context_world

def _ibl_panel(layout, layer):
    layout.prop(layer, 'type')

    enabled = (layer.type == '1')

    col = layout.column()
    col.enabled = enabled
    col.prop(layer, 'map')
    col.prop(layer, 'intensity')
    col.row().prop(layer, 'scale')
    col.row().prop(layer, 'offset')


@MaxwellRenderEngine.register_class
class MAXWELL_MT_environment_presets(Menu):
    bl_label = "Presets"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/environment"

    draw = Menu.draw_preset

    def draw_panel(self, context):
        if MaxwellRenderEngine.is_active(context) and context.world:
            layout = self.layout
            layout.separator()
            row = layout.row(align=True)
            row.menu('MAXWELL_MT_environment_presets', text=MAXWELL_MT_environment_presets.bl_label)
            row.operator('maxwell.environment_preset_add', text="", icon='ZOOMIN')
            row.operator('maxwell.environment_preset_add', text="", icon='ZOOMOUT').remove_active = True
            layout.prop(context.world.maxwell, 'type', expand=True)

    @classmethod
    def register(cls):
        WORLD_PT_context_world.append(cls.draw_panel)

    @classmethod
    def unregister(cls):
        WORLD_PT_context_world.remove(cls.draw_panel)


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_sky(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Sky"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type != 'NONE'
        )

    def draw(self, context):
        layout = self.layout
        mx = context.world.maxwell
        layout.prop(mx, 'sky_type', expand=True)
        col = layout.column()
        sky_type = mx.sky_type
        if sky_type == 'PHYSICAL':
            physical = mx.physical
            col.prop(physical, 'intensity')
            col.prop(physical, 'planet_reflectance')
            col.prop(physical, 'ozone')
            col.prop(physical, 'water')
            col.prop(physical, 'angstrom')
            col.prop(physical, 'wavelength')
            col.prop(physical, 'albedo')
            col.prop(physical, 'asymmetry')
        elif sky_type == 'CONSTANT':
            constant = mx.constant
            col.prop(constant, 'luminance')
            col.row().prop(constant, 'zenith')
            col.row().prop(constant, 'horizon')
            col.prop(constant, 'control_point')


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_sun(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Sun"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type != 'NONE'
        )

    def draw(self, context):
        layout = self.layout
        sun = context.world.maxwell.sun

        layout.prop(sun, 'type')
        enabled = (sun.type != '0')

        col = layout.column()
        col.enabled = enabled
        col.prop(sun, 'power')
        col.prop(sun, 'radius')
        row = col.row()
        row.prop(sun, 'temperature')
        row.enabled = (sun.type == '1')
        row = col.row()
        row.prop(sun, 'color')
        row.enabled = (sun.type == '2')
        col.row().prop(sun, 'position', expand=True)
        if sun.position == '0':
            col.prop(sun, 'latitude')
            col.prop(sun, 'longitude')
            col.prop(sun, 'ui_date')
            col.prop(sun, 'ui_time')
            split = col.split(0.33)
            split.label("")
            row = split.row()
            row.prop(sun, 'gmt')
            row.operator('maxwell.environment_datetime_now')
            col.prop(sun, 'rotation')
        elif sun.position == '1':
            col.prop(sun, 'zenith')
            col.prop(sun, 'azimuth')
        elif sun.position == '2':
            split = col.split(0.5)
            subcol = split.column()
            subcol.label("From Object:")
            subcol.prop_search(sun, 'direction_object', context.scene, 'objects', text="", icon='LAMP_POINT')
            subcol = split.column()
            subcol.prop(sun, 'direction', text="")


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_ibl(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Image Based Lighting"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type == 'IBL'
        )

    def draw(self, context):
        layout = self.layout
        ibl = context.world.maxwell.ibl
        layout.prop(ibl, 'intensity')
        layout.prop(ibl, 'interpolation')
        layout.prop(ibl, 'screen_mapping')


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_background(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Background"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type == 'IBL'
        )

    def draw(self, context):
        _ibl_panel(self.layout, context.world.maxwell.ibl.background)


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_reflection(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Reflection"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type == 'IBL'
        )

    def draw(self, context):
        _ibl_panel(self.layout, context.world.maxwell.ibl.reflection)


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_refraction(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Refraction"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type == 'IBL'
        )

    def draw(self, context):
        _ibl_panel(self.layout, context.world.maxwell.ibl.refraction)


@MaxwellRenderEngine.register_class
class MAXWELL_ENVIRONMENT_PT_illumination(WorldButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Illumination"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.world.maxwell.type == 'IBL'
        )

    def draw(self, context):
        _ibl_panel(self.layout, context.world.maxwell.ibl.illumination)

#endregion


#############################
#region Camera

from bl_ui.properties_data_camera import CameraButtonsPanel

_EXPOSURE_PRESETS = None
_RESPONSE_PRESETS = None

def _exposure_presets():
    global _EXPOSURE_PRESETS
    if _EXPOSURE_PRESETS is None:
        from .pymaxwell import Camera
        _EXPOSURE_PRESETS = Camera.ExposurePresets
    return _EXPOSURE_PRESETS

def _response_presets():
    global _RESPONSE_PRESETS
    if _RESPONSE_PRESETS is None:
        from .pymaxwell import Camera
        _RESPONSE_PRESETS = Camera.ResponsePresets
    return _RESPONSE_PRESETS


@MaxwellRenderEngine.register_class
class MAXWELL_CAMERA_MT_exposure(Menu):
    bl_label = "Exposure"
    bl_description = "Exposure preset"

    def draw(self, context):
        layout = self.layout

        op = layout.operator('maxwell.camera_exposure_preset', text="Custom")
        op.index = 0

        for i, name, iso, shutter, fstop in _exposure_presets():
            op = layout.operator('maxwell.camera_exposure_preset', text=name)
            op.index = i
            op.iso = iso
            op.fstop = fstop
            op.shutter = shutter


@MaxwellRenderEngine.register_class
class MAXWELL_CAMERA_MT_response(Menu):
    bl_label = "Response"
    bl_description = "Response preset"

    def draw(self, context):
        layout = self.layout
        for preset in _response_presets():
            op = layout.operator('maxwell.camera_response_preset', text=preset)
            op.preset = preset


@MaxwellRenderEngine.register_class
class MAXWELL_PT_camera(CameraButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Maxwell Camera"

    def draw(self, context):
        layout = self.layout
        camera = context.camera
        mx = camera.maxwell

        if camera.type == 'PERSP':
            split = layout.split(0.33)
            split.label("Lens Type:")
            split.row().prop(mx, 'persp_lens', expand=True)
        elif camera.type == 'PANO':
            layout.prop(mx, 'pano_lens')
            if mx.pano_lens == 'FISH_EYE':
                layout.prop(mx, 'aperture', text="FOV")
            elif mx.pano_lens == 'SPHERICAL':
                layout.prop(mx, 'aperture', text="Azimuth")
            elif mx.pano_lens == 'CYLINDRICAL':
                layout.prop(mx, 'aperture', text="Angle")

        split = layout.split(0.33)
        split.label("Exposure:")
        if mx.exposure > 0:
            exposure = _exposure_presets()[mx.exposure - 1][1]
        else:
            exposure = "Custom"
        split.menu('MAXWELL_CAMERA_MT_exposure', text=exposure)

        split = layout.split(0.33)
        split.label("Shutter:")
        row = split.row(align=True)
        row.prop(mx, 'shutter_type', text="")
        if mx.shutter_type == 'SPEED':
            row.prop(mx, 'shutter', text="")
        elif mx.shutter_type == 'ANGLE':
            row.prop(mx, 'rotary', text="")

        layout.prop(mx, 'fstop')
        layout.prop(mx, 'iso')

        split = layout.split(0.33)
        split.label("Response:")
        split.menu('MAXWELL_CAMERA_MT_response', text=mx.response)

        box = _UiBox(layout, mx, 'ui_diaphragm', "Diaphragm")
        if box is not None:
            col = box.column()
            col.prop(mx, 'diaphragm')
            subcol = col.column(align=True)
            if mx.diaphragm == 'CIRCULAR':
                subcol.enabled = False
            subcol.prop(mx, 'blades')
            subcol.prop(mx, 'angle')

            col.prop(mx, 'custom_bokeh')
            subcol = col.column(align=True)
            if not mx.custom_bokeh:
                subcol.enabled = False
            subcol.prop(mx, 'bokeh_ratio')
            subcol.prop(mx, 'bokeh_angle')


@MaxwellRenderEngine.register_class
class MAXWELL_PT_camera_latlong_stereo(CameraButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Lat-Long Stereo"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            camera = context.camera
            return camera.type == 'PANO' and camera.maxwell.pano_lens == 'LATLONG_STEREO'
        return False

    def draw(self, context):
        layout = self.layout
        camera = context.camera
        mx = camera.maxwell.latlong_stereo

        layout.prop(mx, 'type')
        layout.prop(mx, 'fov_vertical')
        layout.prop(mx, 'fov_horizontal')

        split = layout.split(0.33, align=True)
        split.label("Flip Ray:")
        split.prop(mx, 'flip_ray_x', toggle=True, text="X")
        split.prop(mx, 'flip_ray_y', toggle=True, text="Y")

        layout.prop(mx, 'parallax')
        layout.prop(mx, 'zenith')

        split = layout.split(0.33, align=True)
        split.label("Separation:")
        split.prop(mx, 'separation', text="")
        split.prop_search(mx, 'separation_map', context.blend_data, 'textures', text="")


@MaxwellRenderEngine.register_class
class MAXWELL_PT_camera_fish_stereo(CameraButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Fish Stereo"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            camera = context.camera
            return camera.type == 'PANO' and camera.maxwell.pano_lens == 'FISH_STEREO'
        return False

    def draw(self, context):
        layout = self.layout
        camera = context.camera
        mx = camera.maxwell.fish_stereo

        layout.prop(mx, 'type')
        layout.prop(mx, 'fov')

        split = layout.split(0.33, align=True)
        split.label("Separation:")
        split.prop(mx, 'separation', text="")
        split.prop_search(mx, 'separation_map', context.blend_data, 'textures', text="")

        layout.prop(mx, 'vertical')
        layout.prop(mx, 'dom_radius')
        layout.prop_search(mx, 'turn_map', context.blend_data, 'textures')
        layout.prop(mx, 'dome_tilt_compensation')
        layout.prop(mx, 'dome_tilt')
        layout.prop_search(mx, 'tilt_map', context.blend_data, 'textures')

#endregion


#############################
#region Object

from bl_ui.properties_object import ObjectButtonsPanel
from bl_ui.properties_data_modifier import ModifierButtonsPanel
from bl_ui.properties_data_empty import DataButtonsPanel as EmptyButtonsPanel
from bl_ui.properties_data_lamp import DataButtonsPanel as LampButtonsPanel
from bl_ui.properties_data_mesh import DATA_PT_uv_texture


@MaxwellRenderEngine.register_class
class MAXWELL_UL_object_custom_alphas(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        layout.prop(item, 'name', text="", emboss=False)

        channel_id = item.id
        if channel_id in context.object.maxwell.custom_alphas:
            remove = True
            icon = 'CHECKBOX_HLT'
        else:
            remove = False
            icon = 'CHECKBOX_DEHLT'
        row = layout.row()
        row.alignment = 'RIGHT'
        op = row.operator('maxwell.custom_alpha_object_add', text="", icon=icon, emboss=False)
        op.channel_id = channel_id
        op.remove = remove


@MaxwellRenderEngine.register_class
class MAXWELL_OBJECT_MT_blocked_emitters(Menu):
    bl_label = "Blocked Emitters"

    @classmethod
    def poll(cls, context):
        return context.object

    def draw(self, context):
        layout = self.layout

        mxs = None
        paths = set()
        emitters = set()
        for ob in context.scene.objects:
            for slot in ob.material_slots:
                mx = slot.material.maxwell
                mx_type = mx.type
                if mx_type == 'CUSTOM':
                    for layer in mx.layers:
                        if layer.emitter.enabled:
                            emitters.add(ob.name)
                            break
                    else:
                        continue
                    break
                elif mx_type == 'FILE' and mx.mxm:
                    path = os.path.realpath(bpy.path.abspath(mx.mxm))
                    if path in paths:
                        continue
                    paths.add(path)

                    if mxs is None:
                        from . import pymaxwell

                        mxs = pymaxwell.Scene()

                    mxm = mxs.ReadMaterial(path)
                    for i in range(mxm.NumLayers):
                        layer = mxm.GetLayer(i)
                        emitter = layer.GetEmitter()
                        if not emitter.isNull and emitter.Enabled:
                            emitters.add(ob.name)
                            break
                    else:
                        continue
                    break

        ob = context.object
        emitters.discard(ob.name)
        blocked_emitters = {e.name for e in ob.maxwell.blocked_emitters}
        for name in emitters.difference(blocked_emitters):
            op = layout.operator('maxwell.object_blocked_emitters_add', text=name)
            op.remove_active = False
            op.name = name


@MaxwellRenderEngine.register_class
class MAXWELL_OBJECT_PT_object(ObjectButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Appearance"

    @classmethod
    def poll(cls, context):
        engine = context.scene.render.engine
        return (
            engine in cls.COMPAT_ENGINES and
            context.object.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY'}
        )

    def draw(self, context):
        layout = self.layout
        obj = context.object
        mx = context.object.maxwell

        layout.prop(mx, 'opacity')

        split = layout.split(0.33)
        col = split.column()
        col.separator()
        col.label("Hidden from:")
        col = split.box().column(align=True)
        col.prop(mx, 'hide_to_camera')
        col.prop(mx, 'hide_to_camera_shadow')
        col.prop(mx, 'hide_to_refl_refr')
        col.prop(mx, 'hide_to_gi')
        col.prop(mx, 'ecp', text="Z-clip Planes")

        layout.prop(mx, 'color_id')

        if obj.type != 'EMPTY':
            layout.prop_search(mx, 'backface_material', obj, 'material_slots')

        blocked_emitters = mx.blocked_emitters
        split = layout.split(0.33)
        split.label("Blocked Emitters:")
        row = split.row()
        row.template_list('UI_UL_list',
                          'maxwell.blocked_emitters',
                          mx, 'blocked_emitters',
                          mx, 'active_blocked_emitter_index',
                          rows=2)
        col = row.column(align=True)
        col.menu('MAXWELL_OBJECT_MT_blocked_emitters', text="", icon='ZOOMIN')
        col.operator('maxwell.object_blocked_emitters_add', text="", icon='ZOOMOUT').remove_active = True

        split = layout.split(0.33)
        split.label("Custom Alphas:")
        channels = context.scene.maxwell.render.channels
        split.template_list('MAXWELL_UL_object_custom_alphas', '', channels,
                            'custom_alphas', mx, 'active_custom_alpha_index', rows=2)


_UVSET_ICONS = {
    'PLANAR': 'MATPLANE',
    'SPHERICAL': 'MATSPHERE',
    'CYLINDRICAL': 'MESH_CYLINDER',
    'CUBIC': 'MATCUBE',
    'LOCKED': 'TEXTURE'
}


@MaxwellRenderEngine.register_class
class MAXWELL_UL_uvsets(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        label = " %s : %s" % (item.channel, item.type_label)
        t = item.type
        if t == 'LOCKED':
            label += " : %s" % item.name
        layout.label(label, icon=_UVSET_ICONS.get(t, 'BLANK1'))


@MaxwellRenderEngine.register_class
class MAXWELL_OBDATA_PT_uvsets(_MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'
    bl_label = "UV Sets"

    @classmethod
    def poll(cls, context):
        engine = context.scene.render.engine
        return (
            engine in cls.COMPAT_ENGINES and
            context.mesh or context.curve or context.meta_ball
        )

    def draw_header(self, context):
        super().draw_header(context)
        self.layout.prop(context.object.data.maxwell, 'use_projections', text="")

    def draw(self, context):
        layout = self.layout
        id_data = context.object.data
        mx = id_data.maxwell

        layout.enabled = mx.use_projections

        row = layout.row()
        row.template_list('MAXWELL_UL_uvsets', '', mx, 'projections',
                          mx, 'active_projection_index', rows=2)
        col = row.column(align=True)
        col.operator('maxwell.obdata_uvsets_add', icon='ZOOMIN', text="")
        col.operator('maxwell.obdata_uvsets_remove', icon='ZOOMOUT', text="")

        projections = mx.projections
        i = mx.active_projection_index
        if 0 <= i < len(projections):
            p = projections[i]
            p_type = p.type
            layout.prop(p, "channel")
            layout.prop(p, 'type')
            if p_type == 'LOCKED':
                layout.prop_search(p, 'name', context.mesh, 'uv_layers', icon='GROUP_UVS')
            else:
                layout.prop_search(p, 'object', context.scene, 'objects')
                row = layout.row()
                row.enabled = not bool(p.object)
                row.column().prop(p, 'position')
                row.column().prop(p, 'rotation')
                row.column().prop(p, 'scale')
                if p_type == 'SPHERICAL':
                    row = layout.row()
                    row.column().prop(p, 'latitude')
                    row.column().prop(p, 'longitude')
                elif p_type == 'CYLINDRICAL':
                    row = layout.row()
                    row.prop(p, 'angle')

    def draw_panel(self, context):
        if context.mesh.uv_layers.active:
            layout = self.layout
            col = layout.column()
            col.label("Headus UVLayout:")
            row = col.row(align=True)
            row.operator('headus_uvlayout.export')
            row.operator('headus_uvlayout.import')

    @classmethod
    def register(cls):
        DATA_PT_uv_texture.append(cls.draw_panel)

    @classmethod
    def unregister(cls):
        DATA_PT_uv_texture.remove(cls.draw_panel)


@MaxwellRenderEngine.register_class
class MAXWELL_OBDATA_PT_object(EmptyButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Object"

    @classmethod
    def poll(cls, context):
        engine = context.scene.render.engine
        return super().poll(context) and engine in cls.COMPAT_ENGINES

    def draw(self, context):
        layout = self.layout
        ob = context.object
        mx = ob.maxwell

        layout.prop(mx, 'type')
        mx_type = mx.type
        if mx_type == 'REFERENCE':
            r = mx.reference
            layout.prop(r, 'path', text="File (.mxs)")
            layout.prop_search(r, 'material', context.blend_data, 'materials')
            box = _UiBox(layout, r, 'ui_flags', "Override Flags")
            if box is not None:
                col = box.column()
                split = col.split(0.33)
                col1 = split.column()
                col1.alignment = 'RIGHT'
                col1.label("Hidden:")
                col1.label("Hidden from:")
                col2 = split.column()
                col2.prop(r, 'flag_hidden', text="")
                col2.prop(r, 'flag_camera')
                col2.prop(r, 'flag_rr')
                col2.prop(r, 'flag_gi')
        elif mx_type == 'ASSET':
            r = mx.reference
            layout.prop(r, 'path')
            layout.prop(r, 'axis')
            layout.prop_search(r, 'material', context.blend_data, 'materials')
        elif mx_type == 'VOLUMETRIC':
            v = mx.volumetric
            layout.prop(v, 'field_type')
            layout.prop_search(v, 'material', context.blend_data, 'materials')
            if v.field_type == 'OPENVDB':
                g = v.vdb_grid
                layout.prop(v, 'vdb_file')
                layout.prop(v, 'vdb_axis')
                layout.prop(g, 'base_grid')
                layout.prop(g, 'multiplier')
                _draw_uvgrids(layout, g)
            else:
                layout.prop(v, 'field_density')
                if v.field_type == 'NOISE':
                    layout.prop(v, 'seed')
                    layout.prop(v, 'low_value')
                    layout.prop(v, 'high_value')
                    layout.prop(v, 'detail')
                    layout.prop(v, 'octaves')
                    layout.prop(v, 'persistence')
                if ob.parent:
                    layout.operator('maxwell.object_volumetric_adjust')


@MaxwellRenderEngine.register_class
class MAXWELL_OBDATA_PT_sea(ModifierButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_options = {'DEFAULT_CLOSED'}
    bl_label = "Sea Extension"

    @classmethod
    def poll(cls, context):
        return (
            context.scene.render.engine in cls.COMPAT_ENGINES and
            context.object.type == 'MESH'
        )

    def draw_header(self, context):
        super().draw_header(context)
        self.layout.prop(context.object.data.maxwell.sea, 'enabled', text="")

    def draw(self, context):
        layout = self.layout
        mesh = context.object.data
        sea = mesh.maxwell.sea

        layout.enabled = sea.enabled
        layout.prop_search(sea, 'material', mesh, 'materials')

        box = _UiBox(layout, sea, 'ui_geometry', "Geometry")
        if box is not None:
            col = box.column()
            col.prop(sea, 'quality')
            col.prop(sea, 'time')
            col.prop(sea, 'vertical_scale')
            col.prop(sea, 'dimension')
            col.prop(sea, 'depth')
            col.prop(sea, 'seed')
            col.prop(sea, 'choppyness')
            col.prop(sea, 'choppy_factor')
            col.prop(sea, 'repeat_u')
            col.prop(sea, 'repeat_v')

        box = _UiBox(layout, sea, 'ui_wind', "Wind")
        if box is not None:
            col = box.column()
            col.prop(sea, 'wind_speed')
            col.prop(sea, 'wind_direction')
            col.prop(sea, 'weight_against_wind')
            col.prop(sea, 'wind_alignment')
            col.prop(sea, 'min_wave_length')

        box = _UiBox(layout, sea, 'ui_mesh_cache', "Mesh Cache")
        if box is not None:
            col = box.column()
            box.prop(sea, 'mc_modifier')
            box.prop(sea, 'mc_file')
            box.prop(sea, 'mc_quality')
            box.row().prop(sea, 'mc_frames')

        row = layout.row(align=True)
        row.operator('maxwell.sea_import', text="Import").action = 'SINGLE_FRAME'
        row.operator('maxwell.sea_import', text="Bake").action = 'FRAMES_RANGE'


@MaxwellRenderEngine.register_class
class MAXWELL_PT_lamp(LampButtonsPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Emitter"

    def draw(self, context):
        layout = self.layout
        lamp = context.lamp
        layout.prop(lamp, 'type', expand=True)
        #_draw_emitter(layout, lamp, lamp.maxwell.emitter)
        pass

#endregion


#############################
#region Extensions

from bl_ui.properties_particle import ParticleButtonsPanel
from bl_ui.properties_physics_smoke import PhysicButtonsPanel


@MaxwellRenderEngine.register_class
class MAXWELL_MT_grass_presets(Menu):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Preset"

    preset_operator = 'script.execute_preset'
    preset_subdir = "bmaxwell/particles/grass"

    draw = Menu.draw_preset


@MaxwellRenderEngine.register_class
class MAXWELL_PT_particles(ParticleButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Extension"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            pss = context.particle_system.settings
            if pss.type == 'HAIR':
                return pss.render_type == 'PATH'
            elif pss.type == 'EMITTER':
                return pss.render_type in {'HALO', 'LINE', 'PATH'}
        return False

    def draw(self, context):
        layout = self.layout
        pss = context.particle_system.settings
        mx = pss.maxwell
        if pss.type == 'HAIR':
            if pss.render_type == 'PATH':
                layout.prop(mx, 'h_type', expand=True)
                if mx.h_type == 'HAIR':
                    h = mx.hair
                    row = layout.row(align=True)
                    row.prop(h, 'root')
                    row.prop(h, 'tip')
                    row = layout.row()
                    row.prop_search(h, 'uv_map', context.object.data, 'uv_textures')
                elif mx.h_type == 'GRASS':
                    g = mx.grass
                    row = layout.row(align=True)
                    row.menu('MAXWELL_MT_grass_presets')
                    row.operator('maxwell.grass_preset_add', text="", icon='ZOOMIN')
                    row.operator('maxwell.grass_preset_add', text="", icon='ZOOMOUT').remove_active = True
                    # Primitive
                    row = layout.row()
                    row.prop(g, 'type')
                    row.prop(g, 'blade_points')
                    layout.prop_search(g, 'backface', context.object, 'material_slots')
                    # Grass Density
                    layout.prop_search(g, 'density_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'density')
                    row.prop(g, 'seed')
                    # Blade Length
                    layout.prop_search(g, 'length_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'length')
                    row.prop(g, 'length_var', text="Variation")
                    # Width
                    row = layout.row()
                    row.label("Width:")
                    subrow = row.row(align=True)
                    subrow.prop(g, 'root_width', text="Root")
                    subrow.prop(g, 'tip_width', text="Tip")
                    # Angle
                    row = layout.row()
                    row.label("Angle direction:")
                    row.prop(g, 'direction', expand=True)
                    layout.prop_search(g, 'angle_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'angle')
                    row.prop(g, 'angle_var', text="Variation")
                    # Bend
                    layout.prop_search(g, 'start_bend_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'start_bend')
                    row.prop(g, 'start_bend_var', text="Variation")
                    layout.prop_search(g, 'bend_radius_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'bend_radius')
                    row.prop(g, 'bend_radius_var', text="Variation")
                    layout.prop_search(g, 'bend_angle_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'bend_angle')
                    row.prop(g, 'bend_angle_var', text="Variation")
                    # Cut off
                    layout.prop_search(g, 'cut_off_map', pss, 'texture_slots')
                    row = layout.row(align=True)
                    row.prop(g, 'cut_off')
                    row.prop(g, 'cut_off_var', text="Variation")
                    # Level of Detail
                    row = layout.row()
                    row.prop(g, 'lod_enabled')
                    col = row.column(align=True)
                    col.enabled = g.lod_enabled
                    row = col.row(align=True)
                    row.prop(g, 'lod_min')
                    row.prop(g, 'lod_max')
                    row = col.row(align=True)
                    row.prop(g, 'lod_max_density')
                    # Display
                    row = layout.row(align=True)
                    row.prop(g, 'display_percent', text="Display")
                    row.prop(g, 'display_blades', text="Max. Blades")
                    layout.separator()
                    layout.operator('maxwell.grass_import')
        elif pss.type == 'EMITTER':
            if pss.render_type in {'HALO', 'LINE', 'PATH'}:
                layout.prop(mx, 'p_type', expand=True)

                if mx.p_type == 'MESHER':
                    box = _UiBox(layout, mx, 'ui_binfile', "Particles .bin File")
                    if box is not None:
                        col = box.column()
                        col.prop(mx, 'overwrite_binfile')
                        col.prop(mx, 'binfile', text="")

                    m = mx.mesher
                    layout.prop(m, 'mesher')

                    # System parameters
                    layout.prop(m, 'threads')

                    # Sequence
                    box = _UiBox(layout, m, 'ui_sequence', "Sequence")
                    if box is not None:
                        col = box.column()
                        col.prop(m, 'radius')
                        col.prop(m, 'core')
                        col.prop(m, 'splash')
                        col.prop(m, 'velocity')

                    # Mesh Optimization
                    box = _UiBox(layout, m, 'ui_optimization', "Mesh Optimization")
                    if box is not None:
                        col = box.column()
                        col.prop(m, 'optimize')
                        col.prop(m, 'distance')

                    # Mesh Parameters
                    box = _UiBox(layout, m, 'ui_params', "Mesh Parameters")
                    if box is not None:
                        col = box.column()
                        col.prop(m, 'field_type')
                        col.prop(m, 'poly')
                        col.prop(m, 'wn')
                        col.prop(m, 'smooth')
                        col.prop(m, 'iso_level')
                        col.prop(m, 'fix_bbox')

                    # Mesh filter
                    box = _UiBox(layout, m, 'ui_filter', "Mesh Filtering")
                    if box is not None:
                        box.prop(m, 'filter')
                        col = box.column()
                        col.enabled = m.filter
                        col.prop(m, 'relax')
                        col.prop(m, 'tension')
                        col.prop(m, 'thinning')
                        col.prop(m, 'steps')
                        col.prop(m, 'splash_thinning')
                        col.prop(m, 'splash_threshold')
                        col.prop(m, 'thinning_size')
                        col.prop(m, 'core_smooth')
                        col.prop(m, 'core_threshold')
                        col.prop(m, 'smooth_steps')

                    # Export and lazy compute
                    box = _UiBox(layout, m, 'ui_export', "Export and lazy compute")
                    if box is not None:
                        col = box.column()
                        col.prop(m, 'action')
                        col.prop(m, 'md_file')
                        col.prop(m, 'md_offset')
                        col.prop(m, 'md_compression')
                        col.prop(m, 'md_normals')
                else:
                    box = _UiBox(layout, mx, 'ui_binfile', "Particles .bin File")
                    if box is not None:
                        col = box.column()
                        row = col.row()
                        row.prop(mx, 'use_binfile')
                        row = row.row()
                        row.enabled = mx.use_binfile
                        row.prop(mx, 'overwrite_binfile')
                        row = col.row()
                        row.enabled = mx.use_binfile
                        col.prop(mx, 'binfile', text="")

                    if mx.p_type == 'PARTICLES':
                        p = mx.particles
                        layout.prop(p, 'radius')
                        layout.prop(p, 'motion_blur')
                        layout.prop(p, 'shutter_speed')
                        col = layout.column(align=True)
                        col.prop(p, 'extra_particles')
                        row = col.row(align=True)
                        row.prop(p, 'extra_dispersion')
                        row.prop(p, 'extra_deformation')
                    elif mx.p_type == 'VOLUMETRIC':
                        v = mx.volumetric
                        col = layout.column(align=True)
                        col.prop(v, 'load_particles')
                        col.prop(v, 'radius_factor')
                        col.prop(v, 'cell_size')
                        col = layout.column(align=True)
                        col.prop(v, 'density_scale')
                        row = col.row(align=True)
                        row.prop(v, 'min_density', text="Min")
                        row.prop(v, 'max_density', text="Max")
                        col = layout.column(align=True)
                        col.prop(v, 'extra_particles')
                        row = col.row(align=True)
                        row.prop(v, 'extra_dispersion')
                        row.prop(v, 'extra_deformation')
                        col = layout.column(align=True)
                        col.prop(v, 'motion_blur_factor')
                        col.prop(v, 'shutter_speed')


@MaxwellRenderEngine.register_class
class MAXWELL_PT_scatter(ParticleButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Scatter Extension"

    @classmethod
    def poll(cls, context):
        if super().poll(context):
            pss = context.particle_system.settings
            return (
                pss.type == 'HAIR' and
                pss.render_type == 'OBJECT'
            )
        return False

    def draw_header(self, context):
        mx = context.particle_system.settings.maxwell.scatter
        super().draw_header(context)
        self.layout.prop(mx, 'enabled', text="")

    def draw(self, context):
        pss = context.particle_system.settings
        s = pss.maxwell.scatter

        layout = self.layout
        layout.enabled = s.enabled

        layout.prop(s, 'inherit_oid')

        row = layout.row(align=True)
        row.prop(s, 'density')
        row.prop_search(s, 'density_map', pss, 'texture_slots', text="")

        row = layout.row(align=True)
        row.prop(s, 'remove_overlaps')
        row.prop(s, 'seed')

        row = layout.row()
        col = row.column(align=True)
        col.prop(s, 'scale')
        col = row.column(align=True)
        col.prop(s, 'scale_var')
        layout.prop_search(s, 'scale_map', pss, 'texture_slots')
        layout.prop(s, 'uniform_scale')

        row = layout.row()
        col = row.column(align=True)
        col.prop(s, 'rotation')
        col = row.column(align=True)
        col.prop(s, 'rotation_var')
        layout.prop_search(s, 'rotation_map', pss, 'texture_slots')
        layout.prop(s, 'direction')


@MaxwellRenderEngine.register_class
class MAXWELL_UL_vdb_grids(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index=0, flt_flag=0):
        row = layout.row(align=True)
        row.prop(item, 'name', text="", emboss=False)
        row.prop(item, 'base_grid', text="", emboss=False)


@MaxwellRenderEngine.register_class
class MAXWELL_PT_volumetric(PhysicButtonsPanel, _MaxwellPanel, Panel):
    COMPAT_ENGINES = {MaxwellRenderEngine.bl_idname}
    bl_label = "Volumetric Extensions"

    @classmethod
    def poll(cls, context):
        return (
            super().poll(context) and
            context.smoke.domain_settings and
            context.smoke.domain_settings.cache_file_format == 'OPENVDB'
        )

    def draw(self, context):
        layout = self.layout
        ob = context.object
        mx = ob.maxwell.volumetric

        row = layout.row()
        row.template_list('MAXWELL_UL_vdb_grids', '', mx, 'vdb_grids',
                          mx, 'active_vdb_grid_index', rows=2)
        col = row.column(align=True)
        col.operator('maxwell.vdb_grids_add', icon='ZOOMIN', text="")
        col.operator('maxwell.vdb_grids_remove', icon='ZOOMOUT', text="")

        grids = mx.vdb_grids
        i = mx.active_vdb_grid_index
        if 0 <= i < len(grids):
            grid = grids[i]
            col = layout.column()
            row = col.row()
            row.label("VDB Grid:")
            row = row.row(align=True)
            row.prop(grid, 'base_grid', text="")
            row.prop(grid, 'multiplier', text="Multiplier")
            col.prop_search(grid, 'material', ob, 'material_slots')

            _draw_uvgrids(layout, grid)
            #box = _UiBox(layout, grid, 'ui_uv_grids', "Additional grids for UV")
            #if box is not None:
            #    col = box.column()
            #    row = col.row()
            #    row.template_list('UI_UL_list', 'MAXWELL_uv_grids', grid, 'uv_grids',
            #                      grid, 'active_uv_grid_index', rows=2)
            #    subcol = row.column(align=True)
            #    subcol.operator('maxwell.vdb_uv_grids_add', icon='ZOOMIN', text="")
            #    subcol.operator('maxwell.vdb_uv_grids_remove', icon='ZOOMOUT', text="")

            #    uv_grids = grid.uv_grids
            #    i = grid.active_uv_grid_index
            #    if 0 <= i < len(uv_grids):
            #        uv_grid = uv_grids[i]
            #        row = col.row(align=True)
            #        row.prop(uv_grid, 'type', text="")
            #        row.prop(uv_grid, 'range', index=0, text="Min")
            #        row.prop(uv_grid, 'range', index=1, text="Max")

#endregion
