# -*- coding: utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Ildar Nikolaev"
__email__ = "nildar@users.sourceforge.net"

bl_info = {
    'name'          : "B-Maxwell",
    'description'   : "Maxwell Render integration",
    'author'        : "N.Ildar <nildar@users.sourceforge.net>",
    'version'       : (0, 9, 4),
    'blender'       : (2, 78, 0),
    'location'      : "Info header, render engine menu",
    'warning'       : "Use only with Blender version 2.78",
    'wiki_url'      : "http://sourceforge.net/p/bmaxwell/wiki/",
    'tracker_url'   : "https://sourceforge.net/p/bmaxwell/tickets/",
    'category'      : "Render"
}

import os
import sys
import time
import types
import importlib.abc
import importlib.util

import bpy
import bl_ui


class MaxwellRenderEngine(bpy.types.RenderEngine):
    bl_idname = 'maxwell_render'
    bl_label = "Maxwell Render"

    bl_use_preview = True
    bl_use_texture_preview = True

    PREVIEW_START = 1.0
    PREVIEW_STARTED = -1.0

    _CLASSES = []
    _COMPATIBLE_PANELS = (
        ('properties_render', ((
            'RENDER_PT_render',
            'RENDER_PT_dimensions',
            'RENDER_PT_output',
            'RENDER_PT_post_processing',
        ), False)),
        ('properties_render_layer', None),
        ('properties_scene', None),
        ('properties_world', ((
            'WORLD_PT_context_world',
            'WORLD_PT_custom_props',
        ), False)),
        ('properties_data_camera', None),
        ('properties_data_mesh', None),
        ('properties_data_lamp', ((
            'DATA_PT_context_lamp',
            #'DATA_PT_preview',
            'DATA_PT_area',
        ), False)),
        ('properties_material', ((
            'MATERIAL_PT_custom_props',
        ), False)),
        ('properties_texture', None),
        #('properties_texture', ((
        #    'TEXTURE_PT_context_texture',
        #    'TEXTURE_PT_preview',
        #    'TEXTURE_PT_image',
        #    'TEXTURE_PT_custom_props',
        #), False)),
        ('properties_particle', None),
        ('properties_physics_common', None),
        ('properties_physics_cloth', None),
        ('properties_physics_dynamicpaint', None),
        ('properties_physics_field', None),
        ('properties_physics_fluid', None),
        ('properties_physics_rigidbody', None),
        ('properties_physics_rigidbody_constraint', None),
        ('properties_physics_smoke', None),
        ('properties_physics_softbody', None),
    )

    def __init__(self):
        engine.create(self)

    def update(self, data, scene):
        engine.update(self, data, scene)

    def render(self, scene):
        engine.render(self, scene)

    def view_update(self, context):
        engine.view_update(self, context)

    def view_draw(self, context):
        engine.view_draw(self, context)

    def __del__(self):
        engine.free(self)

    @classmethod
    def is_active(cls, context):
        return context.scene.render.engine == cls.bl_idname

    @classmethod
    def register_class(cls, rcls):
        cls._CLASSES.append(rcls)
        return rcls

    @classmethod
    def _compatible(cls, mod, panels, remove=False):
        mod = getattr(bl_ui, mod)
        if panels is None:
            for c in mod.__dict__.values():
                ce = getattr(c, 'COMPAT_ENGINES', None)
                if ce is not None:
                    if remove:
                        ce.remove(cls.bl_idname)
                    else:
                        ce.add(cls.bl_idname)
        else:
            classes, exclude = panels
            if exclude:
                for c in mod.__dict__.values():
                    if c.__name__ not in classes:
                        ce = getattr(c, 'COMPAT_ENGINES', None)
                        if ce is not None:
                            if remove:
                                ce.remove(cls.bl_idname)
                            else:
                                ce.add(cls.bl_idname)
            else:
                for c in classes:
                    ce = getattr(mod, c).COMPAT_ENGINES
                    if remove:
                        ce.remove(cls.bl_idname)
                    else:
                        ce.add(cls.bl_idname)

    @classmethod
    def register(cls):
        from bpy.utils import register_class

        ui.register_icons()

        for _cls in cls._CLASSES:
            register_class(_cls)

        for mod, panels in cls._COMPATIBLE_PANELS:
            cls._compatible(mod, panels)

    @classmethod
    def unregister(cls):
        from bpy.utils import unregister_class

        for mod, panels in cls._COMPATIBLE_PANELS:
            cls._compatible(mod, panels, True)

        for _cls in cls._CLASSES:
            unregister_class(_cls)

        ui.unregister_icons()


@MaxwellRenderEngine.register_class
class BMaxwellPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    if sys.platform == 'win32':
        _MXED = "mxed.exe"
        _STUDIO = "studio.exe"
        _MAXWELL = "maxwell.exe"
        _MXNETWORK = "mxnetwork.exe"
    elif sys.platform == 'darwin':
        _MXED = "Mxed.app/Contents/MacOS/Mxed"
        _STUDIO = "Studio.app"
        _MAXWELL = "Maxwell.app"
        _MXNETWORK = "Mxnetwork.app"
    else:  # linux
        _MXED = "mxed"
        _STUDIO = "studio"
        _MAXWELL = "maxwell"
        _MXNETWORK = "mxnetwork"

    maxwell_path = bpy.props.StringProperty(
        name="Maxwell Render Location",
        description="Path there is Maxwell Render installed",
        default=os.environ.get('MAXWELL3_ROOT', "/Applications/Maxwell 3" if sys.platform == 'darwin' else ""),
        subtype='DIR_PATH'
    )
    maxwell_license = bpy.props.StringProperty(
        name="License File",
        subtype='FILE_PATH'
    )
    verbose_output = bpy.props.BoolProperty(
        name="Verbose",
        description="Verbose output to console",
        default=True
    )
    instances_name_format = bpy.props.StringProperty(
        name="Format string for names of instances",
        default="[I:{1:07}] {0}"
    )
    uvlayout_path = bpy.props.StringProperty(
        name="UVLayout Location",
        description="Path there is Headus UVLayout installed",
        subtype='DIR_PATH'
    )

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, 'maxwell_path')
        col.prop(self, 'maxwell_license')
        col.prop(self, 'instances_name_format')
        col.prop(self, 'uvlayout_path')
        col.prop(self, 'verbose_output')

    @classmethod
    def prefs(cls, context=None):
        if context is None:
            context = bpy.context
        return context.user_preferences.addons[cls.bl_idname].preferences

    def mxpath(self, *join):
        path = bpy.path.abspath(self.maxwell_path)
        return path if not join else os.path.join(path, *join)

    @property
    def MXED(self):
        return self.mxpath(self._MXED)

    @property
    def STUDIO(self):
        return self.mxpath(self._STUDIO)

    @property
    def MAXWELL(self):
        return self.mxpath(self._MAXWELL)


def register():
    bpy.utils.register_class(MaxwellRenderEngine)
    bpy.utils.register_manual_map(_manual_map)

def unregister():
    bpy.utils.unregister_class(MaxwellRenderEngine)
    bpy.utils.unregister_manual_map(_manual_map)

def _manual_map():
    try:
        import inspect
        # brrrrr.......
        stack = inspect.stack()
        rna_id = stack[2][0].f_locals['rna_id']
        for m in manual.special_map:
            if rna_id in m[0]:
                return m[1], (("*", m[2]), )
    except:
        pass
    return manual.url_manual_prefix, manual.url_manual_mapping

def _register_binding(cls):
    try:
        sys.meta_path.remove(_MaxwellBindingImporter.instance)
        reload = True
    except ValueError:
        # instance already removed
        reload = True
    except NameError:
        # _MaxwellBindingImporter is not defined yet
        reload = False

    cls.instance = cls()
    sys.meta_path.append(cls.instance)

    if reload:
        global props, ops, ui, engine, manual
        for m in (props, ops, ui, engine, manual):
            importlib.reload(m)
    else:
        from . import props, ops, ui, engine, manual

    return cls


@_register_binding
class _MaxwellBindingImporter(importlib.abc.MetaPathFinder,
                              importlib.abc.Loader):
    module_name = __name__ + ".pymaxwell"
    instance = None

    class _Module(types.ModuleType):
        pass

    class _Loader(types.ModuleType):
        def __getattribute__(self, attr):
            path = BMaxwellPreferences.prefs().mxpath()

            logger = engine.Logger()
            logger("Loading M~R binding (%s)" % path)

            if sys.platform == 'win32':
                from ctypes import windll, create_unicode_buffer

                kernel32 = windll.kernel32
                size = kernel32.GetDllDirectoryW(0, None)
                if size > 0:
                    directory = create_unicode_buffer(size + 1)
                    kernel32.GetDllDirectoryW(size + 1, directory)
                else:
                    directory = None
                kernel32.SetDllDirectoryW(path)
                try:
                    pymaxwell = importlib.import_module('._pymaxwell', __name__)
                finally:
                    kernel32.SetDllDirectoryW(directory)
            else:
                if sys.platform == 'darwin':
                    lib = "libmx_common.dylib"
                else:
                    lib = "libmxcommon.so"
                lib_path = os.path.join(path, lib)
                link_path = os.path.join(os.path.dirname(__file__), lib)
                if os.path.islink(link_path):
                    if link_path != lib_path:
                        os.unlink(link_path)
                        os.symlink(lib_path, link_path)
                else:
                    os.symlink(lib_path, link_path)
                pymaxwell = importlib.import_module('._pymaxwell', __name__)

            logger("Binding loaded (Engine: v%s, SDK: v%s)" % (
                pymaxwell.engine_version(), pymaxwell.sdk_version()
            ))
            pymaxwell.init_extensions(os.path.join(path, "extensions"))

            self.__class__ = pymaxwell.__class__
            self.__dict__.update(pymaxwell.__dict__)
            return getattr(self, attr)

    def find_spec(self, fullname, path, target=None):
        if fullname == self.module_name:
            return importlib.util.spec_from_loader(fullname, self)
        return None

    def create_module(self, spec):
        return self._Module(spec.name)

    def exec_module(self, module):
        module.__class__ = self._Loader
