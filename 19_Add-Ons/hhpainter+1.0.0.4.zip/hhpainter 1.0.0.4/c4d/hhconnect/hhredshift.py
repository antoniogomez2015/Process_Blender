#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import c4d
import os
try:
    import redshift
except:
    pass

REDSHIFT_SHADER_NETWORK = 1036224



def rsCreate(arg_path,arg_mat,arg_ext,arg_normal):

    doc = c4d.documents.GetActiveDocument()

    #Material
    mat = c4d.BaseMaterial(REDSHIFT_SHADER_NETWORK)
    if mat is None:
        raise Exception("Failed to create material")
    mat.SetName("RS_"+arg_mat.replace(' ','_'))
    doc.InsertMaterial(mat)

    gvNodeMaster = redshift.GetRSMaterialNodeMaster(mat)
    root = gvNodeMaster.GetRoot()

    #Nodes
    output = root.GetDown()

    rsmat = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), 0, 100)
    rsmat[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Material"


    basecolor = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 0)
    basecolor[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    roughness = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 100)
    roughness[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    metalness = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 200)
    metalness[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    normal = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 300)
    normal[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "NormalMap"

    disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 800)
    disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Displacement"

    tx_disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -400, 800)
    tx_disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    #Parameters
    rsmat[c4d.ID_BASELIST_NAME] = "Material"
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_BRDF] = 1
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_FRESNEL_MODE] = 2

    basecolor[c4d.ID_BASELIST_NAME] = "tx_basecolor"
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_basecolor."+arg_ext
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

    roughness[c4d.ID_BASELIST_NAME] = "tx_roughness"
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_roughness."+arg_ext
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    metalness[c4d.ID_BASELIST_NAME] = "tx_metalness"
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_metallic."+arg_ext
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    normal[c4d.ID_BASELIST_NAME] = "tx_normal"
    normal[c4d.REDSHIFT_SHADER_NORMALMAP_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_normal."+arg_ext
    if int(arg_normal) == 1:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 0
    else:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 1

    tx_disp[c4d.ID_BASELIST_NAME] = "tx_disp"
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_height."+arg_ext
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    disp[c4d.ID_BASELIST_NAME] = "displacement"
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_SCALE] = 0.1
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MIN] = - 0.5
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MAX] = 0.5

    #Ports
    output.AddPort(c4d.GV_PORT_INPUT,id= c4d.GV_REDSHIFT_OUTPUT_DISPLACEMENT,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_DIFFUSE_COLOR,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_ROUGHNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_METALNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_BUMP_INPUT,message=True)
    disp.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_DISPLACEMENT_TEXMAP,message=True)


    #Connections
    rsmat.GetOutPort(0).Connect(output.GetInPort(0))
    basecolor.GetOutPort(0).Connect(rsmat.GetInPort(0))
    roughness.GetOutPort(0).Connect(rsmat.GetInPort(1))
    metalness.GetOutPort(0).Connect(rsmat.GetInPort(2))
    normal.GetOutPort(0).Connect(rsmat.GetInPort(3))
    tx_disp.GetOutPort(0).Connect(disp.GetInPort(0))
    disp.GetOutPort(0).Connect(output.GetInPort(1))


    path_emissive = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
    if os.path.isfile(path_emissive):
        emissive = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 400)
        emissive[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        rsmat[c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_WEIGHT] = 2

        emissive[c4d.ID_BASELIST_NAME] = "tx_emissive"
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_COLOR,message=True)

        emissive.GetOutPort(0).Connect(rsmat.GetInPort(4))


    path_opacity = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
    if os.path.isfile(path_opacity):
        opacity = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 500)
        opacity[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        opacity[c4d.ID_BASELIST_NAME] = "tx_opacity"
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_OPACITY_COLOR,message=True)

        opacity.GetOutPort(0).Connect(rsmat.GetInPort(rsmat.GetInPortCount() - 1))

    #Redraw
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)

def rsCreatePkd(arg_path,arg_mat,arg_ext,arg_normal):

    doc = c4d.documents.GetActiveDocument()

    #Material
    mat = c4d.BaseMaterial(REDSHIFT_SHADER_NETWORK)
    if mat is None:
        raise Exception("Failed to create material")
    mat.SetName("RS_"+arg_mat.replace(' ','_'))
    doc.InsertMaterial(mat)

    gvNodeMaster = redshift.GetRSMaterialNodeMaster(mat)
    root = gvNodeMaster.GetRoot()

    #Nodes
    output = root.GetDown()

    rsmat = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), 0, 100)
    rsmat[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Material"

    basecolor = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 0)
    basecolor[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    aoroughmetal = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -500, 100)
    aoroughmetal[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    aoroughmetal_split = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -300, 100)
    aoroughmetal_split[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "RSColorSplitter"

    normal = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 300)
    normal[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "NormalMap"

    disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 800)
    disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Displacement"

    tx_disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -400, 800)
    tx_disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    #Parameters
    rsmat[c4d.ID_BASELIST_NAME] = "Material"
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_BRDF] = 1
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_FRESNEL_MODE] = 2

    basecolor[c4d.ID_BASELIST_NAME] = "tx_basecolor"
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_basecolor."+arg_ext
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

    aoroughmetal[c4d.ID_BASELIST_NAME] = "tx_aoroughmetal"
    aoroughmetal[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_aoroughmetal."+arg_ext
    aoroughmetal[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    aoroughmetal[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    aoroughmetal[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    aoroughmetal_split[c4d.ID_BASELIST_NAME] = "aoroughmetal_split"

    normal[c4d.ID_BASELIST_NAME] = "tx_normal"
    normal[c4d.REDSHIFT_SHADER_NORMALMAP_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_normal."+arg_ext
    if int(arg_normal) == 1:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 0
    else:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 1

    tx_disp[c4d.ID_BASELIST_NAME] = "tx_disp"
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_height."+arg_ext
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    disp[c4d.ID_BASELIST_NAME] = "displacement"
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_SCALE] = 0.1
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MIN] = - 0.5
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MAX] = 0.5

    #Ports
    output.AddPort(c4d.GV_PORT_INPUT,id= c4d.GV_REDSHIFT_OUTPUT_DISPLACEMENT,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_DIFFUSE_COLOR,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_ROUGHNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_METALNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_BUMP_INPUT,message=True)
    disp.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_DISPLACEMENT_TEXMAP,message=True)


    #Connections
    rsmat.GetOutPort(0).Connect(output.GetInPort(0))
    basecolor.GetOutPort(0).Connect(rsmat.GetInPort(0))
    aoroughmetal.GetOutPort(0).Connect(aoroughmetal_split.GetInPort(0))
    aoroughmetal_split.GetOutPort(1).Connect(rsmat.GetInPort(1))
    aoroughmetal_split.GetOutPort(2).Connect(rsmat.GetInPort(2))
    normal.GetOutPort(0).Connect(rsmat.GetInPort(3))
    tx_disp.GetOutPort(0).Connect(disp.GetInPort(0))
    disp.GetOutPort(0).Connect(output.GetInPort(1))


    path_emissive = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
    if os.path.isfile(path_emissive):
        emissive = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 400)
        emissive[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        rsmat[c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_WEIGHT] = 2

        emissive[c4d.ID_BASELIST_NAME] = "tx_emissive"
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_COLOR,message=True)

        emissive.GetOutPort(0).Connect(rsmat.GetInPort(4))


    path_opacity = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
    if os.path.isfile(path_opacity):
        opacity = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 500)
        opacity[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        opacity[c4d.ID_BASELIST_NAME] = "tx_opacity"
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_OPACITY_COLOR,message=True)

        opacity.GetOutPort(0).Connect(rsmat.GetInPort(rsmat.GetInPortCount() - 1))

    #Redraw
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)



def rsCreateUdims(arg_path,arg_mesh,arg_mats,arg_ext,arg_normal):

    doc = c4d.documents.GetActiveDocument()

    #Material
    mat = c4d.BaseMaterial(REDSHIFT_SHADER_NETWORK)
    if mat is None:
        raise Exception("Failed to create material")
    mat.SetName("RS_"+arg_mesh.replace(' ','_'))
    doc.InsertMaterial(mat)

    gvNodeMaster = redshift.GetRSMaterialNodeMaster(mat)
    root = gvNodeMaster.GetRoot()

    #Nodes
    output = root.GetDown()

    rsmat = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), 0, 100)
    rsmat[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Material"


    basecolor = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 0)
    basecolor[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    roughness = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 100)
    roughness[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    metalness = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 200)
    metalness[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    normal = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 300)
    normal[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "NormalMap"

    disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 800)
    disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "Displacement"

    tx_disp = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -400, 800)
    tx_disp[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

    #Parameters
    rsmat[c4d.ID_BASELIST_NAME] = "Material"
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_BRDF] = 1
    rsmat[c4d.REDSHIFT_SHADER_MATERIAL_REFL_FRESNEL_MODE] = 2

    basecolor[c4d.ID_BASELIST_NAME] = "tx_basecolor"
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_basecolor.<udim>."+arg_ext
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    basecolor[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

    roughness[c4d.ID_BASELIST_NAME] = "tx_roughness"
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_roughness.<udim>."+arg_ext
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    roughness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    metalness[c4d.ID_BASELIST_NAME] = "tx_metalness"
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_metallic.<udim>."+arg_ext
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    metalness[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    normal[c4d.ID_BASELIST_NAME] = "tx_normal"
    normal[c4d.REDSHIFT_SHADER_NORMALMAP_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_normal.<udim>."+arg_ext
    if int(arg_normal) == 1:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 0
    else:
        normal[c4d.REDSHIFT_SHADER_NORMALMAP_FLIPY] = 1

    tx_disp[c4d.ID_BASELIST_NAME] = "tx_disp"
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_height.<udim>."+arg_ext
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
    tx_disp[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

    disp[c4d.ID_BASELIST_NAME] = "displacement"
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_SCALE] = 0.1
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MIN] = - 0.5
    disp[c4d.REDSHIFT_SHADER_DISPLACEMENT_NEWRANGE_MAX] = 0.5

    #Ports
    output.AddPort(c4d.GV_PORT_INPUT,id= c4d.GV_REDSHIFT_OUTPUT_DISPLACEMENT,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_DIFFUSE_COLOR,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_ROUGHNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_REFL_METALNESS,message=True)
    rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_BUMP_INPUT,message=True)
    disp.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_DISPLACEMENT_TEXMAP,message=True)


    #Connections
    rsmat.GetOutPort(0).Connect(output.GetInPort(0))
    basecolor.GetOutPort(0).Connect(rsmat.GetInPort(0))
    roughness.GetOutPort(0).Connect(rsmat.GetInPort(1))
    metalness.GetOutPort(0).Connect(rsmat.GetInPort(2))
    normal.GetOutPort(0).Connect(rsmat.GetInPort(3))
    tx_disp.GetOutPort(0).Connect(disp.GetInPort(0))
    disp.GetOutPort(0).Connect(output.GetInPort(1))


    isemissive = False
    for m in arg_mats.split('|'):
        if os.path.isfile(os.path.join(arg_path,arg_mesh+"_emissive."+m+"."+arg_ext)):
            isemissive = True
    if isemissive:
        emissive = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 400)
        emissive[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        rsmat[c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_WEIGHT] = 2

        emissive[c4d.ID_BASELIST_NAME] = "tx_emissive"
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_emissive.<udim>."+arg_ext
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        emissive[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 1

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_EMISSION_COLOR,message=True)

        emissive.GetOutPort(0).Connect(rsmat.GetInPort(4))


    isopacity = False
    for m in arg_mats.split('|'):
        if os.path.isfile(os.path.join(arg_path,arg_mesh+"_opacity."+m+"."+arg_ext)):
            isopacity = True
    if isopacity:
        opacity = gvNodeMaster.CreateNode(gvNodeMaster.GetRoot(), 1036227, gvNodeMaster.GetRoot(), -200, 500)
        opacity[c4d.GV_REDSHIFT_SHADER_META_CLASSNAME] = "TextureSampler"

        opacity[c4d.ID_BASELIST_NAME] = "tx_opacity"
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0, c4d.REDSHIFT_FILE_PATH] = arg_path + os.sep + arg_mesh+"_opacity.<udim>."+arg_ext
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMAOVERRIDE] = 1
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_SRGB] = 0
        opacity[c4d.REDSHIFT_SHADER_TEXTURESAMPLER_TEX0_GAMMA] = 1.0

        rsmat.AddPort(c4d.GV_PORT_INPUT,id= c4d.REDSHIFT_SHADER_MATERIAL_OPACITY_COLOR,message=True)

        opacity.GetOutPort(0).Connect(rsmat.GetInPort(rsmat.GetInPortCount() - 1))

    #Redraw
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)
