#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import c4d
import os

# from api/util/Constants.h
C4DTOA_MSG_TYPE = 1000
C4DTOA_MSG_PARAM1 = 2001
C4DTOA_MSG_PARAM2 = 2002
C4DTOA_MSG_PARAM3 = 2003
C4DTOA_MSG_PARAM4 = 2004
C4DTOA_MSG_RESP1 = 2011
C4DTOA_MSG_ADD_SHADER = 1029
C4DTOA_MSG_ADD_CONNECTION = 1031
C4DTOA_MSG_CONNECT_ROOT_SHADER = 1033

# from c4dtoa_symbols.h
ARNOLD_SHADER_NETWORK = 1033991
ARNOLD_SHADER_GV = 1033990

# from api/util/NodeIds.h
C4DAIN_STANDARD_SURFACE = 314733630
C4DAIN_IMAGE = 262700200
C4DAIN_NORMAL_MAP = 1512478027
C4DAIN_CLAMP = 255548946
C4DAIN_NORMAL_DISPLACEMENT = 1270483482

# from api/util/ArnolShaderNetworkUtil.h
ARNOLD_BEAUTY_PORT_ID = 537905099
RNOLD_DISPLACEMENT_PORT_ID = 537905100

# from res/description/ainode_standard.h
C4DAIP_STANDARD_SURFACE_BASE = 1182964519
C4DAIP_STANDARD_SURFACE_BASE_COLOR = 1044225467
C4DAIP_STANDARD_SURFACE_REFL_ROUGHNESS = 1876347704
C4DAIP_STANDARD_SURFACE_BASE_METAL = 1875191464
C4DAIP_STANDARD_SURFACE_NORMAL = 244376085
C4DAIP_STANDARD_SURFACE_EMISSION = 108737517
C4DAIP_STANDARD_SURFACE_EMISSION_COLOR = 274240561
C4DAIP_STANDARD_SURFACE_OPACITY = 784568645

# from res/description/ainode_image.h
C4DAIP_IMAGE_FILENAME = 1737748425
C4DAIP_IMAGE_COLOR_SPACE = 868305056
C4DAIP_IMAGE_SINGLE_CHANNEL = 333361456
C4DAIP_IMAGE_START_CHANNEL = 424767676

# from res/description/ainode_normal_map.h
C4DAIP_NORMAL_MAP_INPUT = 2075543287
C4DAIP_NORMAL_MAP_INVERT_Y = 2113820041

C4DAIP_NORMAL_DISPLACEMENT_DISPLACEMENT = 276937581
C4DAIP_NORMAL_DISPLACEMENT_SCALE = 748850620

def CreateArnoldShader(material, nodeId, posx, posy):
    msg = c4d.BaseContainer()
    msg.SetInt32(C4DTOA_MSG_TYPE, C4DTOA_MSG_ADD_SHADER)
    msg.SetInt32(C4DTOA_MSG_PARAM1, ARNOLD_SHADER_GV)
    msg.SetInt32(C4DTOA_MSG_PARAM2, nodeId)
    msg.SetInt32(C4DTOA_MSG_PARAM3, posx)
    msg.SetInt32(C4DTOA_MSG_PARAM4, posy)
    material.Message(c4d.MSG_BASECONTAINER, msg)
    return msg.GetLink(C4DTOA_MSG_RESP1)

def SetRootShader(material, shader, rootPortId):
    msg = c4d.BaseContainer()
    msg.SetInt32(C4DTOA_MSG_TYPE, C4DTOA_MSG_CONNECT_ROOT_SHADER)
    msg.SetLink(C4DTOA_MSG_PARAM1, shader)
    msg.SetInt32(C4DTOA_MSG_PARAM2, 0)
    msg.SetInt32(C4DTOA_MSG_PARAM3, rootPortId)
    material.Message(c4d.MSG_BASECONTAINER, msg)
    return msg.GetBool(C4DTOA_MSG_RESP1)

def AddConnection(material, srcNode, dstNode, dstPortId):
    msg = c4d.BaseContainer()
    msg.SetInt32(C4DTOA_MSG_TYPE, C4DTOA_MSG_ADD_CONNECTION)
    msg.SetLink(C4DTOA_MSG_PARAM1, srcNode)
    msg.SetInt32(C4DTOA_MSG_PARAM2, 0)
    msg.SetLink(C4DTOA_MSG_PARAM3, dstNode)
    msg.SetInt32(C4DTOA_MSG_PARAM4, dstPortId)
    material.Message(c4d.MSG_BASECONTAINER, msg)
    return msg.GetBool(C4DTOA_MSG_RESP1)


def arCreate(arg_path,arg_mat,arg_ext,arg_normal):

    doc = c4d.documents.GetActiveDocument()

    #Material
    mat = c4d.BaseMaterial(ARNOLD_SHADER_NETWORK)
    if mat is None:
        raise Exception("Failed to create material")
    mat.SetName("AR_"+arg_mat)
    doc.InsertMaterial(mat)

    #Shader Nodes
    standard = CreateArnoldShader(mat, C4DAIN_STANDARD_SURFACE, 300, -200)
    tx_basecolor = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-500)
    tx_roughness = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-400)
    tx_metalness = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-300)
    tx_normal = CreateArnoldShader(mat,C4DAIN_IMAGE,-300,-200)
    normal = CreateArnoldShader(mat,C4DAIN_NORMAL_MAP,0,-200)
    tx_disp = CreateArnoldShader(mat,C4DAIN_IMAGE,0,400)
    disp = CreateArnoldShader(mat,C4DAIN_NORMAL_DISPLACEMENT,300,400)

    #Shader Adjustments
    standard.SetName("material_"+ arg_mat)
    standard.GetOpContainerInstance().SetFloat(C4DAIP_STANDARD_SURFACE_BASE, 1)

    tx_basecolor.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_basecolor."+arg_ext )
    tx_basecolor.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"sRGB")

    tx_roughness.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_roughness."+arg_ext )
    tx_roughness.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_roughness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_roughness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

    tx_metalness.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_metallic."+arg_ext )
    tx_metalness.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_metalness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_metalness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

    tx_normal.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_normal."+arg_ext )
    tx_normal.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    if int(arg_normal) == 1:
        tx_normal.GetOpContainerInstance().SetInt32(C4DAIP_NORMAL_MAP_INVERT_Y,0)
    else:
        tx_normal.GetOpContainerInstance().SetInt32(C4DAIP_NORMAL_MAP_INVERT_Y,1)


    tx_disp.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_height."+arg_ext )
    tx_disp.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_disp.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_disp.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

    disp.GetOpContainerInstance().SetFloat(C4DAIP_NORMAL_DISPLACEMENT_SCALE, 0.01)

    #Connections
    SetRootShader(mat, standard, ARNOLD_BEAUTY_PORT_ID)
    AddConnection(mat, tx_basecolor, standard, C4DAIP_STANDARD_SURFACE_BASE_COLOR)
    AddConnection(mat, tx_roughness, standard, C4DAIP_STANDARD_SURFACE_REFL_ROUGHNESS)
    AddConnection(mat, tx_metalness, standard, C4DAIP_STANDARD_SURFACE_BASE_METAL)
    AddConnection(mat, tx_normal, normal, C4DAIP_NORMAL_MAP_INPUT)
    AddConnection(mat, normal, standard, C4DAIP_STANDARD_SURFACE_NORMAL)
    AddConnection(mat, tx_disp, disp, C4DAIP_NORMAL_DISPLACEMENT_DISPLACEMENT)
    SetRootShader(mat, disp, RNOLD_DISPLACEMENT_PORT_ID)

    path_emissive = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
    if os.path.isfile(path_emissive):
        tx_emissive = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-100)

        tx_emissive.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_emissive."+arg_ext )
        tx_emissive.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"sRGB")

        standard.GetOpContainerInstance().SetFloat(C4DAIP_STANDARD_SURFACE_EMISSION, 1.0)

        AddConnection(mat, tx_emissive, standard, C4DAIP_STANDARD_SURFACE_EMISSION_COLOR)

    path_opacity = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
    if os.path.isfile(path_opacity):
        tx_opacity = CreateArnoldShader(mat,C4DAIN_IMAGE,0,0)

        tx_opacity.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_opacity."+arg_ext )
        tx_opacity.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
        tx_opacity.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
        tx_opacity.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

        AddConnection(mat, tx_opacity, standard, C4DAIP_STANDARD_SURFACE_OPACITY)


    #Redraw
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)







def arCreatePkd(arg_path,arg_mat,arg_ext,arg_normal):

    doc = c4d.documents.GetActiveDocument()

    #Material
    mat = c4d.BaseMaterial(ARNOLD_SHADER_NETWORK)
    if mat is None:
        raise Exception("Failed to create material")
    mat.SetName("AR_"+arg_mat)
    doc.InsertMaterial(mat)

    #Shader Nodes
    standard = CreateArnoldShader(mat, C4DAIN_STANDARD_SURFACE, 300, -200)
    tx_basecolor = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-500)
    tx_roughness = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-400)
    tx_metalness = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-300)
    tx_normal = CreateArnoldShader(mat,C4DAIN_IMAGE,-300,-200)
    normal = CreateArnoldShader(mat,C4DAIN_NORMAL_MAP,0,-200)
    tx_disp = CreateArnoldShader(mat,C4DAIN_IMAGE,0,400)
    disp = CreateArnoldShader(mat,C4DAIN_NORMAL_DISPLACEMENT,300,400)

    #Shader Adjustments
    standard.SetName("material_"+ arg_mat)
    standard.GetOpContainerInstance().SetFloat(C4DAIP_STANDARD_SURFACE_BASE, 1)

    tx_basecolor.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_basecolor."+arg_ext )
    tx_basecolor.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"sRGB")

    tx_roughness.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_aoroughmetal."+arg_ext )
    tx_roughness.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_roughness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_roughness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,1)

    tx_metalness.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_aoroughmetal."+arg_ext )
    tx_metalness.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_metalness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_metalness.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,2)

    tx_normal.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_normal."+arg_ext )
    tx_normal.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    if int(arg_normal) == 1:
        tx_normal.GetOpContainerInstance().SetInt32(C4DAIP_NORMAL_MAP_INVERT_Y,0)
    else:
        tx_normal.GetOpContainerInstance().SetInt32(C4DAIP_NORMAL_MAP_INVERT_Y,1)


    tx_disp.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_height."+arg_ext )
    tx_disp.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
    tx_disp.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
    tx_disp.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

    disp.GetOpContainerInstance().SetFloat(C4DAIP_NORMAL_DISPLACEMENT_SCALE, 0.01)

    #Connections
    SetRootShader(mat, standard, ARNOLD_BEAUTY_PORT_ID)
    AddConnection(mat, tx_basecolor, standard, C4DAIP_STANDARD_SURFACE_BASE_COLOR)
    AddConnection(mat, tx_roughness, standard, C4DAIP_STANDARD_SURFACE_REFL_ROUGHNESS)
    AddConnection(mat, tx_metalness, standard, C4DAIP_STANDARD_SURFACE_BASE_METAL)
    AddConnection(mat, tx_normal, normal, C4DAIP_NORMAL_MAP_INPUT)
    AddConnection(mat, normal, standard, C4DAIP_STANDARD_SURFACE_NORMAL)
    AddConnection(mat, tx_disp, disp, C4DAIP_NORMAL_DISPLACEMENT_DISPLACEMENT)
    SetRootShader(mat, disp, RNOLD_DISPLACEMENT_PORT_ID)


    path_emissive = arg_path + os.sep + arg_mat+"_emissive."+arg_ext
    if os.path.isfile(path_emissive):
        tx_emissive = CreateArnoldShader(mat,C4DAIN_IMAGE,0,-100)

        tx_emissive.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_emissive."+arg_ext )
        tx_emissive.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"sRGB")

        standard.GetOpContainerInstance().SetFloat(C4DAIP_STANDARD_SURFACE_EMISSION, 1.0)

        AddConnection(mat, tx_emissive, standard, C4DAIP_STANDARD_SURFACE_EMISSION_COLOR)

    path_opacity = arg_path + os.sep + arg_mat+"_opacity."+arg_ext
    if os.path.isfile(path_opacity):
        tx_opacity = CreateArnoldShader(mat,C4DAIN_IMAGE,0,0)

        tx_opacity.GetOpContainerInstance().SetFilename(C4DAIP_IMAGE_FILENAME,arg_path + os.sep + arg_mat+"_opacity."+arg_ext )
        tx_opacity.GetOpContainerInstance().SetString(C4DAIP_IMAGE_COLOR_SPACE,"linear")
        tx_opacity.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_SINGLE_CHANNEL,1)
        tx_opacity.GetOpContainerInstance().SetInt32(C4DAIP_IMAGE_START_CHANNEL,0)

        AddConnection(mat, tx_opacity, standard, C4DAIP_STANDARD_SURFACE_OPACITY)

    #Redraw
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)
