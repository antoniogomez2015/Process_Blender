//Xolotl Studio
//Created by Ymmanuel Flores on 2018
//Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
//hhconnect v 1.0.0.4

function sendData(config,selected){

  var maps = null
  if(selected){
    var doc = alg.mapexport.documentStructure()

    doc.materials.forEach(function(mat){
  	   if(mat.selected){
  		     maps = mat.name
  		 }
     })
  }

  var data =  exportMaps(config,maps)


  if(config.rndr == 'RENDERMAN'){
    if(Qt.platform.os == "windows"){
  	   alg.subprocess.check_output(["\""+alg.plugin_root_directory+"makeTXFiles.exe\"", config.out_path, data.materials, data.mesh,  config.ext, config.packed, config.udims])
  	}else{
       alg.subprocess.check_output('./makeTXFiles "' + config.out_path + '" "' + data.materials + '" "' + data.mesh + '" ' + config.ext + ' ' + config.packed + ' ' + config.udims )
  	}
  }

  var res = ""
  if(config.sw == "Houdini"){
    if(Qt.platform.os == "windows"){
  	   res = alg.subprocess.check_output(["\""+alg.plugin_root_directory+"send_to_hou.exe\"", config.out_path, data.materials, data.mesh,  config.udims, config.port, config.houpath,  config.rndr, config.ext,  config.packed,  config.normal ])
  	}else{
       res = alg.subprocess.check_output('./send_to_hou "' + config.out_path + '" "' + data.materials + '" "' + data.mesh + '" ' + config.udims + ' ' + config.port + ' ' + config.houpath + ' ' + config.rndr + ' ' + config.ext + ' ' + config.packed + ' ' + config.normal )
  	}
  }else{
    if(Qt.platform.os == "windows"){
  	   res = alg.subprocess.check_output(["\""+alg.plugin_root_directory+"send_to.exe\"", config.out_path, data.materials, data.mesh,  config.udims, config.sw, config.port, config.rndr, config.ext,  config.packed,  config.normal ])
  	}else{
       res = alg.subprocess.check_output('./send_to "' + config.out_path + '" "' + data.materials + '" "' + data.mesh + '" ' + config.udims + ' "' + config.sw + '" ' + config.port + ' ' + config.rndr + ' ' + config.ext + ' ' + config.packed + ' ' + config.normal )
  	}
  }
  alg.log.info(res)
}

function exportMaps(config,selected){
  var template = getTemplate(config.sw,config.rndr,config.udims,config.packed)
  var templateNormal = getNormalTemplate(config.udims,config.normal)
  var templateHeight = getHeightTemplate(config.udims)

  var result = ""
  var mats = ""
  if(selected != null){
    alg.mapexport.exportDocumentMaps(
                   template,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.main_bit},
                   [selected]
                 );
    alg.mapexport.exportDocumentMaps(
                   templateNormal,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.normal_bit},
                   [selected]
                 );
    result = alg.mapexport.exportDocumentMaps(
                   templateHeight,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.height_bit},
                   [selected]
                 );
    mats = selected

  }else{
    alg.mapexport.exportDocumentMaps(
                   template,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.main_bit}
                 );
    alg.mapexport.exportDocumentMaps(
                   templateNormal,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.normal_bit}
                 );
    result = alg.mapexport.exportDocumentMaps(
                   templateHeight,
                   config.out_path,
                   config.ext,
                   {resolution:[config.res,config.res],bitDepth:config.height_bit}
                 );

    Object.keys(result).map(function(val){
      mats += val + "|"
    })
    mats = mats.substring(0, mats.length - 1)

  }

  var mesh = 'NONE'

  if (config.udims == 1){
    var first_udim = result[Object.keys(result)[0]]
    var path = first_udim[Object.keys(first_udim)[0]]
    var path_split = path.split("/")
    var file = path_split[path_split.length - 1]
    var file_split = file.split(".")
    var filename =  file_split[file_split.length - 3]
    var filename_split =  filename.split("_")
    filename_split.pop()
    mesh = filename_split.join("_")
  }

  return {materials:mats, mesh:mesh}

}

function getTemplate(sw,rndr,udims,packed){
  if(udims == 1 && packed != 1){

    if(sw == "Houdini" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_hou_rs_udims.spexp"}
    else if(sw == "Houdini" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_hou_ar_udims.spexp"}
    else if(sw == "Houdini" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_hou_rm_udims.spexp"}

    else if(sw == "Cinema 4D" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_c4d_ar_udims.spexp"}
    else if(sw == "Cinema 4D" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_c4d_rs_udims.spexp"}

    else if(sw == "Maya" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_may_ar_udims.spexp"}
    else if(sw == "Maya" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_may_rs_udims.spexp"}
    else if(sw == "Maya" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_may_rm_udims.spexp"}
    else if(sw == "Maya" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_may_vry_udims.spexp"}

    else if(sw == "Modo" && rndr == "MODO"){ return alg.plugin_root_directory+"/exports/HH_mod_mod_udims.spexp"}
    else if(sw == "Modo" && rndr == "UE4"){ return alg.plugin_root_directory+"/exports/HH_mod_ue4_udims.spexp"}
    else if(sw == "Modo" && rndr == "UNITY"){ return alg.plugin_root_directory+"/exports/HH_mod_uni_udims.spexp"}

    else if(sw == "3DS Max" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_3ds_ar_udims.spexp"}
    else if(sw == "3DS Max" && rndr == "CORONA"){ return alg.plugin_root_directory+"/exports/HH_3ds_cor_udims.spexp"}
    else if(sw == "3DS Max" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_3ds_rs_udims.spexp"}
    else if(sw == "3DS Max" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_3ds_vry_udims.spexp"}

  }else if(udims == 1 && packed == 1){

    if(sw == "Houdini" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_hou_rs_udims_pkd.spexp"}
    else if(sw == "Houdini" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_hou_ar_udims_pkd.spexp"}
    else if(sw == "Houdini" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_hou_rm_udims_pkd.spexp"}

    else if(sw == "Cinema 4D" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_c4d_ar_udims_pkd.spexp"}
    else if(sw == "Cinema 4D" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_c4d_rs_udims_pkd.spexp"}

    else if(sw == "Maya" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_may_ar_udims_pkd.spexp"}
    else if(sw == "Maya" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_may_rs_udims_pkd.spexp"}
    else if(sw == "Maya" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_may_rm_udims_pkd.spexp"}
    else if(sw == "Maya" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_may_vry_udims_pkd.spexp"}

    else if(sw == "Modo" && rndr == "MODO"){ return alg.plugin_root_directory+"/exports/HH_mod_mod_udims_pkd.spexp"}
    else if(sw == "Modo" && rndr == "UE4"){ return alg.plugin_root_directory+"/exports/HH_mod_ue4_udims_pkd.spexp"}
    else if(sw == "Modo" && rndr == "UNITY"){ return alg.plugin_root_directory+"/exports/HH_mod_uni_udims_pkd.spexp"}

    else if(sw == "3DS Max" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_3ds_ar_udims_pkd.spexp"}
    else if(sw == "3DS Max" && rndr == "CORONA"){ return alg.plugin_root_directory+"/exports/HH_3ds_cor_udims_pkd.spexp"}
    else if(sw == "3DS Max" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_3ds_rs_udims_pkd.spexp"}
    else if(sw == "3DS Max" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_3ds_vry_udims_pkd.spexp"}

  }else if(udims != 1 && packed == 1){

    if(sw == "Blender"){ return alg.plugin_root_directory+"/exports/HH_bld_pkd.spexp"}

    else if(sw == "Cinema 4D" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_c4d_rs_pkd.spexp"}
    else if(sw == "Cinema 4D" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_c4d_ar_pkd.spexp"}

    else if(sw == "Houdini" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_hou_rs_pkd.spexp"}
    else if(sw == "Houdini" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_hou_ar_pkd.spexp"}
    else if(sw == "Houdini" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_hou_rm_pkd.spexp"}

    else if(sw == "Maya" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_may_ar_pkd.spexp"}
    else if(sw == "Maya" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_may_rs_pkd.spexp"}
    else if(sw == "Maya" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_may_rm_pkd.spexp"}
    else if(sw == "Maya" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_may_vry_pkd.spexp"}

    else if(sw == "Modo" && rndr == "MODO"){ return alg.plugin_root_directory+"/exports/HH_mod_mod_pkd.spexp"}
    else if(sw == "Modo" && rndr == "UE4"){ return alg.plugin_root_directory+"/exports/HH_mod_ue4_pkd.spexp"}
    else if(sw == "Modo" && rndr == "UNITY"){ return alg.plugin_root_directory+"/exports/HH_mod_uni_pkd.spexp"}

    else if(sw == "3DS Max" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_3ds_ar_pkd.spexp"}
    else if(sw == "3DS Max" && rndr == "CORONA"){ return alg.plugin_root_directory+"/exports/HH_3ds_cor_pkd.spexp"}
    else if(sw == "3DS Max" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_3ds_rs_pkd.spexp" }
    else if(sw == "3DS Max" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_3ds_vry_pkd.spexp"}

  }else if(udims != 1 && packed != 1){

    if(sw == "Blender"){ return alg.plugin_root_directory+"/exports/HH_bld.spexp"}

    else if(sw == "Cinema 4D" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_c4d_rs.spexp"}
    else if(sw == "Cinema 4D" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_c4d_ar.spexp"}

    else if(sw == "Houdini" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_hou_rs.spexp"}
    else if(sw == "Houdini" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_hou_ar.spexp"}
    else if(sw == "Houdini" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_hou_rm.spexp"}

    else if(sw == "Maya" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_may_ar.spexp"}
    else if(sw == "Maya" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_may_rs.spexp"}
    else if(sw == "Maya" && rndr == "RENDERMAN"){ return alg.plugin_root_directory+"/exports/HH_may_rm.spexp"}
    else if(sw == "Maya" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_may_vry.spexp"}

    else if(sw == "Modo" && rndr == "MODO"){ return alg.plugin_root_directory+"/exports/HH_mod_mod.spexp"}
    else if(sw == "Modo" && rndr == "UE4"){ return alg.plugin_root_directory+"/exports/HH_mod_ue4.spexp"}
    else if(sw == "Modo" && rndr == "UNITY"){ return alg.plugin_root_directory+"/exports/HH_mod_uni.spexp"}

    else if(sw == "3DS Max" && rndr == "ARNOLD"){ return alg.plugin_root_directory+"/exports/HH_3ds_ar.spexp"}
    else if(sw == "3DS Max" && rndr == "CORONA"){ return alg.plugin_root_directory+"/exports/HH_3ds_cor.spexp"}
    else if(sw == "3DS Max" && rndr == "REDSHIFT"){ return alg.plugin_root_directory+"/exports/HH_3ds_rs.spexp"}
    else if(sw == "3DS Max" && rndr == "VRAY"){ return alg.plugin_root_directory+"/exports/HH_3ds_vry.spexp"}

  }
}

function getNormalTemplate(udims,format){
  if(udims == 1 && format == 0){
    return alg.plugin_root_directory + "/exports/HH_normal_ogl_udims.spexp"
  }else if(udims == 1 && format == 1){
    return alg.plugin_root_directory + "/exports/HH_normal_dx_udims.spexp"
  }else if(udims == 0 && format == 1){
    return alg.plugin_root_directory + "/exports/HH_normal_ogl.spexp"
  }else{
    return alg.plugin_root_directory + "/exports/HH_normal_dx.spexp"
  }
}

function getHeightTemplate(udims){
  if(udims == 1){
    return alg.plugin_root_directory + "/exports/HH_height_udims.spexp"
  }else{
    return alg.plugin_root_directory + "/exports/HH_height.spexp"
  }
}
