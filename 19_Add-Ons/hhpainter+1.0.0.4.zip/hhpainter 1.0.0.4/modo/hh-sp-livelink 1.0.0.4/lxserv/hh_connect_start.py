#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx, lxu.command, hhsplink, modo, traceback

class cmd_connect_start_class(lxu.command.BasicCommand):



    def __init__(self):
        lxu.command.BasicCommand.__init__(self)
        self.dyna_Add('connPort', lx.symbol.sTYPE_INTEGER)

    def arg_UIHints(self, index, hints):
        if index == 0:
            hints.Label('Set the connection Port')

    def cmd_DialogInit(self):
        self.attr_SetFlt(0,8080)


    @classmethod

    def cmd_Flags (self):
        return lx.symbol.fCMD_MODEL | lx.symbol.fCMD_UNDO

    def CMD_EXE(self, msg, flags):
        try:
            port = self.dyna_Int(0) if self.dyna_IsSet(0) else 0
            lx.eval('!!telnet.listen %s 1 1' % port)
            print('Started listening commands using the port: %s' % port )
            modo.dialogs.alert('Hedgehog Connect','Modo is ready to communicate with using the port %s' % port,'info')

        except:
            modo.dialogs.alert('Hedgehog Connect','Modo is already listenig Hedgehog Connect','info')


    def basic_Execute(self, msg, flags):
        try:
            self.CMD_EXE(msg, flags)
        except Exception:
            lx.out(traceback.format_exc())

    def basic_Enable(self,msg):
        return True

lx.bless(cmd_connect_start_class, hhsplink.HHC_START)
