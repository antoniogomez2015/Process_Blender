#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx, lxu.command, hhsplink, modo, traceback

class cmd_connect_stop_class(lxu.command.BasicCommand):

    @classmethod

    def cmd_Flags (self):
        return lx.symbol.fCMD_MODEL | lx.symbol.fCMD_UNDO

    def CMD_EXE(self, msg, flags):
        try:
            lx.eval('!!telnet.listen open:false')
            print('Stopped listening devices')
            modo.dialogs.alert('Hedgehog Connect','Modo stopped listening external devices','info')

        except:
            modo.dialogs.alert('Hedgehog Connect','Modo failed to stop listenig external devices','error')


    def basic_Execute(self, msg, flags):
        try:
            self.CMD_EXE(msg, flags)
        except Exception:
            lx.out(traceback.format_exc())

    def basic_Enable(self,msg):
        return True

lx.bless(cmd_connect_stop_class, hhsplink.HHC_STOP)
