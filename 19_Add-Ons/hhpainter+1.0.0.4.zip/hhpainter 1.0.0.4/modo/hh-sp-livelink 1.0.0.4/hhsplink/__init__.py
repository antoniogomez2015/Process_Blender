#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import traceback

try:
    from constants import *
except:
    traceback.print_exc()
