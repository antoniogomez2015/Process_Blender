#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo

import hh_std_udims
import hh_ue4_udims
import hh_unity_udims

def updateImages(rndr,name,materials,packed):

    if rndr == "UE4":
        for mat in materials:
            if int(packed) == 1:
                lx.eval('select.item "'+name+'_basecolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_emissive.'+ mat+'" add')
                lx.eval('select.item "'+name+'_opacity.'+ mat+'" add')
                lx.eval('select.item "'+name+'_aoroughmetal.'+ mat+'" add')
            else:
                lx.eval('select.item "'+name+'_basecolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_emissive.'+ mat+'" add')
                lx.eval('select.item "'+name+'_opacity.'+ mat+'" add')
                lx.eval('select.item "'+name+'_ao.'+ mat+'" add')
                lx.eval('select.item "'+name+'_roughness.'+ mat+'" add')
                lx.eval('select.item "'+name+'_metallic.'+ mat+'" add')

    elif rndr == "UNITY":
        for mat in materials:
            if int(packed) == 1:
                lx.eval('select.item "'+name+'_basecolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_emissive.'+ mat+'" add')
                lx.eval('select.item "'+name+'_aoglossmetal.'+ mat+'" add')
            else:
                lx.eval('select.item "'+name+'_basecolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_emissive.'+ mat+'" add')
                lx.eval('select.item "'+name+'_ao.'+ mat+'" add')
                lx.eval('select.item "'+name+'_glossiness.'+ mat+'" add')
                lx.eval('select.item "'+name+'_metallic.'+ mat+'" add')


    else:
        for mat in materials:
            if int(packed) == 1:
                lx.eval('select.item "'+name+'_diffuse.'+ mat+'" add')
                lx.eval('select.item "'+name+'_reflection.'+ mat+'" add')
                lx.eval('select.item "'+name+'_aoroughf0.'+ mat+'" add')
                lx.eval('select.item "'+name+'_opacity.'+ mat+'" add')
                lx.eval('select.item "'+name+'_luminouscolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_luminousamount.'+ mat+'" add')
            else:
                lx.eval('select.item "'+name+'_diffuse.'+ mat+'" add')
                lx.eval('select.item "'+name+'_reflection.'+ mat+'" add')
                lx.eval('select.item "'+name+'_ao.'+ mat+'" add')
                lx.eval('select.item "'+name+'_roughness.'+ mat+'" add')
                lx.eval('select.item "'+name+'_f0.'+ mat+'" add')
                lx.eval('select.item "'+name+'_opacity.'+ mat+'" add')
                lx.eval('select.item "'+name+'_luminouscolor.'+ mat+'" add')
                lx.eval('select.item "'+name+'_luminousamount.'+ mat+'" add')


    for mat in materials:
        lx.eval('select.item "'+name+'_normal.'+ mat+'" add')
        lx.eval('select.item "'+name+'_height.'+ mat+'" add')

    lx.eval('!clip.reload')
    lx.eval("select.drop item")


def addMaterials(out_path,mat_names,ext,rndr,mesh,packed,normal):

    materials = mat_names.split("|")

    scene = modo.scene.current()
    scene.select( [i for i in scene.iterItems(itype=modo.c.MASK_TYPE)] )
    masks = scene.selectedByType(modo.c.MASK_TYPE)
    if rndr == "UE4":
        alt_name = "UE4_"+mesh + " (Material)"
        item = None
        for m in masks:
            if m.name == ("UE4_"+mesh) or m.name == alt_name:
                item = m

        if item == None:
            if int(packed) == 1:
                hh_ue4_udims.addUE4Pkd(out_path,ext,mesh,materials,normal)
            else:
                hh_ue4_udims.addUE4(out_path,ext,mesh,materials,normal)
        else:
            updateImages(rndr,mesh,materials,packed)


    elif rndr == "UNITY":
        alt_name = "UT_"+mesh + " (Material)"
        item = None
        for m in masks:
            if m.name == ("UT_"+mesh) or m.name == alt_name:
                item = m

        if item == None:
            if int(packed) == 1:
                hh_unity_udims.addUnityPkd(out_path,ext,mesh,materials,normal)
            else:
                hh_unity_udims.addUnity(out_path,ext,mesh,materials,normal)
        else:
            updateImages(rndr,mesh,materials,packed)


    else:
        alt_name = "STD_"+mesh + " (Material)"
        item = None
        for m in masks:
            if m.name == ("STD_"+mesh) or m.name == alt_name:
                item = m

        if item == None:
            if int(packed) == 1:
                hh_std_udims.addDefaultPkd(out_path,ext,mesh,materials,normal)
            else:
                hh_std_udims.addDefault(out_path,ext,mesh,materials,normal)
        else:
            updateImages(rndr,mesh,materials,packed)

    return



args = lx.args()
addMaterials(args[0],args[1],args[2],args[3],args[4],args[5],args[6])
