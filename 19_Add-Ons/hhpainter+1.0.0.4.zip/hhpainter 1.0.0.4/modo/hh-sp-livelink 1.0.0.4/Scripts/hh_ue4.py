#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo
import os

def addUE4(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    mat_name = "UE4_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unreal"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_basecolor."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect baseUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')

    txtMap = '"'+out_path + "/"+name+"_ao."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_ao."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect aoUE")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_roughness."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect roughUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_metallic."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect metallicUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_emissive."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_emissive."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect emisUE")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')

    txtMap = '"'+out_path + "/"+name+"_opacity."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_opacity."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect opacUE")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normalUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect bumpUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')






def addUE4Pkd(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    mat_name = "UE4_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unreal"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_basecolor."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect baseUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')

    txtMap = '"'+out_path + "/"+name+"_aoroughmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect aoUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba red")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')


    txtMap = '"'+out_path + "/"+name+"_aoroughmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect roughUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba green")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_aoroughmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect metallicUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba blue")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_emissive."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_emissive."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect emisUE")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')

    txtMap = '"'+out_path + "/"+name+"_opacity."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_opacity."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect opacUE")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normalUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect bumpUE")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
