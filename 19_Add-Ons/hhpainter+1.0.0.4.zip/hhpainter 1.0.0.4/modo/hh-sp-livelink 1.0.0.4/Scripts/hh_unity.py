#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo
import os

def addUnity(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    scene = modo.scene.current()
    mat_name = "UT_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unity"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_basecolor."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect albedoUT")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba use")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_ao."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_ao."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect aoUT")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_glossiness."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect smoothUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_metallic."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect metallicUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_emissive."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_emissive."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect emisUT")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normalUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect bumpUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")


def addUnityPkd(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    mat_name = "UT_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unity"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_basecolor."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect albedoUT")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba use")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_aoglossmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect aoUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba red")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_aoglossmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect smoothUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba green")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_aoglossmetal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect metallicUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba blue")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_emissive."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_emissive."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 1"%mask[0].id)
        lx.eval("shader.setEffect emisUT")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normalUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect bumpUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")
