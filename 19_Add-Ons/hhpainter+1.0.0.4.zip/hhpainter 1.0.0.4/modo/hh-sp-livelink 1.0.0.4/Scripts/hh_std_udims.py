#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo
import os

def addDefault(out_path,mat_ext,name,materials,normal):
    scene = modo.scene.current()
    mat_name = "STD_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false default"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')[0]

    #Diffuse
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_diffuse", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_diffuse."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect diffColor")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Reflection
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_reflection", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_reflection."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect specColor")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Opacity
    opacity = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_opacity."+mat+"."+mat_ext):
            opacity = True

    if opacity:
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_opacity", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_opacity."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_opacity."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("item.channel textureLayer$invert true")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval("shader.setEffect dissolve")

    #Emissive
    emissive = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext):
            emissive = True

    if emissive:
        #Luminous Color
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_luminouscolor", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect lumiColor")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

        #Luminous Amount
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_luminousamount", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_luminousamount."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_luminousamount."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect lumiAmount")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Roughness
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_roughness", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_roughness."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()

    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect rough")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #f0
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_f0", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_f0."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect specAmount")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

    #Normal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_normal", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_normal."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect normal")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Height
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_height", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_height."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect displace")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel imageMap$min -1.0")
    lx.eval("item.channel imageMap$max 1.0")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


def addDefaultPkd(out_path,mat_ext,name,materials,normal):
    scene = modo.scene.current()
    mat_name = "STD_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false default"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')[0]

    #Diffuse
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_diffuse", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_diffuse."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect diffColor")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Reflection
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_reflection", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_reflection."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect specColor")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Opacity
    opacity = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_opacity."+mat+"."+mat_ext):
            opacity = True

    if opacity:
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_opacity", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_opacity."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_opacity."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("item.channel textureLayer$invert true")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval("shader.setEffect dissolve")

    #Emissive
    emissive = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext):
            emissive = True

    if emissive:
        #Luminous Color
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_luminouscolor", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_luminouscolor."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect lumiColor")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

        #Luminous Amount
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_luminousamount", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_luminousamount."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_luminousamount."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect lumiAmount")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #AO Roughness f0
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_aoroughf0", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_aoroughf0."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    #Roughness
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect rough")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba green")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    #f0
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect specAmount")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba blue")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

    #Normal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_normal", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_normal."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect normal")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Height
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_height", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_height."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect displace")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel imageMap$min -1.0")
    lx.eval("item.channel imageMap$max 1.0")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
