#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo
import os

def addUnity(out_path,mat_ext,name,materials,normal):
    scene = modo.scene.current()
    mat_name = "UT_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unity"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')[0]

    #Albedo
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_basecolor", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_basecolor."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect albedoUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba use")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #AO
    ao = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_ao."+mat+"."+mat_ext):
            emissive = True

    if ao:
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_ao", imageFolder.id))
        for mat in materials:
            txtMap = '"'+out_path + "/"+name+"_ao."+mat+"."+mat_ext+'"'
            lx.eval('clip.addStill %s'%txtMap)
            texture = scene.selectedByType('videoStill')[0]
            lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
            lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
            lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
            texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect aoUT")
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

    #Gloss
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_glossiness", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_glossiness."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect smoothUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

    #Metal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_metallic", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_metallic."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect metallicUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Emissive
    emissive = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_emissive."+mat+"."+mat_ext):
            emissive = True

    if emissive:
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_emissive", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_emissive."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_emissive."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect emisUT")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Normal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_normal", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_normal."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect normalUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Height
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_height", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_height."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect bumpUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


def addUnityPkd(out_path,mat_ext,name,materials,normal):
    scene = modo.scene.current()
    mat_name = "UT_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false unity"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')[0]

    #Albedo
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_basecolor", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_basecolor."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect albedoUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba use")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")

    #AO Gloss Metal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_aoglossmetal", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_aoglossmetal."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    #AO
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect aoUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba red")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    #Gloss
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect smoothUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba green")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    #Metal
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect metallicUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba blue")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Emissive
    emissive = False
    for mat in materials:
        if os.path.isfile(out_path + "/"+name+"_emissive."+mat+"."+mat_ext):
            emissive = True

    if emissive:
        lx.eval("clip.newFolder")
        imageFolder = scene.selectedByType('imageFolder')[0]
        lx.eval("item.name {%s} item:%s" % (name+"_emissive", imageFolder.id))
        for mat in materials:
            if os.path.isfile(out_path + "/"+name+"_emissive."+mat+"."+mat_ext):
                txtMap = '"'+out_path + "/"+name+"_emissive."+mat+"."+mat_ext+'"'
                lx.eval('clip.addStill %s'%txtMap)
                texture = scene.selectedByType('videoStill')[0]
                lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
                lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
                lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
                texture.deselect()
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
        lx.eval("texture.new clip:{%s}"%imageFolder.id)
        lx.eval("texture.parent %s 1"%mask.id)
        lx.eval("shader.setEffect emisUT")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Normal
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_normal", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_normal."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect normalUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")


    #Height
    lx.eval("clip.newFolder")
    imageFolder = scene.selectedByType('imageFolder')[0]
    lx.eval("item.name {%s} item:%s" % (name+"_height", imageFolder.id))
    for mat in materials:
        txtMap = '"'+out_path + "/"+name+"_height."+mat+"."+mat_ext+'"'
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')[0]
        lx.eval("clip.setUdimFromFilename {%s}"%texture.id)
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval('item.parent {%s} %s 0' % (texture.id, imageFolder.id))
        texture.deselect()
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask.id)
    lx.eval("texture.new clip:{%s}"%imageFolder.id)
    lx.eval("texture.parent %s 1"%mask.id)
    lx.eval("shader.setEffect bumpUT")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
