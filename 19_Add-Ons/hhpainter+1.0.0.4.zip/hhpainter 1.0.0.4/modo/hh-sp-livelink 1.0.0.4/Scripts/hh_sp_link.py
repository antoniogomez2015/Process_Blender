#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo

import hh_std
import hh_ue4
import hh_unity

def updateImages(rndr,name,packed):

    if rndr == "UE4":
        if int(packed) == 1:
            lx.eval('select.item "'+name+'_basecolor" set')
            lx.eval('select.item "'+name+'_emissive" add')
            lx.eval('select.item "'+name+'_opacity" add')
            lx.eval('select.item "'+name+'_aoroughmetal" add')
        else:
            lx.eval('select.item "'+name+'_basecolor" set')
            lx.eval('select.item "'+name+'_emissive" add')
            lx.eval('select.item "'+name+'_opacity" add')
            lx.eval('select.item "'+name+'_ao" add')
            lx.eval('select.item "'+name+'_roughness" add')
            lx.eval('select.item "'+name+'_metallic" add')
    elif rndr == "UNITY":
        if int(packed) == 1:
            lx.eval('select.item "'+name+'_basecolor" set')
            lx.eval('select.item "'+name+'_emissive" add')
            lx.eval('select.item "'+name+'_aoglossmetal" add')
        else:
            lx.eval('select.item "'+name+'_basecolor" set')
            lx.eval('select.item "'+name+'_emissive" add')
            lx.eval('select.item "'+name+'_ao" add')
            lx.eval('select.item "'+name+'_glossiness" add')
            lx.eval('select.item "'+name+'_metallic" add')

    else:
        if int(packed) == 1:
            lx.eval('select.item "'+name+'_diffuse" set')
            lx.eval('select.item "'+name+'_reflection" add')
            lx.eval('select.item "'+name+'_aoroughf0" add')
            lx.eval('select.item "'+name+'_opacity" add')
            lx.eval('select.item "'+name+'_luminouscolor" add')
            lx.eval('select.item "'+name+'_luminousamount" add')
        else:
            lx.eval('select.item "'+name+'_diffuse" set')
            lx.eval('select.item "'+name+'_reflection" add')
            lx.eval('select.item "'+name+'_ao" add')
            lx.eval('select.item "'+name+'_roughness" add')
            lx.eval('select.item "'+name+'_f0" add')
            lx.eval('select.item "'+name+'_opacity" add')
            lx.eval('select.item "'+name+'_luminouscolor" add')
            lx.eval('select.item "'+name+'_luminousamount" add')

    lx.eval('select.item "'+name+'_normal" add')
    lx.eval('select.item "'+name+'_height" add')
    lx.eval('!clip.reload')
    lx.eval("select.drop item")


def addMaterials(out_path,mat_names,ext,rndr,packed,normal):

    materials = mat_names.split("|")

    scene = modo.scene.current()
    scene.select( [i for i in scene.iterItems(itype=modo.c.MASK_TYPE)] )
    masks = scene.selectedByType(modo.c.MASK_TYPE)
    if rndr == "UE4":
        for mat in materials:
            alt_name = "UE4_"+mat + " (Material)"
            item = None
            for m in masks:
                if m.name == ("UE4_"+mat) or m.name == alt_name:
                    item = m

            if item == None:
                if int(packed) == 1:
                    hh_ue4.addUE4Pkd(out_path,ext,mat,normal)
                else:
                    hh_ue4.addUE4(out_path,ext,mat,normal)
            else:
                updateImages(rndr,mat,packed)

    elif rndr == "UNITY":
        for mat in materials:
            alt_name = "UT_"+mat + " (Material)"
            item = None
            for m in masks:
                if m.name == ("UT_"+mat) or m.name == alt_name:
                    item = m

            if item == None:
                if int(packed) == 1:
                    hh_unity.addUnityPkd(out_path,ext,mat,normal)
                else:
                    hh_unity.addUnity(out_path,ext,mat,normal)
            else:
                updateImages(rndr,mat,packed)

    else:
        for mat in materials:
            alt_name = "STD_"+mat + " (Material)"
            item = None
            for m in masks:
                if m.name == ("STD_"+mat) or m.name == alt_name:
                    item = m

            if item == None:
                if int(packed) == 1:
                    hh_std.addDefaultPkd(out_path,ext,mat,normal)
                else:
                    hh_std.addDefault(out_path,ext,mat,normal)
            else:
                updateImages(rndr,mat,packed)

    return



args = lx.args()
addMaterials(args[0],args[1],args[2],args[3],args[4],args[5])
