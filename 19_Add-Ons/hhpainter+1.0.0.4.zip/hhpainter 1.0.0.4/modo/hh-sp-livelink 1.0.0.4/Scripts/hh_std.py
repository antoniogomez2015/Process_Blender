#python

#Xolotl Studio
#Created by Ymmanuel Flores on 2018
#Copyright 2018 Crowdorchestra SAPI de CV. All rights reserved.
#hhconnect v 1.0.0.4

import lx
import modo
import os

def addDefault(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    mat_name = "STD_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false default"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_diffuse."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect diffColor")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_reflection."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect specColor")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_roughness."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect rough")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_f0."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect specAmount")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_opacity."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_opacity."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect dissolve")
        lx.eval('item.channel textureLayer$invert true')
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_luminouscolor."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect lumiColor")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_luminousamount."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_luminousamount."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect lumiAmount")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normal")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect displace")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("item.channel imageMap$min -1.0")
    lx.eval("item.channel imageMap$max 1.0")
    lx.eval("!!clip.reload")


def addDefaultPkd(out_path,mat_ext,name,normal):
    scene = modo.scene.current()
    mat_name = "STD_"+name

    lx.eval("poly.setMaterial \"%s\" {0.6 0.6 0.6} 0.8 0.04 true false false default"%mat_name)
    material = scene.selectedByType('advancedMaterial')
    mask = scene.selectedByType('mask')

    txtMap = '"'+out_path + "/"+name+"_diffuse."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect diffColor")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_reflection."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 1"%mask[0].id)
    lx.eval("shader.setEffect specColor")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_aoroughf0."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect rough")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba green")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_aoroughf0."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 2"%mask[0].id)
    lx.eval("shader.setEffect specAmount")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba blue")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_opacity."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_opacity."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect dissolve")
        lx.eval('item.channel textureLayer$invert true')
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_luminouscolor."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_luminouscolor."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect lumiColor")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:sRGB"')
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_luminousamount."+mat_ext+'"'
    if os.path.isfile(out_path + "/"+name+"_luminousamount."+mat_ext):
        lx.eval('clip.addStill %s'%txtMap)
        texture = scene.selectedByType('videoStill')
        lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
        lx.eval("texture.new clip:{%s}"%texture[0].id)
        lx.eval("texture.parent %s 2"%mask[0].id)
        lx.eval("shader.setEffect lumiAmount")
        lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
        lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
        lx.eval("item.channel imageMap$swizzling true")
        lx.eval("item.channel imageMap$rgba ignore")
        lx.eval("!!clip.reload")

    txtMap = '"'+out_path + "/"+name+"_normal."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect normal")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    if int(normal) != 1:
        lx.eval("item.channel imageMap$greenInv true")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("!!clip.reload")


    txtMap = '"'+out_path + "/"+name+"_height."+mat_ext+'"'
    lx.eval('clip.addStill %s'%txtMap)
    texture = scene.selectedByType('videoStill')
    lx.eval("select.subItem %s set textureLayer;light;render;environment"%mask[0].id)
    lx.eval("texture.new clip:{%s}"%texture[0].id)
    lx.eval("texture.parent %s 5"%mask[0].id)
    lx.eval("shader.setEffect displace")
    lx.eval("item.channel imageMap$swizzling true")
    lx.eval("item.channel imageMap$rgba ignore")
    lx.eval("item.channel textureLayer(txtrLocator)$projType uv")
    lx.eval('item.channel videoStill$colorspace "nuke-default:linear"')
    lx.eval("item.channel imageMap$min -1.0")
    lx.eval("item.channel imageMap$max 1.0")
    lx.eval("!!clip.reload")
