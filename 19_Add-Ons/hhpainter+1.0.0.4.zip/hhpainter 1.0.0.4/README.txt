Install & Use Tutorials:

Blender: https://youtu.be/U5w2K8HN6lE
Modo: https://youtu.be/xMK8T19QVsA
Maya:  https://youtu.be/OdMXGIec4N4
3DSMax: https://youtu.be/zrpWKk7Jp4Y
Houdini: https://youtu.be/sU0B7sBvWAQ
Cinema 4D: https://youtu.be/DhuZe5HHrHs

Questions & Requests:
https://discord.gg/ZatBBXe

Twitter:
https://twitter.com/ymmanuel_who
https://twitter.com/xolotl_studio

Youtube:
https://www.youtube.com/c/XolotlStudio
