# yPanel
yPanel is a Blender addon that consists of many tools to help you creating realtime asset.

#### Guide videos:

Introduction:

[![IMAGE ALT TEXT HERE](http://i3.ytimg.com/vi/6KSGgJYi-iw/maxresdefault.jpg)](https://www.youtube.com/watch?v=6KSGgJYi-iw)

Paint Slots:

[![IMAGE ALT TEXT HERE](http://i3.ytimg.com/vi/1IXvoF7osag/maxresdefault.jpg)](https://www.youtube.com/watch?v=1IXvoF7osag)

Material Override:

[![IMAGE ALT TEXT HERE](http://i3.ytimg.com/vi/x_dSI4JApOY/maxresdefault.jpg)](https://www.youtube.com/watch?v=x_dSI4JApOY)

Bake Tools:

[![IMAGE ALT TEXT HERE](http://i3.ytimg.com/vi/ghJgnjskwyM/maxresdefault.jpg)](https://www.youtube.com/watch?v=ghJgnjskwyM)
