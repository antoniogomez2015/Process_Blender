bl_info = {
    "name": "Accent Layers",
    "author": "Minimalist Soft",
    "location": "View3D > Tools Panel /Properties panel",
    "version": (1, 0, 0),
    "blender": (2, 7, 8),
    "description": "Edit mode layers for Modeling. Shift + ` for solo layer toggling.",
    "wiki_url": "https://blendermarket.com/creator/products/accent-pro-edit-mode-layers/",
    "category": "3D View"
    }

import bpy
from bpy.props import *
import bmesh

# ---
# Toggle Button Functions
# ---

def VisibleToggle1(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer1 = bm.faces.layers.int.get("selectionLayer_1")

    if scnobj.accent_layers_prop_grp.VisibleType1 ==True:
        for f in bm.faces:
            if f[customlayer1]:
                bm.faces[f.index].hide_set(False)

    if scnobj.accent_layers_prop_grp.VisibleType1 ==False:
        for f in bm.faces:
            if f[customlayer1]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle2(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer2 = bm.faces.layers.int.get("selectionLayer_2")

    if scnobj.accent_layers_prop_grp.VisibleType2 ==True:
        for f in bm.faces:
            if f[customlayer2]:
                bm.faces[f.index].hide_set(False)
    if scnobj.accent_layers_prop_grp.VisibleType2 ==False:
        for f in bm.faces:
            if f[customlayer2]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle3(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer3 = bm.faces.layers.int.get("selectionLayer_3")

    if scnobj.accent_layers_prop_grp.VisibleType3 ==True:
        for f in bm.faces:
            if f[customlayer3]:
                bm.faces[f.index].hide_set(False)
    if scnobj.accent_layers_prop_grp.VisibleType3 ==False:
        for f in bm.faces:
            if f[customlayer3]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle4(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer4 = bm.faces.layers.int.get("selectionLayer_4")

    if scnobj.accent_layers_prop_grp.VisibleType4 ==True:
        for f in bm.faces:
            if f[customlayer4]:
                bm.faces[f.index].hide_set(False)

    if scnobj.accent_layers_prop_grp.VisibleType4 ==False:
        for f in bm.faces:
            if f[customlayer4]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle5(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer5 = bm.faces.layers.int.get("selectionLayer_5")

    if scnobj.accent_layers_prop_grp.VisibleType5 ==True:
        for f in bm.faces:
            if f[customlayer5]:
                bm.faces[f.index].hide_set(False)
    if scnobj.accent_layers_prop_grp.VisibleType5 ==False:
        for f in bm.faces:
            if f[customlayer5]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle6(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer6 = bm.faces.layers.int.get("selectionLayer_6")

    if scnobj.accent_layers_prop_grp.VisibleType6 ==True:
        for f in bm.faces:
            if f[customlayer6]:
                bm.faces[f.index].hide_set(False)
    if scnobj.accent_layers_prop_grp.VisibleType6 ==False:
        for f in bm.faces:
            if f[customlayer6]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle7(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer7 = bm.faces.layers.int.get("selectionLayer_7")

    if scnobj.accent_layers_prop_grp.VisibleType7 ==True:
        for f in bm.faces:
            if f[customlayer7]:
                bm.faces[f.index].hide_set(False)

    if scnobj.accent_layers_prop_grp.VisibleType7 ==False:
        for f in bm.faces:
            if f[customlayer7]:
                bm.faces[f.index].hide_set(True)
    return

def VisibleToggle8(self, context):
    obj = bpy.context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    scnobj = bpy.context.object
    customlayer8 = bm.faces.layers.int.get("selectionLayer_8")

    if scnobj.accent_layers_prop_grp.VisibleType8 ==True:
        for f in bm.faces:
            if f[customlayer8]:
                bm.faces[f.index].hide_set(False)
    if scnobj.accent_layers_prop_grp.VisibleType8 ==False:
        for f in bm.faces:
            if f[customlayer8]:
                bm.faces[f.index].hide_set(True)
    return

# ---
# Group Properties
# ---

class AccentLayersPropertyGroup(bpy.types.PropertyGroup):
    LockType1 = bpy.props.BoolProperty(name="Lock1")
    LockType2 = bpy.props.BoolProperty(name="Lock2")
    LockType3 = bpy.props.BoolProperty(name="Lock3")
    LockType4 = bpy.props.BoolProperty(name="Lock4")
    LockType5 = bpy.props.BoolProperty(name="Lock5")
    LockType6 = bpy.props.BoolProperty(name="Lock6")
    LockType7 = bpy.props.BoolProperty(name="Lock7")
    LockType8 = bpy.props.BoolProperty(name="Lock8")
    VisibleType1 = bpy.props.BoolProperty(name="Visible1", update=VisibleToggle1)
    VisibleType2 = bpy.props.BoolProperty(name="Visible2", update=VisibleToggle2)
    VisibleType3 = bpy.props.BoolProperty(name="Visible3", update=VisibleToggle3)
    VisibleType4 = bpy.props.BoolProperty(name="Visible4", update=VisibleToggle4)
    VisibleType5 = bpy.props.BoolProperty(name="Visible5", update=VisibleToggle5)
    VisibleType6 = bpy.props.BoolProperty(name="Visible6", update=VisibleToggle6)
    VisibleType7 = bpy.props.BoolProperty(name="Visible7", update=VisibleToggle7)
    VisibleType8 = bpy.props.BoolProperty(name="Visible8", update=VisibleToggle8)
    StringType1 = bpy.props.StringProperty(name ="String1")
    StringType2 = bpy.props.StringProperty(name ="String2")
    StringType3 = bpy.props.StringProperty(name ="String3")
    StringType4 = bpy.props.StringProperty(name ="String4")
    StringType5 = bpy.props.StringProperty(name ="String5")
    StringType6 = bpy.props.StringProperty(name ="String6")
    StringType7 = bpy.props.StringProperty(name ="String7")
    StringType8 = bpy.props.StringProperty(name ="String8")


# ---
# Storing/ Add Functions
# ---

def StoreLayer1(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer1 = bm.faces.layers.int.get("selectionLayer_1")
    if not selectionLayer1:
        selectionLayer1 = bm.faces.layers.int.new("selectionLayer_1")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer1] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType1 == False:
                for f in bm.faces:
                    if f[selectionLayer1]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer2(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer2 = bm.faces.layers.int.get("selectionLayer_2")
    if not selectionLayer2:
        selectionLayer2 = bm.faces.layers.int.new("selectionLayer_2")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer2] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType2 == False:
                for f in bm.faces:
                    if f[selectionLayer2]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer3(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer3 = bm.faces.layers.int.get("selectionLayer_3")
    if not selectionLayer3:
        selectionLayer3 = bm.faces.layers.int.new("selectionLayer_3")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer3] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType3 == False:
                for f in bm.faces:
                    if f[selectionLayer3]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer4(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer4 = bm.faces.layers.int.get("selectionLayer_4")
    if not selectionLayer4:
        selectionLayer4 = bm.faces.layers.int.new("selectionLayer_4")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer4] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType4 == False:
                for f in bm.faces:
                    if f[selectionLayer4]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer5(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer5 = bm.faces.layers.int.get("selectionLayer_5")
    if not selectionLayer5:
        selectionLayer5 = bm.faces.layers.int.new("selectionLayer_5")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer5] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType5 == False:
                for f in bm.faces:
                    if f[selectionLayer5]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer6(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer6 = bm.faces.layers.int.get("selectionLayer_6")
    if not selectionLayer6:
        selectionLayer6 = bm.faces.layers.int.new("selectionLayer_6")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer6] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType6 == False:
                for f in bm.faces:
                    if f[selectionLayer6]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer7(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer7 = bm.faces.layers.int.get("selectionLayer_7")
    if not selectionLayer7:
        selectionLayer7 = bm.faces.layers.int.new("selectionLayer_7")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer7] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType7 == False:
                for f in bm.faces:
                    if f[selectionLayer7]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def StoreLayer8(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    scnobj = bpy.context.object
    selectionLayer8 = bm.faces.layers.int.get("selectionLayer_8")
    if not selectionLayer8:
        selectionLayer8 = bm.faces.layers.int.new("selectionLayer_8")
    for f in bm.faces:
        if not f.select:
            pass
        else:
            f[selectionLayer8] = int(f.select)
        if scnobj.accent_layers_prop_grp.VisibleType8 == False:
                for f in bm.faces:
                    if f[selectionLayer8]:
                        bm.faces[f.index].hide_set(True)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

# ---
# Clear Functions
# ---

def ClearLayer1(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer1 = bm.faces.layers.int.get("selectionLayer_1")
    if not selectionLayer1:
        selectionLayer1 = bm.faces.layers.int.new("selectionLayer_1")
    for f in bm.faces:
        f[selectionLayer1] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer2(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer2 = bm.faces.layers.int.get("selectionLayer_2")
    if not selectionLayer2:
        selectionLayer2 = bm.faces.layers.int.new("selectionLayer_2")
    for f in bm.faces:
        f[selectionLayer2] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer3(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer3 = bm.faces.layers.int.get("selectionLayer_3")
    if not selectionLayer3:
        selectionLayer3 = bm.faces.layers.int.new("selectionLayer_3")
    for f in bm.faces:
        f[selectionLayer3] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer4(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer4 = bm.faces.layers.int.get("selectionLayer_4")
    if not selectionLayer4:
        selectionLayer4 = bm.faces.layers.int.new("selectionLayer_4")
    for f in bm.faces:
        f[selectionLayer4] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer5(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer5 = bm.faces.layers.int.get("selectionLayer_5")
    if not selectionLayer5:
        selectionLayer5 = bm.faces.layers.int.new("selectionLayer_5")
    for f in bm.faces:
        f[selectionLayer5] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer6(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer6 = bm.faces.layers.int.get("selectionLayer_6")
    if not selectionLayer6:
        selectionLayer6 = bm.faces.layers.int.new("selectionLayer_6")
    for f in bm.faces:
        f[selectionLayer6] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer7(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer7 = bm.faces.layers.int.get("selectionLayer_7")
    if not selectionLayer7:
        selectionLayer7 = bm.faces.layers.int.new("selectionLayer_7")
    for f in bm.faces:
        f[selectionLayer7] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

def ClearLayer8(caller, context):
    obj = bpy.context.edit_object
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selectionLayer8 = bm.faces.layers.int.get("selectionLayer_8")
    if not selectionLayer8:
        selectionLayer8 = bm.faces.layers.int.new("selectionLayer_8")
    for f in bm.faces:
        f[selectionLayer8] = int(f.select)
    bmesh.update_edit_mesh(mesh)
    mesh.update()

    return

# ---
# Layout
# ---

class LayoutPanelAccentLayers(bpy.types.Panel):
    bl_label = "Accent Layers"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_context = "mesh_edit"
    bl_category = "Accent"

    def draw(self, context):
        scn = bpy.context.scene
        scnobj = bpy.context.object
        layout = self.layout
        obj = bpy.context.edit_object
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)

        visible_icon1 = 'PROP_OFF'
        visible_icon2 = 'PROP_OFF'
        visible_icon3 = 'PROP_OFF'
        visible_icon4 = 'PROP_OFF'
        visible_icon5 = 'PROP_OFF'
        visible_icon6 = 'PROP_OFF'
        visible_icon7 = 'PROP_OFF'
        visible_icon8 = 'PROP_OFF'

        row = layout.row(align=True)
        row.scale_y = 1.5
        row.scale_x = 2.1
        row.operator("show_type.button", text = "", icon = 'OBJECT_DATA')
        row.operator("toggle_type.button", text = "", icon = 'BBOX')
        row.operator("layout_type.button", text ="", icon = 'UV_ISLANDSEL').loc ="invselect_type"

        selectionLayer1 = bm.faces.layers.int.get("selectionLayer_1")
        if not selectionLayer1:
            selectionLayer1 = bm.faces.layers.int.new("selectionLayer_1")
        for x in bm.faces:
            if (x[selectionLayer1]):
                if scnobj.accent_layers_prop_grp.VisibleType1:
                    visible_icon1 = 'PROP_ON'
                else:
                    visible_icon1 = 'PROP_ON'

        selectionLayer2 = bm.faces.layers.int.get("selectionLayer_2")
        if not selectionLayer2:
            selectionLayer2 = bm.faces.layers.int.new("selectionLayer_2")
        for y in bm.faces:
            if (y[selectionLayer2]):
                if scnobj.accent_layers_prop_grp.VisibleType2:
                    visible_icon2 = 'PROP_ON'
                else:
                    visible_icon2 = 'PROP_ON'

        selectionLayer3 = bm.faces.layers.int.get("selectionLayer_3")
        if not selectionLayer3:
            selectionLayer3 = bm.faces.layers.int.new("selectionLayer_3")
        for z in bm.faces:
            if (z[selectionLayer3]):
                if scnobj.accent_layers_prop_grp.VisibleType3:
                    visible_icon3 = 'PROP_ON'
                else:
                    visible_icon3 = 'PROP_ON'

        selectionLayer4 = bm.faces.layers.int.get("selectionLayer_4")
        if not selectionLayer4:
            selectionLayer4 = bm.faces.layers.int.new("selectionLayer_4")
        for x in bm.faces:
            if (x[selectionLayer4]):
                if scnobj.accent_layers_prop_grp.VisibleType4:
                    visible_icon4 = 'PROP_ON'
                else:
                    visible_icon4 = 'PROP_ON'

        selectionLayer5 = bm.faces.layers.int.get("selectionLayer_5")
        if not selectionLayer5:
            selectionLayer5 = bm.faces.layers.int.new("selectionLayer_5")
        for y in bm.faces:
            if (y[selectionLayer5]):
                if scnobj.accent_layers_prop_grp.VisibleType5:
                    visible_icon5 = 'PROP_ON'
                else:
                    visible_icon5 = 'PROP_ON'

        selectionLayer6 = bm.faces.layers.int.get("selectionLayer_6")
        if not selectionLayer6:
            selectionLayer6 = bm.faces.layers.int.new("selectionLayer_6")
        for z in bm.faces:
            if (z[selectionLayer6]):
                if scnobj.accent_layers_prop_grp.VisibleType6:
                    visible_icon6 = 'PROP_ON'
                else:
                    visible_icon6 = 'PROP_ON'

        selectionLayer7 = bm.faces.layers.int.get("selectionLayer_7")
        if not selectionLayer7:
            selectionLayer7 = bm.faces.layers.int.new("selectionLayer_7")
        for x in bm.faces:
            if (x[selectionLayer7]):
                if scnobj.accent_layers_prop_grp.VisibleType7:
                    visible_icon7 = 'PROP_ON'
                else:
                    visible_icon7 = 'PROP_ON'

        selectionLayer8 = bm.faces.layers.int.get("selectionLayer_8")
        if not selectionLayer8:
            selectionLayer8 = bm.faces.layers.int.new("selectionLayer_8")
        for y in bm.faces:
            if (y[selectionLayer8]):
                if scnobj.accent_layers_prop_grp.VisibleType8:
                    visible_icon8 = 'PROP_ON'
                else:
                    visible_icon8 = 'PROP_ON'

        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType1', text = "", toggle = True, icon ='LOCKED')
        row1 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType1', text="")
        row1.scale_y = 1.1
        row1.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_1"
        row1.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_1"
        row1.scale_x = 2.1
        row1.prop(scnobj.accent_layers_prop_grp, 'VisibleType1', text = "", toggle = True, icon = visible_icon1)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05
        row.operator("layout_type.button", text = "")

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType2', text = "", toggle = True, icon ='LOCKED')
        row2 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType2', text="")
        row2.scale_y = 1.1
        row2.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_2"
        row2.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_2"
        row2.scale_x = 2.1
        row2.prop(scnobj.accent_layers_prop_grp, 'VisibleType2', text = "", toggle = True, icon = visible_icon2)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05 
        row.operator("layout_type.button", text = "")

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType3', text = "", toggle = True, icon ='LOCKED')
        row3 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType3', text="")
        row3.scale_y = 1.1
        row3.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_3"
        row3.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_3"
        row3.scale_x = 2.1
        row3.prop(scnobj.accent_layers_prop_grp, 'VisibleType3', text = "", toggle = True, icon = visible_icon3)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05
        row.operator("layout_type.button", text = "")
        
        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType4', text = "", toggle = True, icon ='LOCKED')
        row4 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType4', text="")
        row4.scale_y = 1.1
        row4.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_4"
        row4.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_4"
        row4.scale_x = 2.1
        row4.prop(scnobj.accent_layers_prop_grp, 'VisibleType4', text = "", toggle = True, icon = visible_icon4)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05
        row.operator("layout_type.button", text = "")

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType5', text = "", toggle = True, icon ='LOCKED')
        row5 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType5', text="")
        row5.scale_y = 1.1
        row5.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_5"
        row5.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_5"
        row5.scale_x = 2.1
        row5.prop(scnobj.accent_layers_prop_grp, 'VisibleType5', text = "", toggle = True, icon = visible_icon5)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05 
        row.operator("layout_type.button", text = "")

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType6', text = "", toggle = True, icon ='LOCKED')
        row6 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType6', text="")
        row6.scale_y = 1.1
        row6.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_6"
        row6.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_6"
        row6.scale_x = 2.1
        row6.prop(scnobj.accent_layers_prop_grp, 'VisibleType6', text = "", toggle = True, icon = visible_icon6)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05
        row.operator("layout_type.button", text = "")
        
        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType7', text = "", toggle = True, icon ='LOCKED')
        row7 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType7', text="")
        row7.scale_y = 1.1
        row7.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_7"
        row7.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_7"
        row7.scale_x = 2.1
        row7.prop(scnobj.accent_layers_prop_grp, 'VisibleType7', text = "", toggle = True, icon = visible_icon7)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05
        row.operator("layout_type.button", text = "")

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.prop(scnobj.accent_layers_prop_grp, 'LockType8', text = "", toggle = True, icon ='LOCKED')
        row8 = layout.row(align=True)
        col = row.column()
        col.prop(scnobj.accent_layers_prop_grp, 'StringType8', text="")
        row8.scale_y = 1.1
        row8.operator("layout_type.button", text = "", icon="FILE_BLANK").loc ="save_type_8"
        row8.operator("layout_type.button", text = "", icon='X_VEC').loc ="clear_type_8"
        row8.scale_x = 2.1
        row8.prop(scnobj.accent_layers_prop_grp, 'VisibleType8', text = "", toggle = True, icon = visible_icon8)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 0.05 
        row.operator("layout_type.button", text = "")

        if scnobj.accent_layers_prop_grp.LockType1 == True:
            row1.enabled=False
        else:
            row1.enabled=True

        if scnobj.accent_layers_prop_grp.LockType2 == True:
            row2.enabled=False
        else:
            row2.enabled=True

        if scnobj.accent_layers_prop_grp.LockType3 == True:
            row3.enabled=False
        else:
            row3.enabled=True

        if scnobj.accent_layers_prop_grp.LockType4 == True:
            row4.enabled=False
        else:
            row4.enabled=True

        if scnobj.accent_layers_prop_grp.LockType5 == True:
            row5.enabled=False
        else:
            row5.enabled=True

        if scnobj.accent_layers_prop_grp.LockType6 == True:
            row6.enabled=False
        else:
            row6.enabled=True
            
        if scnobj.accent_layers_prop_grp.LockType7 == True:
            row7.enabled=False
        else:
            row7.enabled=True

        if scnobj.accent_layers_prop_grp.LockType8 == True:
            row8.enabled=False
        else:
            row8.enabled=True   
            
        return

# ---
# Button Operators
# ---

class ActionButtonShow(bpy.types.Operator):
    bl_idname = "show_type.button"
    bl_label = "`Show All Layers"
 
    def execute(self, context):
        obj = bpy.context.edit_object
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bp = bpy.ops.mesh
        scn = bpy.context.scene
        AllOn(self, context)
        return{'FINISHED'}

class ActionSolo(bpy.types.Operator):
    bl_idname = "toggle_type.button"
    bl_label = "`Solo Layer"
 
    def execute(self, context):
        scnobj = bpy.context.object
        edit_obj = bpy.context.edit_object
        if edit_obj is not None:
            if scnobj.accent_layers_prop_grp.VisibleType1 == False and scnobj.accent_layers_prop_grp.VisibleType2 == False and scnobj.accent_layers_prop_grp.VisibleType3 == False and scnobj.accent_layers_prop_grp.VisibleType4 == False and scnobj.accent_layers_prop_grp.VisibleType5 == False and scnobj.accent_layers_prop_grp.VisibleType6 == False and scnobj.accent_layers_prop_grp.VisibleType7 == False and scnobj.accent_layers_prop_grp.VisibleType8 == False:
                scnobj.accent_layers_prop_grp.VisibleType1 = True

            elif scnobj.accent_layers_prop_grp.VisibleType1:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = True
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False

            elif scnobj.accent_layers_prop_grp.VisibleType2:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = True
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False

            elif scnobj.accent_layers_prop_grp.VisibleType3:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = True
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False
                
            elif scnobj.accent_layers_prop_grp.VisibleType4:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = True
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False

            elif scnobj.accent_layers_prop_grp.VisibleType5:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = True
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False

            elif scnobj.accent_layers_prop_grp.VisibleType6:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = True
                scnobj.accent_layers_prop_grp.VisibleType8 = False
                
            elif scnobj.accent_layers_prop_grp.VisibleType7:
                scnobj.accent_layers_prop_grp.VisibleType1 = False
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = True

            elif scnobj.accent_layers_prop_grp.VisibleType8:
                scnobj.accent_layers_prop_grp.VisibleType1 = True
                scnobj.accent_layers_prop_grp.VisibleType2 = False
                scnobj.accent_layers_prop_grp.VisibleType3 = False
                scnobj.accent_layers_prop_grp.VisibleType4 = False
                scnobj.accent_layers_prop_grp.VisibleType5 = False
                scnobj.accent_layers_prop_grp.VisibleType6 = False
                scnobj.accent_layers_prop_grp.VisibleType7 = False
                scnobj.accent_layers_prop_grp.VisibleType8 = False
        return{'FINISHED'}

class ActionButton(bpy.types.Operator):
    bl_idname = "layout_type.button"
    bl_label = "`Press"

    loc = bpy.props.StringProperty()

    def execute(self, context):
        bp = bpy.ops.mesh
        scnobj = bpy.context.object
        obj = bpy.context.edit_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        customlayer1 = bm.faces.layers.int.get("selectionLayer_1")
        customlayer2 = bm.faces.layers.int.get("selectionLayer_2")
        customlayer3 = bm.faces.layers.int.get("selectionLayer_3")
        customlayer4 = bm.faces.layers.int.get("selectionLayer_4")
        customlayer5 = bm.faces.layers.int.get("selectionLayer_5")
        customlayer6 = bm.faces.layers.int.get("selectionLayer_6")
        customlayer7 = bm.faces.layers.int.get("selectionLayer_7")
        customlayer8 = bm.faces.layers.int.get("selectionLayer_8")

        if self.loc == "invselect_type":
            bp.select_all(action='INVERT')

        if self.loc == "save_type_1":
            StoreLayer1(self, context)

        if self.loc == "save_type_2":
            StoreLayer2(self, context)

        if self.loc == "save_type_3":
            StoreLayer3(self, context)
            
        if self.loc == "save_type_4":
            StoreLayer4(self, context)

        if self.loc == "save_type_5":
            StoreLayer5(self, context)

        if self.loc == "save_type_6":
            StoreLayer6(self, context)
            
        if self.loc == "save_type_7":
            StoreLayer7(self, context)

        if self.loc == "save_type_8":
            StoreLayer8(self, context)

        if self.loc == "clear_type_1":
            scnobj.accent_layers_prop_grp.VisibleType1 = True
            bp.select_all(action='DESELECT')
            ClearLayer1(self, context)
            scnobj.accent_layers_prop_grp.VisibleType1 = False
        if self.loc == "clear_type_2":
            scnobj.accent_layers_prop_grp.VisibleType2 = True
            bp.select_all(action='DESELECT')
            ClearLayer2(self, context)
            scnobj.accent_layers_prop_grp.VisibleType2 = False
        if self.loc == "clear_type_3":
            scnobj.accent_layers_prop_grp.VisibleType3 = True
            bp.select_all(action='DESELECT')
            ClearLayer3(self, context)
            scnobj.accent_layers_prop_grp.VisibleType3 = False
        if self.loc == "clear_type_4":
            scnobj.accent_layers_prop_grp.VisibleType4 = True
            bp.select_all(action='DESELECT')
            ClearLayer4(self, context)
            scnobj.accent_layers_prop_grp.VisibleType4 = False
        if self.loc == "clear_type_5":
            scnobj.accent_layers_prop_grp.VisibleType5 = True
            bp.select_all(action='DESELECT')
            ClearLayer5(self, context)
            scnobj.accent_layers_prop_grp.VisibleType5 = False
        if self.loc == "clear_type_6":
            scnobj.accent_layers_prop_grp.VisibleType6 = True
            bp.select_all(action='DESELECT')
            ClearLayer6(self, context)
            scnobj.accent_layers_prop_grp.VisibleType6 = False
        if self.loc == "clear_type_7":
            scnobj.accent_layers_prop_grp.VisibleType7 = True
            bp.select_all(action='DESELECT')
            ClearLayer7(self, context)
            scnobj.accent_layers_prop_grp.VisibleType7 = False
        if self.loc == "clear_type_8":
            scnobj.accent_layers_prop_grp.VisibleType8 = True
            bp.select_all(action='DESELECT')
            ClearLayer8(self, context)
            scnobj.accent_layers_prop_grp.VisibleType8 = False

        return {'FINISHED'}

# ---
# All On Function
# ---

def AllOn(self, context):
    scnobj = bpy.context.object
    bm = bmesh.from_edit_mesh(bpy.context.edit_object.data)
    selectionLayer1 = bm.faces.layers.int.get("selectionLayer_1")
    selectionLayer2 = bm.faces.layers.int.get("selectionLayer_2")
    selectionLayer3 = bm.faces.layers.int.get("selectionLayer_3")
    selectionLayer4 = bm.faces.layers.int.get("selectionLayer_4")
    selectionLayer5 = bm.faces.layers.int.get("selectionLayer_5")
    selectionLayer6 = bm.faces.layers.int.get("selectionLayer_6")
    selectionLayer7 = bm.faces.layers.int.get("selectionLayer_7")
    selectionLayer8 = bm.faces.layers.int.get("selectionLayer_8")

    if not selectionLayer1:
        selectionLayer1 = bm.faces.layers.int.new("selectionLayer_1")
    if not selectionLayer2:
        selectionLayer2 = bm.faces.layers.int.new("selectionLayer_2")
    if not selectionLayer3:
        selectionLayer3 = bm.faces.layers.int.new("selectionLayer_3")
    if not selectionLayer4:
        selectionLayer4 = bm.faces.layers.int.new("selectionLayer_4")
    if not selectionLayer5:
        selectionLayer5 = bm.faces.layers.int.new("selectionLayer_5")
    if not selectionLayer6:
        selectionLayer6 = bm.faces.layers.int.new("selectionLayer_6")
    if not selectionLayer7:
        selectionLayer7 = bm.faces.layers.int.new("selectionLayer_7")
    if not selectionLayer8:
        selectionLayer8 = bm.faces.layers.int.new("selectionLayer_8")

    if scnobj.accent_layers_prop_grp.LockType1 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType1 == True):
                scnobj.accent_layers_prop_grp.VisibleType1 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType1 == False):
                scnobj.accent_layers_prop_grp.VisibleType1 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer1])==1:
                scnobj.accent_layers_prop_grp.VisibleType1 = True
                break
    
    if scnobj.accent_layers_prop_grp.LockType2 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType2 == True):
                scnobj.accent_layers_prop_grp.VisibleType2 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType2 == False):
                scnobj.accent_layers_prop_grp.VisibleType2 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer2])==1:
                scnobj.accent_layers_prop_grp.VisibleType2 = True
                break
    
    if scnobj.accent_layers_prop_grp.LockType3 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType3 == True):
                scnobj.accent_layers_prop_grp.VisibleType3 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType3 == False):
                scnobj.accent_layers_prop_grp.VisibleType3 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer3])==1:
                scnobj.accent_layers_prop_grp.VisibleType3 = True
                break
                
    if scnobj.accent_layers_prop_grp.LockType4 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType4 == True):
                scnobj.accent_layers_prop_grp.VisibleType4 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType4 == False):
                scnobj.accent_layers_prop_grp.VisibleType4 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer4])==1:
                scnobj.accent_layers_prop_grp.VisibleType4 = True
                break
    
    if scnobj.accent_layers_prop_grp.LockType5 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType5 == True):
                scnobj.accent_layers_prop_grp.VisibleType5 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType5 == False):
                scnobj.accent_layers_prop_grp.VisibleType5 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer5])==1:
                scnobj.accent_layers_prop_grp.VisibleType5 = True
                break
    
    if scnobj.accent_layers_prop_grp.LockType6 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType6 == True):
                scnobj.accent_layers_prop_grp.VisibleType6 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType6 == False):
                scnobj.accent_layers_prop_grp.VisibleType6 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer6])==1:
                scnobj.accent_layers_prop_grp.VisibleType6 = True
                break
                
    if scnobj.accent_layers_prop_grp.LockType7 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType7 == True):
                scnobj.accent_layers_prop_grp.VisibleType7 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType7 == False):
                scnobj.accent_layers_prop_grp.VisibleType7 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer7])==1:
                scnobj.accent_layers_prop_grp.VisibleType7 = True
                break
    
    if scnobj.accent_layers_prop_grp.LockType8 == True:
        for f in bm.faces:
            if (scnobj.accent_layers_prop_grp.VisibleType8 == True):
                scnobj.accent_layers_prop_grp.VisibleType8 = True
            elif (scnobj.accent_layers_prop_grp.VisibleType8 == False):
                scnobj.accent_layers_prop_grp.VisibleType8 = False
    else:
        for f in bm.faces:
            if (f[selectionLayer8])==1:
                scnobj.accent_layers_prop_grp.VisibleType8 = True
                break

    return


# ---
# Add Menu Access: Edit Mode> Mesh
# ---

def menu_func(self, context):
    self.layout.operator(ActionButtonShow.bl_idname)
    self.layout.operator(ActionSolo.bl_idname)
    
# ---
# Add Keymap
# ---

addon_keymaps = []

# ---
# Registers
# ---

def register():
    bpy.utils.register_module(__name__)
    bpy.types.VIEW3D_MT_edit_mesh.append(menu_func)
    bpy.types.Object.accent_layers_prop_grp = bpy.props.PointerProperty(type=AccentLayersPropertyGroup)

# ---
# Handle the Keymap
# ---

    kcfg = bpy.context.window_manager.keyconfigs.addon
    if kcfg:
        km = kcfg.keymaps.new(name='Mesh', space_type='EMPTY')
        kmi = km.keymap_items.new(ActionSolo.bl_idname, type='ACCENT_GRAVE', value='PRESS', shift=True)
        addon_keymaps.append((km, kmi))

def unregister():

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_module(__name__)


if __name__ == "__main__":
    register()
