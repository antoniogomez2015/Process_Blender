This is the Git repository for [Gaffer], the Blender Add-on for speeding up your lighting workflow.

You can download it here to try it out. If you like it, please consider [purchasing it from the Blender Market]. $15 isn't much, and every sale puts a smile on my face and motivates me to keep developing it :)

A portion of every sale is donated to the [Blender Development Fund] too.

Documentation can be found in [the wiki], and a list of changes in the [commit logs] or on the [Releases page].

[Gaffer]:http://cgcookiemarkets.com/blender/all-products/gaffer-light-manager/
[purchasing it from the Blender Market]:http://cgcookiemarkets.com/blender/all-products/gaffer-light-manager/
[Blender Development Fund]:https://www.blender.org/foundation/development-fund/
[the wiki]:https://github.com/gregzaal/Gaffer/wiki
[commit logs]:https://github.com/gregzaal/Gaffer/commits/master
[Releases page]:https://github.com/gregzaal/Gaffer/releases
