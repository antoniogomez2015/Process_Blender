http://animation-nodes-manual.readthedocs.org/en/latest/
