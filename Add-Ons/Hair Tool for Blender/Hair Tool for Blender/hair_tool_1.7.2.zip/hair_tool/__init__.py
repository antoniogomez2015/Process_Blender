'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
#DONE: add converting curves (eg from zbrush) to blender Particle Hair
#DONE: randomize spacing by randomizing   t_ins? +- rand dt (same dt over length (in resample 2d)
#DONE: why flipps happnes?? cos bitangetn is 180deg from VectSurfHit. Not a bug (almost like gimaball lock)
#DONE: Resample output point count  proprotional to len of strand
#DONE: Add flip uv to options
#BUG_IN_BLENDER: GP to PartHair still sometimes is broken (depending on viewing angle)... - cos blender messes up attached hair keys,
#                Comb fix dosent always work
#DONE: GenerateVerColorRandom per strand
#CANNOTDO: ribbon profile curve if possible  - Wont work in f6 mode
#DONE: Edit Curve profile option - more complex profile like " /\/\/\ " <- 3 peaks per one curve
#DONE: option to edit uv boxes (delete, resize)
#DONE: fix align curve random flipping
#DONE: fix last material setup
#TODO: add custom clumping maybe? FIX adjust it
#WIP: add vert color, random, gradinet, flow map? Partialy done in Vertex Color Master
#TODO: fix undo in modal uv draw?


bl_info = {
    "name": "Hair Tool",
    "description": "Make hair planes from curves",
    "author": "Bartosz Styperek",
    "blender": (2, 79, 0),
    "location": "View 3D > Tools > Hair Tool",
    "version": (1, 7, 2),
    "category": "Object"
}

# load and reload submodules
##################################

if "bpy" in locals():
    import importlib
    importlib.reload(hair_tool_ui)
    importlib.reload(surface_to_splines)
    importlib.reload(curve_to_strip)
    importlib.reload(resample2d)
    importlib.reload(edit_curve_helpers)
    importlib.reload(curve_simplify)
    importlib.reload(child_strands)
    importlib.reload(uv_modal_draw_boxes)
else:
    from . import hair_tool_ui
    from . import surface_to_splines
    from . import curve_to_strip
    from . import resample2d
    from . import edit_curve_helpers
    from . import curve_simplify
    from . import child_strands
    from . import uv_modal_draw_boxes

import bpy
from bpy.props import StringProperty,IntProperty
from .hair_tool_ui import register_keymap, unregister_keymap

def draw_item(self, context):
    layout = self.layout
    layout.separator()
    layout.operator("curve.select_tips",text="Select Tips").roots = False
    layout.operator("curve.select_tips",text="Select Roots").roots = True


class hairUVPoints(bpy.types.PropertyGroup):
    start_point = bpy.props.FloatVectorProperty(name="", description="", default=(0.0, 0.0), size=2)
    end_point = bpy.props.FloatVectorProperty(name="", description="", default=(1.0, 1.0), size=2)

class hair_mesh_settings(bpy.types.PropertyGroup):
    hair_mesh_parent = StringProperty(name="", default="")
    hair_curve_child = StringProperty(name="", default="")
    hair_uv_points = bpy.props.CollectionProperty(type=hairUVPoints)
    uv_seed = IntProperty(name="UV Seed", default=20, min=1, max=1000)

class last_hair_settings(bpy.types.PropertyGroup):
    # material = StringProperty(name="", default="")
    material = bpy.props.PointerProperty(type=bpy.types.Material)
    hair_uv_points = bpy.props.CollectionProperty(type=hairUVPoints)


import traceback

def register():
    try:
        bpy.utils.register_module(__name__)
    except: traceback.print_exc()
    # lets add ourselves to the main header
    bpy.types.VIEW3D_MT_select_edit_curve.append(draw_item)
    bpy.types.Object.hair_settings = bpy.props.PointerProperty(type=hair_mesh_settings)
    bpy.types.Scene.last_hair_settings = bpy.props.PointerProperty(type=last_hair_settings)
    register_keymap()

def unregister():
    # bpy.utils.unregister_class(curve_to_strip.hair_mesh_settings)
    # bpy.utils.unregister_class(curve_to_strip.last_hair_mesh_settings)
    del bpy.types.Scene.last_hair_settings.hair_uv_points
    del bpy.types.Scene.last_hair_settings
    del bpy.types.Object.hair_settings
    try:
        bpy.utils.unregister_module(__name__)
    except: traceback.print_exc()
    bpy.types.VIEW3D_MT_select_edit_curve.remove(draw_item)

    unregister_keymap()
