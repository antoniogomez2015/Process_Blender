# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
import math
from bpy_extras import view3d_utils
import numpy as np
from mathutils import noise, Vector, kdtree
from mathutils.bvhtree import BVHTree
from .curve_to_strip import CurvesUVRefresh
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
from .resample2d import get2dInterpol, interpol, get_strand_proportions
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python35\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb
bpy.types.Object.targetObjPointer = StringProperty(name="Target", description="Target of operation")
bpy.types.Scene.GPSource = BoolProperty(name="Scene GreasePencil", description="Use Scene as Grease Pencil source if enabled \n"
                                                                           "otherwise use Object GP strokes.", default = True)

def next_edge_ring(edge, face):  # return opposite edge
    if len(face.verts) == 4:
        target_verts = [v for v in face.verts if v not in edge.verts]
        return [e for e in face.edges if
                target_verts[0] in e.verts and
                target_verts[1] in e.verts][0]
    else:
        return


def getEdgesRing(edge):
    facesLoop = []
    edgesRing = []
    while True:
        edgesRing.append(edge)
        nextFace = [f for f in edge.link_faces if f not in facesLoop]  # edge has 2 faces
        if len(nextFace) == 0:
            break
        if nextFace[0] is None:
            break
        facesLoop.append(nextFace[0])
        edge = next_edge_ring(edge, nextFace[0])
        if not edge:
            break
    return edgesRing


def sortSelectedEdgesInLoop(selected_edges):  # for now assume we get edge
    # get BMLoop that points to the right direction

    orderedSelectedEdgesList = []  # will containt all islands loops sorted
    while True:  # for islands
        cornerEdge = None
        cornerVert = None
        for e in selected_edges:
            for v in e.verts:
                if len(v.link_edges) == 2:
                    cornerEdge = e
                    cornerVert = v
                    break
            if cornerEdge:
                break
        if not cornerEdge:
            # print('Couldnt find corner for edge loop')
            vertsStorage = set()
            for e in selected_edges:  # try detecting closed loop vert count ==  edge count
                for v in e.verts:
                    vertsStorage.add(v.index)
            if len(vertsStorage) == len(selected_edges):
                # print('Closed edge loop detected')
                cornerEdge = selected_edges[0]  # set random edge as first edge
                cornerVert = selected_edges[0].verts[0]
            else:  # no edge corner, no closed edge loop detected
                return []
        # trying detecting closed loop

        nextEdge = cornerEdge
        nextVert = cornerVert
        orderedSelectedEdges = []  # will stores edge loop in individual island
        while True:  # for getting sorted edge loops in each island
            orderedSelectedEdges.append(nextEdge)
            selected_edges.remove(nextEdge)
            nextVert = nextEdge.other_vert(nextVert)
            if len(nextVert.link_edges) == 2:
                break
            nextEdge = [edge for edge in nextVert.link_edges if edge.is_boundary and edge in selected_edges]
            if not nextEdge:
                break
            else:
                nextEdge = nextEdge[0]
        orderedSelectedEdgesList.append(orderedSelectedEdges)
        if len(selected_edges) == 0:  # no more islands to check
            break
    return orderedSelectedEdgesList


def sortSelectedEdgesToVerts(selected_edges):  # for now assume we get edge
    # get BMLoop that points to the right direction

    orderedVertsLoops = []  # will containt all islands loops sorted
    while True:  # for islands
        cornerEdge = None
        cornerVert = None
        for e in selected_edges:
            for v in e.verts:
                if len(v.link_edges) == 2:
                    cornerEdge = e
                    cornerVert = v
                    break
            if cornerEdge:
                break
        if not cornerEdge:
            return []

        nextEdge = cornerEdge
        nextVert = cornerVert
        VertsLoops = []
        VertsLoops.append([])
        CheckedEdges = []
        while True:  # first pass for filling VertsLoops[0] with sharp edges/verts
            VertsLoops[0].append(nextVert)
            CheckedEdges.append(nextEdge)
            selected_edges.remove(nextEdge)
            nextVert = nextEdge.other_vert(nextVert)
            # if len(nextVert.link_edges) == 2: break
            proposedEdge = [edge for edge in nextVert.link_edges if edge in selected_edges]
            if not proposedEdge:
                VertsLoops[0].append(nextVert)  # add last vert  v -e- v  -e- (v)
                break
            else:
                nextEdge = proposedEdge[0]
        i = 0

        while True:  # try filling VertsLoops[0+n]
            VertsLoops.append([])  # add new row i+1
            for vert in VertsLoops[i]:
                for e in vert.link_edges:
                    if e not in CheckedEdges:
                        nextVert = e.other_vert(vert)
                        if nextVert not in VertsLoops[i + 1] and nextVert not in VertsLoops[
                                i]:  # next vert not in current loop, or previous loop
                            VertsLoops[i + 1].append(nextVert)
                        CheckedEdges.append(e)
            if len(VertsLoops[i + 1]) == 0:  # nothing added in this pass == break
                break
            i += 1
        VertsLoops.pop()  # remove last empty row
        orderedVertsLoops.append(VertsLoops)
        if len(selected_edges) == 0:  # no more islands to check
            break

    return orderedVertsLoops


def get_sorted_verts_co(obj):
    # --- get a mesh from the object ---
    apply_modifiers = True
    settings = 'PREVIEW'
    me = obj.to_mesh(bpy.context.scene, apply_modifiers, settings)
    bm = bmesh.new()  # create an empty BMesh
    bm.from_mesh(me)
    selected_edges = [e for e in bm.edges if not e.smooth and e.is_boundary] #get sharp boundary eges only
    if len(selected_edges) == 0:
        return 0
    orderedVertsLoopsIsland = sortSelectedEdgesToVerts(selected_edges)

    VertsCoLoops = []
    for i, orderedVertsLoops in enumerate(orderedVertsLoopsIsland):
        VertsCoLoops.append([])
        for j, VertsLoop in enumerate(orderedVertsLoops):
            VertsCoLoops[i].append([])
            for vert in VertsLoop:
                VertsCoLoops[i][j].append(vert.co)
    bm.free()
    bpy.data.meshes.remove(me)
    return VertsCoLoops


def get_edge_ring_centers(obj):
    # --- get a mesh from the object ---
    apply_modifiers = True
    settings = 'PREVIEW'
    me = obj.to_mesh(bpy.context.scene, apply_modifiers, settings)
    bm = bmesh.new()  # create an empty BMesh
    bm.from_mesh(me)
    selected_edges = [e for e in bm.edges if not e.smooth and e.is_boundary] #get sharp boundary eges only
    if len(selected_edges) == 0:
        return 0
    if len(selected_edges) == 1:
        return 1
    sorted_selected_edgesPerIslands = sortSelectedEdgesInLoop(selected_edges)  # list - island1Edges, island2Edges ...
    edge_ring_centers_List_per_island = []
    for islandEdgesLoop in sorted_selected_edgesPerIslands:  # for selected/sharp edge loops in island
        edge_ring_centers_List = []
        for loopEdge in islandEdgesLoop:  # create edge rings for sharp edge loops
            edgeRing = getEdgesRing(loopEdge)
            edge_ring_Centers = []
            for e in edgeRing:
                center = (e.verts[0].co + e.verts[1].co) / 2
                edge_ring_Centers.append(center[:])
            edge_ring_centers_List.append(edge_ring_Centers.copy())
        edge_ring_centers_List_per_island.append([list(i) for i in zip(*edge_ring_centers_List)])  # does the transpose

    bm.free()
    bpy.data.meshes.remove(me)
    return edge_ring_centers_List_per_island


def get_edge_ring_vert_co(obj):
    me = obj.data
    bm = bmesh.new()  # create an empty BMesh
    bm.from_mesh(me)
    selected_edges = [e for e in bm.edges if not e.smooth]
    sorted_selected_edgesPerIslands = sortSelectedEdgesToVerts(selected_edges)  # list - island1Edges, island2Edges ...
    edge_ring_centers_List_per_island = []
    for islandEdgesLoop in sorted_selected_edgesPerIslands:  # for selected/sharp edge loops in island
        edge_ring_centers_List = []
        for loopEdge in islandEdgesLoop:  # create edge rings for sharp edge loops
            currentVert = [v for v in loopEdge.verts if len(v.link_edges) == 2]
            edgeRing = getEdgesRing(loopEdge)
            vert_ring_co = []
            for e in edgeRing:
                vertLoc = currentVert.co
                vert_ring_co.append(vertLoc[:])
                currentVert = e.other_vert(currentVert)  # TODO: make it work
            edge_ring_centers_List.append(vert_ring_co.copy())
        edge_ring_centers_List_per_island.append(edge_ring_centers_List.copy())

    bm.free()
    bpy.data.meshes.remove(me)
    return edge_ring_centers_List_per_island


def get_islands_proportions(splinesInIslands):
    widthPerIsland = []
    lengthPerIsland = []
    for splines in splinesInIslands:  # for islands
        splinesTotalLen = 0
        splineTotalWidth = 0
        prevSpline = splines[0]
        for splineIndex, spline in enumerate(splines):
            prevPoint = spline[0]
            for pointIndex, point in enumerate(spline):
                splinesSpacing = Vector(spline[pointIndex]) - Vector(prevSpline[pointIndex])
                splineTotalWidth += splinesSpacing.length
                splinesLen = Vector(point) - Vector(prevPoint)
                splinesTotalLen += splinesLen.length
                prevPoint = point
            prevSpline = spline
        lengthPerIsland.append(splinesTotalLen / len(splines))  # len*numb of spliness / number of splines
        widthPerIsland.append(splineTotalWidth / len(splines[0]))  # width*pointsNumb / numb of points
    maxWidthX = max(widthPerIsland)
    maxLengthY = max(lengthPerIsland)
    NormalizedWidthXPerIsland = [xWidth / maxWidthX for xWidth in widthPerIsland]
    NormalizedLengthYPerIsland = [yWidth / maxLengthY for yWidth in lengthPerIsland]
    return NormalizedWidthXPerIsland, NormalizedLengthYPerIsland


def calc_power(cpow):
    if cpow < 0:  # (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        cpow = 1 + cpow * 0.8  # map to 0.5 to 1  (old 1.3 - cpow)
    else:
        cpow = 1 + 4 * cpow  # map from 1 to 8
    return cpow


class CurvesFromsurface(bpy.types.Operator):
    bl_label = "Curves from grid surface"
    bl_idname = "object.curves_from_mesh"
    bl_description = "Generate hair curves from grid type mesh object \n" \
                     "For operator to work one border loop must be marked as sharp"
    bl_options = {"REGISTER", "UNDO","PRESET"}

    hairMethod = bpy.props.EnumProperty(name="Hair Method", default="edge",
                                        items=(("edge", "Edge Centers", ""),
                                               ("vert", "Vertex position", "")))
    hairType = bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    bezierRes = IntProperty(name="Bezier resolution", default=3, min=1, max=12)
    t_in_x = IntProperty(name="Strands amount", default=10, min=3, max=400)
    x_uniform = BoolProperty(name="Uniform Distribution", description="Uniform Distribution", default=True)
    noiseStrandSeparation = FloatProperty(name="Randomize Spacing", description="Randomize spacing between strands", default=0.3, min=0,
                                          max=1, subtype='PERCENTAGE')
    t_in_y = IntProperty(name="Strand Segments", default=8, min=3, max=20)
    y_uniform = BoolProperty(name="Uniform Distribution", description="Uniform Distribution", default=True)
    shortenStrandLen = FloatProperty(name="Shorten Segment", description="Shorten strand length", default=0.1, min=0, max=1, subtype='PERCENTAGE')
    Seed = IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    noiseMixFactor = FloatProperty(name="Noise Mix", description="Uniform vs non uniform noise", default=0.3, min=0,
                                   max=1, subtype='PERCENTAGE')
    noiseMixVsAdditive = BoolProperty(name="Mix additive", description="additive vs mix strand noise", default=False)
    noiseFalloff = FloatProperty(name="Noise falloff", description="Noise influence over strand lenght", default=0,
                                 min=-1, max=1, subtype='PERCENTAGE')
    snapAmount = FloatProperty(name="Snap Amount", default=0.5, min=0.0, max=1.0, subtype='PERCENTAGE')
    freq = FloatProperty(name="Noise freq", default=0.5, min=0.0, max=5.0)
    strandFreq = FloatProperty(name="Strand freq", default=0.5, min=0.0, max=5.0)
    noiseAmplitude = FloatProperty(name="Noise Amplitude", default=1.0, min=0.0, max=10.0)
    offsetAbove = FloatProperty(name="Offset Strands", description="Offset strands above surface", default=0.1,
                                min=0.01, max=1.0)
    Radius = FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, max=100)

    generateRibbons = BoolProperty(name="Generate Ribbons", description="Generate Ribbons on curve", default=False)
    strandResU = IntProperty(name="Segments U", default=3, min=1, max=5, description="Additional subdivision along strand length")
    strandResV = IntProperty(name="Segments V", default=2, min=1, max=5, description="Subdivisions perpendicular to strand length ")
    strandWidth = FloatProperty(name="Strand Width", default=0.5, min=0.0, max=10)
    strandPeak = FloatProperty(name="Strand peak", default=0.4, min=0.0, max=1, description="Describes how much middle point of ribbon will be elevated")
    strandUplift = FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")

    alignToSurface = BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    yLengthPerIsland = []
    xWidthPerIsland = []
    diagonal = 0
    # @classmethod #breaks undo
    # def poll(cls, context):
    #     return context.active_object.type == 'MESH'  # bpy.context.scene.render.engine == "CYCLES"
    # def invoke(self, context, event): #just shows prop pop-up but wont execute operator
    #     wm = context.window_manager
    #     return wm.invoke_props_dialog(self)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    @staticmethod
    def is_inside(p, bvht_tree, searchDistance):
        hitpoint, norm, face_index, distance = bvht_tree.find_nearest(p, searchDistance)  # max_dist = 10
        # hit, hitpoint, norm, face_index = obj.closest_point_on_mesh(p, 10)  # max_dist = 10
        vecP = hitpoint - p
        v = vecP.dot(norm)
        return v < 0.0

    def callInterpolation(self, verts2dListIsland, xFactor, yFactor, shortenStrandLen):
        xNormalized = max(round(self.t_in_x * xFactor), 2)
        yNormalized = max(round(self.t_in_y * yFactor), 2)
        return get2dInterpol(verts2dListIsland, xNormalized, yNormalized, shortenStrandLen, self.Seed, self.x_uniform, self.y_uniform, self.noiseStrandSeparation)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label("Hair Settings:")
        col = box.column(align=True)
        col.prop(self, 'hairMethod')
        # if self.hairMethod =='BEZIER' or self.hairMethod =='NURBS':
        col = box.column(align=True)
        col.prop(self, 'bezierRes')
        col.prop(self, 'Radius')
        col = box.column(align=True)
        col.prop(self, 'hairType')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(self, 't_in_x')
        row.prop(self, 'x_uniform', icon_only=True, emboss=True, icon='ARROW_LEFTRIGHT')
        row = col.row(align=True)
        row.prop(self, 't_in_y')
        row.prop(self, 'y_uniform', icon_only=True, emboss=True, icon='ARROW_LEFTRIGHT')
        row = col.row(align=True)
        row.prop(self, 'shortenStrandLen')

        box.label("Noise Settings:")
        col = box.column(align=True)
        col.prop(self, 'Seed')
        col.prop(self, 'noiseStrandSeparation')
        col.prop(self, 'noiseAmplitude')
        col.prop(self, 'noiseFalloff')
        col.prop(self, 'freq')
        col.prop(self, 'snapAmount')
        col.prop(self, 'offsetAbove')
        col = box.column(align=True)
        row = col.row()
        row.prop(self, 'noiseMixVsAdditive', icon_only=True, emboss=True, icon='PLUS')
        row.prop(self, 'noiseMixFactor')
        col.prop(self, 'strandFreq')

        box.prop(self, 'generateRibbons')
        if self.generateRibbons:
            col = box.column(align=True)
            col.prop(self, 'strandResU')
            col.prop(self, 'strandResV')
            col.prop(self, 'strandWidth')
            col.prop(self, 'strandPeak')
            col.prop(self, 'strandUplift')
            col.prop(self, 'alignToSurface')


    def invoke(self, context, event):
        sourceSurface = context.active_object
        if sourceSurface.type != 'MESH':
            self.report({'INFO'}, 'Works only on grid mesh type of sourceSurfaceect. Select mesh object first')
            return {"CANCELLED"}
        for face in sourceSurface.data.polygons:
            if len(face.edge_keys)!=4:
                self.report({'INFO'}, 'Non quad polygon detected. This operation works on quad only meshes')
                return {"CANCELLED"}
        me = sourceSurface.data
        # Get a BMesh representation
        bm = bmesh.new()  # create an empty BMesh
        bm.from_mesh(me)
        bm.edges.ensure_lookup_table()
        sharp_edges = [e for e in bm.edges if not e.smooth]
        if len(sharp_edges)==0:
            self.report({'INFO'}, 'No edges marked as sharp! Mark one border edge loop as sharp')
            return {"CANCELLED"}
        sharp_boundary_edges = [e for e in sharp_edges if e.is_boundary]
        if len(sharp_boundary_edges) == 0:
            self.report({'INFO'}, 'None of sharp edges are boundary edges! Mark one border edge loop as sharp')
            return {"CANCELLED"}
        if len(sharp_boundary_edges) == 1:
            self.hairMethod = 'vert'
        bm.free()

        self.sourceSurface_BVHT = BVHTree.FromObject(sourceSurface, context.scene)
        self.diagonal = math.sqrt(pow(sourceSurface.dimensions[0], 2) + pow(sourceSurface.dimensions[1], 2) + pow(sourceSurface.dimensions[2], 2))  # to normalize some values
        return self.execute(context)

    def execute(self, context):
        sourceSurface = context.active_object
        if self.hairMethod == 'edge':
            coLoopsPerIslandsList = get_edge_ring_centers(sourceSurface)
        else:
            coLoopsPerIslandsList = get_sorted_verts_co(sourceSurface)

        self.yLengthPerIsland, self.xWidthPerIsland = get_islands_proportions(coLoopsPerIslandsList)

        # hide source surface
        sourceSurface.draw_type = 'WIRE'
        sourceSurface.hide_render = True
        sourceSurface.cycles_visibility.camera = False
        sourceSurface.cycles_visibility.diffuse = False
        sourceSurface.cycles_visibility.glossy = False
        sourceSurface.cycles_visibility.transmission = False
        sourceSurface.cycles_visibility.scatter = False
        sourceSurface.cycles_visibility.shadow = False

        # create the Curve Datablock
        curveData = bpy.data.curves.new(sourceSurface.name+'_curve', type='CURVE')
        curveData.dimensions = '3D'
        curveData.fill_mode = 'FULL'
        # unitsScale = 1 # context.scene.unit_settings.scale_length
        if self.diagonal==0:
            diagonal = math.sqrt(pow(sourceSurface.dimensions[0], 2) + pow(sourceSurface.dimensions[1], 2) + pow(sourceSurface.dimensions[2], 2))  # to normalize some values
        else:
            diagonal = self.diagonal
        # print("diagonal is: "+str(diagonal))
        curveData.bevel_depth = 0.004 * diagonal * self.Radius
        curveData.bevel_resolution = 2

        sourceSurface_BVHT = self.sourceSurface_BVHT
        searchDistance = 1000 * diagonal
        cpow = calc_power(self.noiseFalloff)
        for xFactor, yFactor, edgeCentersRingsList in zip(self.xWidthPerIsland, self.yLengthPerIsland, coLoopsPerIslandsList):  # for islands
            Centers_of_EdgeRingsInterpolated = self.callInterpolation(edgeCentersRingsList, xFactor, yFactor,
                                                                      self.shortenStrandLen)
            # map coords to spline
            for l, edgeRingCenters in enumerate(Centers_of_EdgeRingsInterpolated):  # for each strand/ring
                curveLenght = len(edgeRingCenters)
                polyline = curveData.splines.new(self.hairType)
                if self.hairType == 'BEZIER':
                    polyline.bezier_points.add(curveLenght - 1)
                elif self.hairType == 'POLY' or self.hairType == 'NURBS':
                    polyline.points.add(curveLenght - 1)
                if self.hairType == 'NURBS':
                    polyline.order_u = 3  # like bezier thing
                    polyline.use_endpoint_u = True
                for i, edgeCenter in enumerate(edgeRingCenters):  # for strand point
                    edgeCenter = Vector(edgeCenter)
                    noise.seed_set(self.Seed)
                    noiseVectorPerAllHair = noise.noise_vector(edgeCenter * self.freq / diagonal, noise.types.STDPERLIN)
                    noise.seed_set(self.Seed + l)  # seed per strand/ring
                    noiseVectorPerStrand = noise.noise_vector(edgeCenter * self.strandFreq / diagonal, noise.types.STDPERLIN)
                    if self.noiseMixVsAdditive:
                        noiseMix = noiseVectorPerAllHair + noiseVectorPerStrand * self.noiseMixFactor
                    else:
                        noiseMix = noiseVectorPerAllHair * (1 - self.noiseMixFactor) + noiseVectorPerStrand * self.noiseMixFactor
                    noiseFalloff = math.pow(i / curveLenght, cpow)  # 0.1 to give 1% of influence on root
                    noisedEdgeCenter = edgeCenter + noiseMix * noiseFalloff * self.noiseAmplitude * diagonal  # linear fallof

                    snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(noisedEdgeCenter, searchDistance)
                    if not snappedPoint:  # search radius is too small ...
                        snappedPoint = noisedEdgeCenter #snap to itself...
                        normalSourceSurf = Vector((0,0,1))
                    snapMix = snappedPoint * self.snapAmount + noisedEdgeCenter * (1 - self.snapAmount)
                    offsetAbove = snapMix + (self.offsetAbove * 0.2) * diagonal * normalSourceSurf * noiseFalloff
                    x, y, z = offsetAbove
                    if self.hairType == 'BEZIER':
                        polyline.bezier_points[i].co = (x, y, z)
                        polyline.bezier_points[i].handle_left_type = 'AUTO'
                        polyline.bezier_points[i].handle_right_type = 'AUTO'
                    else:
                        polyline.points[i].co = (x, y, z, 1)
        curveData.resolution_u = self.bezierRes
        # create Object
        curveOB = bpy.data.objects.new(sourceSurface.name+'_curve', curveData)
        curveOB.targetObjPointer = sourceSurface.name  # store source surface for snapping oper
        curveOB.matrix_world = sourceSurface.matrix_world
        scn = context.scene
        scn.objects.link(curveOB)
        scn.objects.active = curveOB
        curveOB.select = True
        sourceSurface.select = False
        curveOB.data.show_normal_face = False
        if self.generateRibbons:
            bpy.ops.object.generate_ribbons(strandResU=self.strandResU, strandResV=self.strandResV,
                                        strandWidth=self.strandWidth, strandPeak=self.strandPeak,
                                        strandUplift=self.strandUplift, alignToSurface=self.alignToSurface)
            CurvesUVRefresh.uvCurveRefresh(curveOB)

        return {"FINISHED"}


class CurvesResample(bpy.types.Operator):
    bl_label = "Curve resample"
    bl_idname = "object.curve_resample"
    bl_description = "Change ammount of points on curve"
    bl_options = {"REGISTER", "UNDO"}

    hairType = bpy.props.EnumProperty(name="Output Curve Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    # bezierRes = IntProperty(name="Bezier resolution", default=3, min=1, max=12)
    t_in_y = IntProperty(name="Strand Segments", default=8, min=3, max=20)
    uniformPointSpacing = BoolProperty(name="Uniform spacing", description="Distribute stand points with uniform spacing", default=False)
    equalPointCount = BoolProperty(name="Equal point count", description="Give all cures same points count \n"
                                                                       "If disabled shorter curves will have less points", default=False)
    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=False)

    def invoke(self, context, event):
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        self.input_spline_type = Curve.data.splines[0].type
        self.hairType =  self.input_spline_type  #hair type  - output spline
        if self.input_spline_type == 'NURBS':
            self.nurbs_order = Curve.data.splines[0].order_u
        if len(Curve.data.splines) > 0:  # do get initnial value for resampling t
            polyline = Curve.data.splines[0]  # take first spline len for resampling
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                self.t_in_y = len(polyline.points)
            else:
                self.t_in_y = len(polyline.bezier_points)
        self.bezierRes = Curve.data.resolution_u

        return self.execute(context)

    def execute(self, context):
        curveObj = context.active_object
        if curveObj.type != 'CURVE':
            self.report({'INFO'}, 'Works only on curves')
            return {"CANCELLED"}
        pointsList = []
        pointsRadius = []
        pointsTilt = []
        selectedSplines = []

        if self.onlySelection:
            for polyline in curveObj.data.splines:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    if any(point.select==True for point in polyline.points):
                        selectedSplines.append(polyline)
                else:
                    if any(point.select_control_point == True for point in polyline.bezier_points):
                        selectedSplines.append(polyline)
            if not selectedSplines:
                selectedSplines = curveObj.data.splines
        else:
            selectedSplines = curveObj.data.splines

        for polyline in selectedSplines:  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                points = polyline.points
            else:
                points = polyline.bezier_points
            if len(points)>1: #skip single points
                pointsList.append([point.co.to_3d() for point in points])
                pointsRadius.append([point.radius for point in points])
                pointsTilt.append([point.tilt for point in points])
        backup_mat_indices = [spline.material_index for spline in selectedSplines]
        interpolRad = []
        interpolTilt = []
        # ipdb.set_trace()
        splinePointsList = interpol(pointsList, self.t_in_y, self.uniformPointSpacing, constantLen=self.equalPointCount)
        if self.equalPointCount: # each output spline will have same point count
            t_ins_y = [i / (self.t_in_y - 1) for i in range(self.t_in_y)]

            for radii, tilts in zip(pointsRadius, pointsTilt):  # per strand
                t_rad = [i / (len(radii) - 1) for i in range(len(radii))]
                interpolRad.append(np.interp(t_ins_y, t_rad, radii))  # first arg len() = out len
                interpolTilt.append(np.interp(t_ins_y, t_rad, tilts))  # first arg len() = out len
        else: # shorter output splines will have less points
            NormalizedStrandsLength = get_strand_proportions(pointsList)
            for radii, tilts, strandLen in zip(pointsRadius, pointsTilt, NormalizedStrandsLength):  # per strand
                # t_Normalized = max(round((self.t_in_y-1) * strandLen), 2)
                t_Normalized = max(math.ceil((self.t_in_y - 1) * strandLen), 2) + 1
                t_ins_Normalized = [i / (t_Normalized - 1) for i in range(int(t_Normalized))]
                t_rad = [[i / (len(radii) - 1) for i in range(len(radii))]]
                interpolRad.append(np.interp(t_ins_Normalized, t_rad[0], radii))  # first arg len() = out len
                interpolTilt.append(np.interp(t_ins_Normalized, t_rad[0], tilts))  # first arg len() = out len

        curveData = curveObj.data
        # spline_type =
        if self.onlySelection:
            for spline in selectedSplines:
                curveData.splines.remove(spline)
        else:
            curveData.splines.clear()

        newSplines = []
        for k, splinePoints in enumerate(splinePointsList):  # for each strand/ring
            curveLenght = len(splinePoints)
            polyline = curveData.splines.new(self.hairType)
            newSplines.append(polyline)
            if self.hairType == 'BEZIER':
                polyline.bezier_points.add(curveLenght - 1)
            elif self.hairType == 'POLY' or self.hairType == 'NURBS':
                polyline.points.add(curveLenght - 1)
            if self.hairType == 'NURBS':
                if self.input_spline_type == 'NURBS':
                    polyline.order_u = self.nurbs_order
                else:
                    polyline.order_u = 3  #like bezier thing
                polyline.use_endpoint_u = True
            # ipdb.set_trace()
            for i, points in enumerate(splinePoints):  # for strand point
                x, y, z = points
                if self.hairType == 'BEZIER':
                    polyline.bezier_points[i].co = (x, y, z)
                    polyline.bezier_points[i].radius = interpolRad[k][i]
                    polyline.bezier_points[i].tilt = interpolTilt[k][i]
                    polyline.bezier_points[i].handle_left_type = 'AUTO'
                    polyline.bezier_points[i].handle_right_type = 'AUTO'
                else:
                    polyline.points[i].co = (x, y, z, 1)
                    polyline.points[i].radius = interpolRad[k][i]
                    polyline.points[i].tilt = interpolTilt[k][i]
        curveData.resolution_u = self.bezierRes
        # bpy.ops.object.curve_uv_refresh()
        for i,newSpline in enumerate(newSplines):
            newSpline.material_index = backup_mat_indices[i]
        return {"FINISHED"}


class ParticleHairToCurves(bpy.types.Operator):
    bl_label = "Particle Hair to Curves"
    bl_idname = "object.hair_to_curves"
    bl_description = "Convert active Hair particle system to curves. "
    bl_options = {"REGISTER", "UNDO"}

    embed = FloatProperty(name="Embed roots", description="Embed roots", default=0, min=0, max=10)
    # embedTip = FloatProperty(name="Embed tips", description="Embed tips", default=0, min=0, max=10)
    hairType = bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    particleHairRes = IntProperty(name="Hair Res", description="How many points output curve will build off", default=3,
                                  min=0, max=6)
    strandResU = IntProperty(name="Segments U", default=3, min=1, max=5, description="Additional subdivision along strand length")
    strandResV = IntProperty(name="Segments V", default=2, min=1, max=5, description="Subdivisions perpendicular to strand length ")
    strandWidth = FloatProperty(name="Strand Width", default=0.5, min=0.0, max=10)
    strandPeak = FloatProperty(name="Strand peak", default=0.4, min=0.0, max=1, description="Describes how much middle point of ribbon will be elevated")
    strandUplift = FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")

    alignToSurface = BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    RadiusFalloff = FloatProperty(name="Radius falloff", description="Radius falloff over strand lenght", default=0,
                                  min=-1, max=1, subtype='PERCENTAGE')
    TipRadius = FloatProperty(name="Tip Radius", description="Tip Radius", default=1, min=0,
                                  max=1, subtype='PERCENTAGE')
    Radius = FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, max=100)
    generateRibbons = BoolProperty(name="Generate Ribbons", description="Generate Ribbons on curve", default=True)
    Seed = IntProperty(name="UV Seed", default=1, min=1, max=1000)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label("Curve from Particle Hair Settings:")
        box.prop(self, 'embed')
        # box.prop(self, 'embedTips')
        box.prop(self, 'particleHairRes')
        box.prop(self, 'hairType')
        box.prop(self, 'generateRibbons')
        col = box.column(align=True)

        if self.generateRibbons:
            col.prop(self, 'strandResU')
            col.prop(self, 'strandResV')
            col.prop(self, 'strandWidth')
            col.prop(self, 'strandPeak')
            col.prop(self, 'strandUplift')
            col.prop(self, 'Seed')
            col.prop(self, 'alignToSurface')
        else:
            col.prop(self, 'Radius')
            col.prop(self, 'RadiusFalloff')
            col.prop(self, 'TipRadius')

    def execute(self, context):
        particleObj = context.object
        partsysMod = None
        for mod in particleObj.modifiers:
            if mod.type == 'PARTICLE_SYSTEM':  #  and mod.show_viewport use first visible
                if particleObj.particle_systems.active.name == mod.particle_system.name:
                    if mod.particle_system.settings.type == "HAIR":
                        partsysMod = mod  # use first
                        break
        if partsysMod is None:
            self.report({'INFO'}, 'No active Particle Hair System found')
            return {"CANCELLED"}
        partsysMod.particle_system.settings.draw_step = self.particleHairRes
        bpy.ops.object.modifier_convert(modifier=partsysMod.name)
        newObj = context.active_object
        me = newObj.data
        bm = bmesh.new()  # create an empty BMesh
        bm.from_mesh(me)
        diagonal = math.sqrt(pow(particleObj.dimensions[0], 2) + pow(particleObj.dimensions[1], 2) + pow(particleObj.dimensions[2],
                                                                                                         2))  # to normalize some values
        sourceSurface_BVHT = BVHTree.FromObject(particleObj, context.scene)
        embed = self.embed * 0.04 * diagonal
        # embedTips = self.embedTips * 0.04 * diagonal
        for i, vert in enumerate(bm.verts):
            if vert.select: #cos converted hair to mesh has first verts selected
                snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(vert.co, 1000)
                nextVert = vert.link_edges[0].other_vert(vert)  # only one edge
                diff = vert.co - nextVert.co
                diff.normalize()
                vert.co += (diff - normalSourceSurf)* embed  #for slight bending root toward surface source
        bm.to_mesh(me)
        bm.free()
        newObj.data.transform(particleObj.matrix_world.inverted())  # cos modifier_convert above, applays loc,rot, scale so revert it
        newObj.matrix_world = particleObj.matrix_world
        bpy.ops.object.convert(target='CURVE')
        bpy.ops.object.editmode_toggle()
        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.spline_type_set(type=self.hairType)

        if self.hairType == 'NURBS':
            for polyline in context.active_object.data.splines:
                polyline.order_u = 3  # like bezier thing
                polyline.use_endpoint_u = True
        bpy.ops.object.editmode_toggle()

        newObj.data.dimensions = '3D'
        newObj.data.fill_mode = 'FULL'
        newObj.data.bevel_depth = 0.004 * diagonal
        newObj.data.bevel_resolution = 2
        newObj.data.resolution_u = self.strandResU
        if self.generateRibbons:
            # particleObj.targetObjPointer = newObj.name  # for child storing
            newObj.targetObjPointer = particleObj.name  # for snapping purpouse
            bpy.ops.object.generate_ribbons(strandResU=self.strandResU, strandResV=self.strandResV,
                                            strandWidth=self.strandWidth, strandPeak=self.strandPeak,
                                            strandUplift=self.strandUplift, alignToSurface=self.alignToSurface)
            CurvesUVRefresh.uvCurveRefresh(newObj)
        else:
            bpy.ops.object.curve_taper(TipRadiusFalloff=self.RadiusFalloff, MainRadius=self.Radius, TipRadius=self.TipRadius)

        partsysMod.show_viewport = False

        return {"FINISHED"}


def getObjectMassCenter(context, obj):
    local_bbox_center = 0.125 * sum((Vector(b) for b in obj.bound_box), Vector())
    global_bbox_center = obj.matrix_world * local_bbox_center
    region = context.region
    rv3d = context.space_data.region_3d
    return view3d_utils.location_3d_to_region_2d(region, rv3d, global_bbox_center)  # 3d coords to 2d reg

def particleHairFromPoints(self,context,particleObj,pointsList,extend=False):
    partsysMod = None
    context.scene.objects.active = particleObj

    for mod in particleObj.modifiers:
        if mod.type == 'PARTICLE_SYSTEM':  # use first visible
            if particleObj.particle_systems.active.name == mod.particle_system.name:
                partsysMod = particleObj.particle_systems.active  # use last
                mod.show_viewport = True
                extendList = []
                if extend and mod.particle_system.settings.type == "HAIR":
                    for strand in partsysMod.particles:  # for strand point
                        extendList.append([hair_key.co for hair_key in strand.hair_keys])
                    # ipdb.set_trace()
                    if len(extendList)>0:
                        pointsList.extend(interpol(extendList, len(pointsList[0]), uniform=False, constantLen=True))
                bpy.ops.particle.edited_clear()  # toogle editability
                break
    if partsysMod is None: #create new one
        self.report({'INFO'}, 'No active Particle Hair System found! Adding new one')
        particleObj.modifiers.new("HairNet", 'PARTICLE_SYSTEM')
        partsysMod = particleObj.particle_systems[-1]
        partsysMod.name = 'HairFromCurves'
    # ipdb.set_trace()
    # Create new settings
    partsysMod.settings.type = 'HAIR'
    partsysMod.settings.emit_from = 'FACE'
    partsysMod.settings.use_strand_primitive = True

    partsysMod.settings.hair_step = len(pointsList[0]) - 1  # == HAIR_KEY NUMB
    partsysMod.settings.count = len(pointsList)
    partsysMod.settings.draw_step = max(math.floor(math.log(len(pointsList[0]),2)),2)+1
    bpy.ops.particle.particle_edit_toggle()

    bpy.context.scene.tool_settings.particle_edit.use_emitter_deflect = False
    bpy.context.scene.tool_settings.particle_edit.use_preserve_root = False
    bpy.context.scene.tool_settings.particle_edit.use_preserve_length = False
    # bpy.context.scene.update()
    for i, points in enumerate(pointsList):  # for strand point
        partsysMod.particles[i].location = points[0]
        for j, point in enumerate(points):  # for strand point
            partsysMod.particles[i].hair_keys[j].co = Vector(point)

    # do empty stroke to save hair
    x, y = getObjectMassCenter(context, particleObj)
    #fix stupid particle jumpint by making empty comb
    bpy.context.scene.tool_settings.particle_edit.tool = 'COMB'
    brushSize = bpy.context.scene.tool_settings.particle_edit.brush.size
    bpy.context.scene.tool_settings.particle_edit.brush.size = 500
    # bpy.ops.particle.brush_edit(
    #     stroke=[{"name": "", "location": (0, 0, 0), "mouse": (x, y), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False}])
    # bpy.context.scene.update()
    bpy.ops.particle.brush_edit( #do 'empty' stroke to fix hair jumping
        stroke=[{"name": "", "location": (0, 0, 0), "mouse": (x, y), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False},
                {"name": "", "location": (0, 0, 0), "mouse": (x+1, y+1), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False}])
    bpy.context.scene.tool_settings.particle_edit.brush.size = brushSize
    bpy.context.scene.tool_settings.particle_edit.use_emitter_deflect = True
    bpy.context.scene.tool_settings.particle_edit.use_preserve_root = True
    bpy.context.scene.tool_settings.particle_edit.use_preserve_length = True
    #snap to surface
    bpy.ops.particle.disconnect_hair(all=True)
    bpy.ops.particle.connect_hair(all=True)
    bpy.ops.particle.particle_edit_toggle()


class ParticleHairFromCurves(bpy.types.Operator):
    bl_label = "Particle Hair from Curves"
    bl_idname = "object.hair_from_curves"
    bl_description = "Creates particle hair strands from Curves object. \n" \
                     "Two objects need to be selected: one mesh and one curve type"
    bl_options = {"REGISTER", "UNDO"}

    extend = BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=True)
    override_segments = BoolProperty(name="Resample strands", description="Force using strands segments parameter", default=False)
    t_in_y = IntProperty(name="Strand Segments", default=8, min=3, max=20)

    def invoke(self, context, event):
        particleObj = context.active_object
        if particleObj.type != 'MESH':
            self.report({'INFO'}, 'Select mesh object first')
            return {"CANCELLED"}
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label("Particle Hair from Curve settings:")
        box.prop(self, 'extend')
        box.prop(self, 'override_segments')
        col = box.column(align=True)
        if self.override_segments:
            col.prop(self, 't_in_y')

    @staticmethod
    def isEqualLen(lst_of_lsts):
        if len(lst_of_lsts) in (0, 1): return True
        lfst = len(lst_of_lsts[0])
        return all(len(lst) == lfst for lst in lst_of_lsts[1:])

    def execute(self, context):
        meshObj = [obj for obj in context.selected_objects if obj.type == 'MESH']
        curveObj = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        if len(meshObj) == 0 or len(curveObj) == 0:
            self.report({'INFO'}, 'Select one mesh and one curve object')
            return {"CANCELLED"}
        particleObj = meshObj[0]
        curveObj = curveObj[0]

        #wtf undo won't work without this .... extend - if disablend, and then enabled breaks appending old hair (old hair co are all null)
        bpy.context.scene.update()
        # sourceSurface_BVHT = BVHTree.FromObject(particleObj, context.scene)

        curveData = curveObj.data
        curveData.transform(particleObj.matrix_world.inverted()*curveObj.matrix_world) #to make it go into particle obj space
        pointsList = []
        for polyline in curveData.splines:  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                pointsList.append([point.co[0:3] for point in polyline.points])
            else:
                pointsList.append([point.co[0:3] for point in polyline.bezier_points])
        curveData.transform(curveObj.matrix_world.inverted() * particleObj.matrix_world)
        if self.override_segments: #if force resample
            averLen = self.t_in_y
            pointsList = interpol(pointsList, averLen, uniform=False)
        elif not self.isEqualLen(pointsList):  #else  do stroke interpolation for splines of various lengths
            averLen = int((len(pointsList[0]) + len(pointsList[1])) / 2)  # assume at least two splines?
            pointsInterpolated = interpol(pointsList, averLen, uniform=False)
            pointsList.clear()
            pointsList = pointsInterpolated

        particleHairFromPoints(self, context, particleObj, pointsList, extend = self.extend)
        return {"FINISHED"}


class GPencilToCurve(bpy.types.Operator):
    bl_label = "Curve from grease pencil"
    bl_idname = "object.curve_from_gp"
    bl_description = "Generate Curves from Scene or Object grease pencil data. \\n" \
                     "If you have curve object selected strokes will be appended to this curve \\n" \
                     "otherwise new curve will be created."
    bl_options = {"REGISTER", "UNDO"}

    hairType = bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    t_in_y = IntProperty(name="Strand Segments", default=6, min=3, max=20)
    noiseFalloff = FloatProperty(name="Noise falloff", description="Noise influence over strand lenght", default=0,
                                 min=-1, max=1, subtype='PERCENTAGE')
    offsetAbove = FloatProperty(name="Offset Strands", description="Offset strands above surface", default=0.2,
                                min=0.01, max=1.0)
    Radius = FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, max=100)
    extend = BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=True)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'hairType')
        layout.prop(self, 't_in_y')
        layout.prop(self, 'Radius')
        layout.prop(self, 'extend')

        if context.active_object.targetObjPointer:
            layout.prop(self, 'noiseFalloff')
            layout.prop(self, 'offsetAbove')


    def invoke(self, context, event):
        if context.active_object and context.active_object.select:
            selObj = context.active_object
        else:
            selObj = None


        if selObj and selObj.type=='CURVE' and len(selObj.data.splines) > 0:  # do get initnial value for resampling t
            polyline = selObj.data.splines[0]  # take first spline len for resampling
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                self.t_in_y = len(polyline.points)
            else:
                self.t_in_y = len(polyline.bezier_points)
            self.Radius =selObj.data.bevel_depth/0.004
        return self.execute(context)

    def execute(self, context):

        if context.active_object and context.active_object.select:
            selObj = context.active_object
        else:
            selObj = None

        addon_prefs = bpy.context.user_preferences.addons['hair_tool'].preferences
        if context.scene.GPSource:  # true == use scene gp
            if bpy.context.scene.grease_pencil and bpy.context.scene.grease_pencil.layers.active:
                if len(bpy.context.scene.grease_pencil.layers.active.active_frame.strokes) > 0:
                    strokes = bpy.context.scene.grease_pencil.layers.active.active_frame.strokes
                    bpy.context.scene.grease_pencil.layers.active.hide = addon_prefs.hideGPStrokes
                else:
                    self.report({'INFO'}, 'Scene has no grease pencil strokes for conversion to curves!')
                    return {"CANCELLED"}
            else:
                self.report({'INFO'}, 'Scene has no active grease pencil strokes for conversion to curves!')
                return {"CANCELLED"}

        else:  # false  == use object gp
            if selObj:
                if selObj.grease_pencil and selObj.grease_pencil.layers.active:
                    if len(selObj.grease_pencil.layers.active.active_frame.strokes) > 0:
                        strokes = selObj.grease_pencil.layers.active.active_frame.strokes
                        selObj.grease_pencil.layers.active.hide = addon_prefs.hideGPStrokes
                    else:
                        self.report({'INFO'}, 'Object has no grease pencil strokes for conversion to curves!')
                        return {"CANCELLED"}
                else:
                    self.report({'INFO'}, 'Selected object has no active grease pencil strokes! Try enabling \'Use scene GP\' ')
                    return {"CANCELLED"}
            else:
                self.report({'INFO'}, 'No object was selected, so no active grease pencil strokes found! Try selecting object with GP')
                return {"CANCELLED"}


        if not selObj or (selObj and selObj.type != 'CURVE'): #if no selection, or selection is not curve
            # self.report({'INFO'}, 'Use operator on curve type object')
            curveData = bpy.data.curves.new('CurveFromGP', type='CURVE')
            curveData.dimensions = '3D'
            curveData.fill_mode = 'FULL'
            # unitsScale = 1 # context.scene.unit_settings.scale_length
            curveData.bevel_depth = 0.004 * self.Radius
            curveData.bevel_resolution = 2
            Curve = bpy.data.objects.new('CurveFromGP', curveData)
            curveData.resolution_u = 3
            # curveOB.matrix_world = sourceSurface.matrix_world
            context.scene.objects.link(Curve)
            context.scene.objects.active = Curve
            Curve.select = True
            Curve.data.show_normal_face = False
            bpy.context.scene.update()
        else:
            Curve = context.active_object

        matInvCurve = Curve.matrix_world.inverted()
        Curve.data.show_normal_face = False
        sourceSurface_BVHT = None
        VGIndex = -1
        snapSurface = None
        invSnapSurfaceMat = 1
        SnapSurfaceMat = 1
        if Curve.targetObjPointer:
            if Curve.targetObjPointer in bpy.data.objects.keys():
                snapSurface = bpy.data.objects[Curve.targetObjPointer]
                sourceSurface_BVHT = BVHTree.FromObject(snapSurface, context.scene)
                VGIndex = snapSurface.vertex_groups.active_index
                # activeVertexGroup = context.active_object.vertex_groups[VGIndex]
                invSnapSurfaceMat = snapSurface.matrix_world.inverted()
                SnapSurfaceMat=snapSurface.matrix_world

        pointsList = []
        for stroke in strokes:
            pointsList.append([invSnapSurfaceMat*point.co for point in stroke.points])
        pointsInterpolated = interpol(pointsList, self.t_in_y, True)
        pointsList.clear()
        pointsList = pointsInterpolated

        Curve.data.fill_mode = 'FULL'
        Curve.data.bevel_depth = 0.004 * self.Radius
        searchDistance = 100
        cpow = calc_power(self.noiseFalloff)
        curveLenght = len(pointsList[0])

        if not self.extend:
            Curve.data.splines.clear()
        for points in pointsList:  # for strand point
            curveLength = len(points)
            polyline = Curve.data.splines.new(self.hairType)
            if self.hairType == 'BEZIER':
                polyline.bezier_points.add(curveLength - 1)
            elif self.hairType == 'POLY' or self.hairType == 'NURBS':
                polyline.points.add(curveLength - 1)
            if self.hairType == 'NURBS':
                polyline.order_u = 3  # like bezier thing
                polyline.use_endpoint_u = True

            weight = 1
            if sourceSurface_BVHT:  #calc weight based on root point
                snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(points[0], searchDistance)
                if VGIndex != -1:  # if vg exist
                    averageWeight = 0
                    for vertIndex in snapSurface.data.polygons[index].vertices:
                        # ipdb.set_trace()
                        for group in snapSurface.data.vertices[vertIndex].groups:
                            if group.group == VGIndex:
                                averageWeight += group.weight
                                break
                    weight = averageWeight / len(snapSurface.data.polygons[index].vertices)
            for i, point in enumerate(points):
                x, y, z = SnapSurfaceMat*matInvCurve*Vector(point)
                if sourceSurface_BVHT:
                    snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(point, searchDistance)
                    noiseFalloff = math.pow(i / curveLenght, cpow)  # 0.1 to give 1% of influence on root
                    offsetAbove = Vector(point) + self.offsetAbove * normalSourceSurf * noiseFalloff * weight
                    x, y, z = SnapSurfaceMat*matInvCurve*offsetAbove
                if self.hairType == 'BEZIER':
                    polyline.bezier_points[i].co = (x, y, z)
                    polyline.bezier_points[i].handle_left_type = 'AUTO'
                    polyline.bezier_points[i].handle_right_type = 'AUTO'
                else:
                    polyline.points[i].co = (x, y, z, 1)
        Curve.data.resolution_u = 3
        return {"FINISHED"}


class ParticleHairFromGPencil(bpy.types.Operator):
    bl_label = "Particle hair from GPencile"
    bl_idname = "object.particle_from_gp"
    bl_description = "Convert Grease Pencil strokes to Particle hair, \n" \
                     "and attach them to selected mesh object"
    bl_options = {"REGISTER", "UNDO"}

    hairType = bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    t_in_y = IntProperty(name="Strand Segments", default=4, min=3, max=20)
    offsetFalloff = FloatProperty(name="Offset Falloff", description="Noise influence over strand lenght", default=0,
                                 min=-1, max=1, subtype='PERCENTAGE')
    offsetAbove = FloatProperty(name="Offset Strands", description="Offset strands above surface", default=0.2,
                                min=0.01, max=5.0)
    useVertWeight = BoolProperty(name="Use Vertex Weight", description="Use Vertex Weight for modulating particle offset", default=False)
    extend = BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=False)

    def invoke(self, context, event):
        particleObj = context.active_object
        if particleObj.type != 'MESH':
            self.report({'INFO'}, 'Select mesh object first')
            return {"CANCELLED"}

        return self.execute(context)

    def execute(self, context):
        particleObj = context.active_object
        matInvHairObj = particleObj.matrix_world.inverted()
        addon_prefs = bpy.context.user_preferences.addons['hair_tool'].preferences
        if context.scene.GPSource:  # true == use scene gp
            if bpy.context.scene.grease_pencil and bpy.context.scene.grease_pencil.layers.active:
                if len(bpy.context.scene.grease_pencil.layers.active.active_frame.strokes) > 0:
                    strokes = bpy.context.scene.grease_pencil.layers.active.active_frame.strokes
                    bpy.context.scene.grease_pencil.layers.active.hide = addon_prefs.hideGPStrokes
                else:
                    self.report({'INFO'}, 'Scene has no grease pencil strokes for conversion to curves!')
                    return {"CANCELLED"}
            else:
                self.report({'INFO'}, 'Scene has no active grease pencil strokes for conversion to curves!')
                return {"CANCELLED"}
        else:  # false  == use object gp
            if particleObj:
                if particleObj.grease_pencil and particleObj.grease_pencil.layers.active:
                    if len(particleObj.grease_pencil.layers.active.active_frame.strokes) > 0:
                        strokes = particleObj.grease_pencil.layers.active.active_frame.strokes
                        particleObj.grease_pencil.layers.active.hide = addon_prefs.hideGPStrokes
                    else:
                        self.report({'INFO'}, 'Object has no grease pencil strokes for conversion to curves!')
                        return {"CANCELLED"}
                else:
                    self.report({'INFO'}, 'Selected object has no active grease pencil strokes! Try enabling \'Use scene GP\' ')
                    return {"CANCELLED"}
            else:
                self.report({'INFO'}, 'No object was selected, so no active grease pencil strokes found! Try selecting object with GP')
                return {"CANCELLED"}

        bm = bmesh.new()  # create an empty BMesh
        bm.from_mesh(particleObj.data)
        sourceSurface_BVHT = BVHTree.FromBMesh(bm)
        bm.free()
        sourceSurface_BVHT_mod = BVHTree.FromObject(particleObj, context.scene) # to get smoother result when using subdiv

        VGIndex = particleObj.vertex_groups.active_index
        # activeVertexGroup = context.active_object.vertex_groups[VGIndex]
        diagonal = math.sqrt(pow(particleObj.dimensions[0], 2) + pow(particleObj.dimensions[1], 2) + pow(particleObj.dimensions[2], 2))/4  # to normalize some values
        searchDistance = 100 * diagonal
        pointsList = []
        if VGIndex != -1:
            self.report({'INFO'}, 'Active object has no active vertex group found!')
        if len(strokes)==0:
            self.report({'INFO'}, 'No GP strokes found!')
        for stroke in strokes:
            pointsList.append([matInvHairObj*point.co for point in stroke.points])
        pointsInterpolated = interpol(pointsList, self.t_in_y, uniform=True, constantLen=True)

        cpow = calc_power(self.offsetFalloff)
        strandLen = len(pointsInterpolated[0])
        pointsList = [[] for x in range(len(pointsInterpolated))]

        for i,points in enumerate(pointsInterpolated):  # for strand point
            weight = 1
            if self.useVertWeight:  #calc weight based on root point
                snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT.find_nearest(points[0], searchDistance) #search dist = 100
                if VGIndex != -1: #if vg exist
                    averageWeight = 0
                    for vertIndex in particleObj.data.polygons[index].vertices:
                        # ipdb.set_trace()
                        for group in particleObj.data.vertices[vertIndex].groups:
                            if group.group == VGIndex:
                                averageWeight += group.weight
                                break
                    weight = averageWeight / len(particleObj.data.polygons[index].vertices)
            for j, point in enumerate(points):
                if sourceSurface_BVHT:
                    snappedPoint, normalSourceSurf, index, distance = sourceSurface_BVHT_mod.find_nearest(Vector(point),searchDistance)
                    noiseFalloff = math.pow(j / strandLen, cpow)
                    offsetAbove = Vector(point) + self.offsetAbove * normalSourceSurf * noiseFalloff * weight * diagonal
                    pointsList[i].append(offsetAbove)
        particleHairFromPoints(self, context, particleObj, pointsList,extend=self.extend)
        return {"FINISHED"}

#for custom ui curve mapping panel - wont work in f6 props
def myNodeTree():
    if 'HairToolCurveTmp' not in bpy.data.node_groups:
        ng = bpy.data.node_groups.new('HairToolCurveTmp', 'ShaderNodeTree')
        ng.fake_user = True
    return bpy.data.node_groups['HairToolCurveTmp'].nodes

def myCurveData():
    nt = myNodeTree()
    if "RGB Curves" not in nt.keys():
        nt.new('ShaderNodeRGBCurve')
    return myNodeTree()["RGB Curves"]


class CurvesRadius(bpy.types.Operator):
    bl_label = "Taper Curve"
    bl_idname = "object.curve_taper"
    bl_description = "Taper Curve radius over length"
    bl_options = {"REGISTER", "UNDO"}

    MainRadius = FloatProperty(name="Main Radius", description="Main Radius", default=1, min=0, max=10)
    RootRadius = FloatProperty(name="Root Radius", description="Root Radius Taper", default=1, min=0, max=1, subtype='PERCENTAGE')
    RootRadiusFalloff = FloatProperty(name="Root Radius falloff", description="Radius falloff over strand length", default=0,
                                  min=-1, max=1, subtype='PERCENTAGE')
    TipRadius = FloatProperty(name="Tip Radius", description="Tip Radius Taper", default=0, min=0, max=1, subtype='PERCENTAGE')
    TipRadiusFalloff = FloatProperty(name="Tip Radius falloff", description="Radius falloff over strand length", default=0,
                                  min=-1, max=1, subtype='PERCENTAGE')
    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=False)

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object

        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        # self.layout.template_curve_mapping(bpy.data.node_groups['HairToolCurveTmp'].nodes["RGB Curves"], "mapping")
        layout.prop(self, 'MainRadius')
        col = layout.column(align=True)
        col.prop(self, 'RootRadius')
        col.prop(self, 'RootRadiusFalloff')
        col = layout.column(align=True)
        col.prop(self, 'TipRadius')
        col.prop(self, 'TipRadiusFalloff')
        layout.prop(self, 'onlySelection')

    def execute(self, context):
        # myCurveData()
        selectedCurves = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        cpowRoot = calc_power(-self.RootRadiusFalloff)
        cpowTip = calc_power(-self.TipRadiusFalloff)
        for Curve in selectedCurves:
            curveData = Curve.data
            for polyline in curveData.splines:  # for strand point
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = polyline.points
                else:
                    points = polyline.bezier_points
                if self.onlySelection:
                    if polyline.type == 'NURBS' or polyline.type == 'POLY':
                        points = [point for point in points if point.select]
                    else:  # bezier
                        points = [point for point in points if point.select_control_point]
                curveLength = len(points)
                for j, point in enumerate(points):  # for strand point
                    RadFallof = math.pow(j / curveLength, cpowRoot)
                    RadMIx = self.RootRadius * self.MainRadius * (1-RadFallof)  +  self.MainRadius*RadFallof
                    point.radius = RadMIx  # apply fallof
                for j, point in enumerate(reversed(points)):  # for strand point
                    RadFallof = math.pow(j / curveLength, cpowTip)
                    RadMIx =  self.TipRadius * self.MainRadius * (1-RadFallof)  +  self.MainRadius*RadFallof
                    point.radius *= RadMIx  # apply fallof

        return {"FINISHED"}


class CurvesTiltAlign(bpy.types.Operator):
    bl_label = "Align curve tilt "
    bl_idname = "object.curves_align_tilt"
    bl_description = "Align curve tilt so that it is aligned to target object surface"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    # resetTilt = BoolProperty(name="Reset Tilt", description="Reset Tilt before aligning it to surface", default=True)

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    @staticmethod
    def find_nearest(p, bvht_tree, searchDistance):
        hitpoint, norm, face_index, distance = bvht_tree.find_nearest(p, searchDistance)  # max_dist = 10
        # hit, hitpoint, norm, face_index = obj.closest_point_on_mesh(p, 10)  # max_dist = 10
        vecP = hitpoint - p
        v = vecP.dot(norm)
        return hitpoint, norm, face_index, distance, v < 0.0  # v<0 = = is inside volume?

    @staticmethod
    def angle_signed(vA, vB, vN):  # angle betwen a - b, is vN space
        a = vA.normalized()
        b = vB.normalized()
        adotb = a.dot(b)  # not sure why but cos(x) goes above 1, and below -1   if a= -b
        if a.dot(b) > 1:
            adotb = 1
        elif a.dot(b) < -1:
            adotb = -1
        angle = math.acos(adotb)
        cross = a.cross(b)
        if vN.dot(cross) < 0:  # // Or > 0
            angle = -angle
        return angle

    @staticmethod
    def get_tangents(me, index, is_last):
        selected_vert = me.vertices[index]
        if is_last:
            prev = me.vertices[index - 3]
            tangent = selected_vert.co - prev.co
        else:
            nextVert = me.vertices[index + 3]
            tangent = nextVert.co - selected_vert.co
        return tangent.normalized()

    def execute(self, context):
        snapTargetName = context.active_object.targetObjPointer
        if snapTargetName not in bpy.data.objects.keys():
            self.report({'INFO'}, 'No target to snap to')
            return {"CANCELLED"}
        snapTarget = bpy.data.objects[snapTargetName]
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        snapTarget.data.transform(snapTarget.matrix_world)
        Curve.data.transform(Curve.matrix_world)
        curveBevelObj = Curve.data.bevel_object  # backup
        context.active_object.data.bevel_object = None  # zero out to prevent changing default one
        curveResU = Curve.data.resolution_u  # backup
        Curve.data.resolution_u = 12
        bpy.ops.object.generate_ribbons(strandResV=2, strandWidth=0.01, strandPeak=0)  # for temp curve for tangent and normals

        meFromCurve = Curve.to_mesh(context.scene, True, 'PREVIEW')
        size = len(meFromCurve.vertices)
        kdMeshFromCurve = kdtree.KDTree(size)
        for i, v in enumerate(meFromCurve.vertices):
            kdMeshFromCurve.insert(v.co, i)
        kdMeshFromCurve.balance()

        curveData = Curve.data

        snapTarget_BVHT_tree = BVHTree.FromObject(snapTarget, context.scene)  # render eg use subsurf render settin
        unitsScale = context.scene.unit_settings.scale_length
        searchDistance = 10 / unitsScale
        for i, polyline in enumerate(curveData.splines):  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                points = polyline.points
            else:
                points = polyline.bezier_points
            pointsNumber = len(points) - 1  # helper for tangetnt function (to detect last point on cuve)
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
            prevAngle = 0
            angleFlipFix = [-2*math.pi, -math.pi, 2*math.pi, math.pi]
            for j, curvePoint in enumerate(points):  # for strand point
                curvePoint3dLoc = curvePoint.co.to_3d()
                pointOnMeshLoc, normSnapTarget, face_index, distance, isInside = \
                    self.find_nearest(curvePoint3dLoc, snapTarget_BVHT_tree, searchDistance)

                # get vertex closest to spline point (for normal) from temp spline representation
                co, index, dist = kdMeshFromCurve.find(curvePoint3dLoc)
                curveNormal = meFromCurve.vertices[index].normal

                vecSurfaceHit = curvePoint3dLoc - pointOnMeshLoc
                if isInside:  # if curve point is outside snapSurface flip it
                    vecSurfaceHit *= -1

                # vecSurfaceHit = normSnapTarget * -1  # less accurate but faster...
                isLast = True if j == pointsNumber else False
                tangent = self.get_tangents(meFromCurve, index, isLast)  # for bezier we can gets handles for tanget
                biTangentCurve = tangent.cross(curveNormal)
                vectSurfHitProjected90 = tangent.cross(vecSurfaceHit)
                vectSurfHitProjectedToTangent = vectSurfHitProjected90.cross(tangent)
                # angle = biTangentCurve.angle(vectSurfHitProjectedToTangent)  #unsigned angle 0 - 180
                angle = self.angle_signed(biTangentCurve, vectSurfHitProjectedToTangent,
                                          tangent) - math.pi / 2  # a,b, vN  - signed -180 to 180
                if j>1 and abs(prevAngle-angle)>math.pi/2: #try fixing random flips in ribbons surface
                    fix = [fix_angle for fix_angle in angleFlipFix if abs(prevAngle - fix_angle-angle)<math.pi/2]
                    if len(fix)>0:
                        angle+=fix[0]
                prevAngle = angle
                curvePoint.tilt += angle   # in radians
            # manually smooth first two points cos they are usually broken
            if len(points) >= 4:
                points[0].tilt = points[1].tilt = (points[2].tilt + points[3].tilt) / 2
            if len(points) == 3:
                points[0].tilt = points[1].tilt = points[2].tilt

        bpy.data.meshes.remove(meFromCurve)
        context.active_object.data.bevel_object = curveBevelObj  # restore old bevel obj
        snapTarget.data.transform(snapTarget.matrix_world.inverted())
        Curve.data.transform(Curve.matrix_world.inverted())
        Curve.data.resolution_u = curveResU
        return {"FINISHED"}


class CurvesTiltRandomize(bpy.types.Operator):
    bl_label = "Randomize curve tilt "
    bl_idname = "object.curves_randomize_tilt"
    bl_description = "Randomize curve tilt"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    # resetTilt = BoolProperty(name="Reset Tilt", description="Reset Tilt before aligning it to surface", default=True)
    Seed = IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    noiseAmplitude = FloatProperty(name="Tilt Amplitude", description="Tilt strength", default=0.5, min=0,
                                   max=1, subtype='PERCENTAGE')
    tiltMixFalloff = FloatProperty(name="Tilt falloff", description="Tilt strength over strand length", default=0,
                                   min=-1, max=1, subtype='PERCENTAGE')
    tiltMixPropagate = FloatProperty(name="Propagate to roots", description="Propagate tilt change to hair roots", default=0, min=0,
                                     max=1, subtype='PERCENTAGE')

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    def execute(self, context):
        snapTargetName = context.active_object.targetObjPointer
        if snapTargetName not in bpy.data.objects.keys():
            self.report({'INFO'}, 'No target to snap to')
            return {"CANCELLED"}
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        np.random.seed(self.Seed)
        randTiltList = 6 * np.random.rand(len(Curve.data.splines)) - 3
        cpow = calc_power(-self.tiltMixFalloff)
        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                points = polyline.points
            else:
                points = polyline.bezier_points
            pointsNumber = len(points)
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
            for j, curvePoint in enumerate(points):  # for strand point
                MixFallof = math.pow(j / pointsNumber, cpow)
                randomizedAngle = randTiltList[i] * self.noiseAmplitude * (MixFallof * (1 - self.tiltMixPropagate) + self.tiltMixPropagate)
                curvePoint.tilt += randomizedAngle   # in radians
        return {"FINISHED"}


interpolation_items = (("LINEAR", "Linear", ""),
                       ("BSPLINE", "Bspline", ""),
                       ("CARDINAL", "Cardinal", ""))

class CurvesSmooth(bpy.types.Operator):
    bl_label = "Smooth curve"
    bl_idname = "object.curves_smooth"
    bl_description = "Smooth curve points"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    # resetTilt = BoolProperty(name="Reset Tilt", description="Reset Tilt before aligning it to surface", default=True)
    smooth = IntProperty(name="Smooth iterations", default=1, min=0, max=20)
    nurbs_order = IntProperty(name="Nurbs Order", default=3, min=2, max=6)
    tilt_interpols = bpy.props.EnumProperty(name="Tilt Interpolation", default="BSPLINE", items=interpolation_items)
    radius_interpol = bpy.props.EnumProperty(name="Radius Interpolation", default="BSPLINE", items=interpolation_items)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        Curve = context.active_object
        active_spline_type = Curve.data.splines.active.type
        layout = self.layout
        box = layout.box()
        box.label("Curve Smooth")
        box.prop(self, 'onlySelection')
        box.prop(self, 'smooth')
        col = box.column(align=True)
        if active_spline_type=='NURBS':
            col.prop(self, 'nurbs_order')
        elif active_spline_type=='BEZIER':
            col.prop(self, 'tilt_interpols')
            col.prop(self, 'radius_interpol')

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    def execute(self, context):

        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        mode = Curve.mode
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        pointsList = []
        BezierpointsList = []
        if not self.onlySelection:  # store selection
            for polyline in Curve.data.splines:  # for strand point
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    pointsList += [point for point in polyline.points if point.select]  # += flat 1D list
                else:
                    BezierpointsList += [point for point in polyline.bezier_points if point.select_control_point]
            bpy.ops.curve.select_all(action='SELECT')

        for i in range(self.smooth):
            bpy.ops.curve.smooth()
        if not self.onlySelection:
            bpy.ops.curve.select_all(action='DESELECT')
            for p in pointsList:
                p.select = True
            for p in BezierpointsList:
                p.select_control_point = True

        active_spline_type = Curve.data.splines.active.type
        for polyline in Curve.data.splines:  # for strand point
            if polyline.type == 'NURBS' and active_spline_type=='NURBS':
                polyline.order_u = self.nurbs_order
            elif polyline.type == 'BEZIER' and active_spline_type=='BEZIER':
                polyline.tilt_interpolation = self.tilt_interpols
                polyline.radius_interpolation = self.radius_interpols

        bpy.ops.object.mode_set(mode=mode, toggle=False)
        return {"FINISHED"}


class CurvesTiltSmooth(bpy.types.Operator):
    bl_label = "Smooth tilt"
    bl_idname = "object.curves_smooth_tilt"
    bl_description = "Smooth curve tilt"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    strength = IntProperty(name="Smooth strength", default=3, min=1, max=10)

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    @staticmethod
    def smooth(y, box_pts):
        # box = np.ones(box_pts) / box_pts
        len_y = len(y)
        # rev_y = list(reversed(y))
        # y_3x = rev_y +y + rev_y
        # y_smooth = np.convolve(y_3x, box, mode='same')
        smoothed = []
        for i in range(len(y)):
            low = max(0, i - box_pts)
            hi = min(len_y, i + box_pts)
            smoothed.append(np.sum(y[low:hi]) / (hi - low))  # average
        return smoothed

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                points = polyline.points
            else:
                points = polyline.bezier_points
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
            curveTiltList = [curvePoint.tilt for curvePoint in points]
            smoothedTilts = self.smooth(curveTiltList, self.strength)
            for j, curvePoint in enumerate(points):  # for strand point
                curvePoint.tilt = smoothedTilts[j]
        return {"FINISHED"}


class CurvesRadiusSmooth(bpy.types.Operator):
    bl_label = "Smooth radius"
    bl_idname = "object.curves_smooth_radius"
    bl_description = "Smooth curve radius"
    bl_options = {"REGISTER", "UNDO"}

    onlySelection = BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    strength = IntProperty(name="Smooth strength", default=3, min=1, max=10)

    def invoke(self, context, event): #make selection only false, if obj mode
        particleObj = context.active_object
        if particleObj.mode == 'EDIT':
            self.onlySelection = True
        elif particleObj.mode == 'OBJECT':
            self.onlySelection = False
        return self.execute(context)

    @staticmethod
    def smooth(y, box_pts):
        # box = np.ones(box_pts) / box_pts
        len_y = len(y)
        # rev_y = list(reversed(y))
        # y_3x = rev_y +y + rev_y
        # y_smooth = np.convolve(y_3x, box, mode='same')
        smoothed = []
        for i in range(len(y)):
            low = max(0, i - box_pts)
            hi = min(len_y, i + box_pts)
            smoothed.append(np.sum(y[low:hi]) / (hi - low))  # average
        return smoothed

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        for i, polyline in enumerate(Curve.data.splines):  # for strand point
            if polyline.type == 'NURBS' or polyline.type == 'POLY':
                points = polyline.points
            else:
                points = polyline.bezier_points
            if self.onlySelection:
                if polyline.type == 'NURBS' or polyline.type == 'POLY':
                    points = [point for point in points if point.select]
                else:  # bezier
                    points = [point for point in points if point.select_control_point]
            curveRadiusList = [curvePoint.radius for curvePoint in points]
            smoothedRaadius = self.smooth(curveRadiusList, self.strength)
            for j, curvePoint in enumerate(points):  # for strand point
                curvePoint.radius = smoothedRaadius[j]
        return {"FINISHED"}


class EditCurveProfile(bpy.types.Operator):
    bl_label = "Edit curve Profile"
    bl_idname = "object.curves_edit_profile"
    bl_description = "Edit curve Profile (link it to scene and put into edit mode)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and obj.data.bevel_object

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        bevelObj = bpy.context.object.data.bevel_object
        if bevelObj:
            if bevelObj.name not in context.scene.objects.keys():
                bpy.context.scene.objects.link(bevelObj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects.active = bevelObj
            bevelObj.select
            bpy.context.scene.update()
            bpy.ops.view3d.view_selected()
            bpy.ops.object.editmode_toggle()
            self.report({'INFO'}, 'Editing curve Profile was successful')
        return {"FINISHED"}

class CloseCurveProfile(bpy.types.Operator):
    bl_label = "Close curve Profile"
    bl_idname = "object.curves_close_profile"
    bl_description = "Hide curve Profile object (unlink it from scene)"
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        for selObj in context.scene.objects:
            Curve = selObj
            if  Curve.type != 'CURVE':
                # self.report({'INFO'}, Curve.name+' is not curve type object. Skipping')
                continue
            bevelObj = Curve.data.bevel_object
            if bevelObj:
                if bevelObj.name in context.scene.objects.keys():
                    if bevelObj.mode=='EDIT':
                        bpy.ops.object.editmode_toggle()
                    bpy.context.scene.objects.unlink(bevelObj)
                    self.report({'INFO'}, 'Closing curve Profile '+bevelObj.name+' was successful')
        return {"FINISHED"}